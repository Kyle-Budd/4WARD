import {Pressable, Text, View} from 'native-base';
import React from 'react';
import pagestyles from '../styles/story.style';
import EvilIcons from 'react-native-vector-icons/EvilIcons';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Ionicons from 'react-native-vector-icons/Ionicons';

function PostActivity({
  handelNavigateShare,
  handelLikeUnlike,
  handelDisLike,
  likes,
  disLikes,
  comments,
  isLiked,
  isDisLiked,
  showShare,
}) {
  return (
    <View
      style={[
        {
          flexDirection: 'row',
          justifyContent: showShare ? 'space-between' : 'space-around',
          paddingHorizontal: 15,
          paddingBottom: 15,
        },
      ]}>
      <Pressable style={pagestyles.numList} onPress={handelLikeUnlike}>
        <MaterialCommunityIcons
          name={isLiked ? 'heart' : 'heart-outline'}
          size={25}
          color={'#900'}
        />
        <Text style={pagestyles.numbr} ml="1">
          {likes}
        </Text>
      </Pressable>
      <Pressable style={pagestyles.numList} onPress={handelDisLike}>
        <MaterialCommunityIcons
          name={!isDisLiked ? 'heart-off-outline' : 'heart-off'}
          size={25}
          color={'#900'}
        />
        <Text style={pagestyles.numbr} ml="1">
          {disLikes}
        </Text>
      </Pressable>
      <Pressable style={pagestyles.numList}>
        <EvilIcons name="comment" size={30} color="#900" />
        <Text style={pagestyles.numbr} ml="1">
          {comments}
        </Text>
      </Pressable>
      {showShare && (
        <Pressable style={pagestyles.numList} onPress={handelNavigateShare}>
          <EvilIcons name="share-google" size={30} color="#900" />
          <Text style={pagestyles.numbr} ml="1">
            Share
          </Text>
        </Pressable>
      )}
    </View>
  );
}

export default PostActivity;
