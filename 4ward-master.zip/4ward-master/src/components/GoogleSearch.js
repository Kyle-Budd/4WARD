import {View} from 'native-base';
import React, {useRef} from 'react';
import {Keyboard} from 'react-native';
import {GooglePlacesAutocomplete} from 'react-native-google-places-autocomplete';
import {API_KEY} from '../utils/apiKey';

function GoogleSearch({setSearchLocation, handelAnimate}) {
  const inputRef = useRef(null);
  return (
    <View
      style={{
        zIndex: 100,
        justifyContent: 'center',
        alignItems: 'center',
        flex: 1,
        position: 'absolute',
        top: 5,
        left: 0,
        right: 0,
        marginBottom: 5,
        paddingHorizontal: 5,
        // shadowOffset: {width: 10, height: 10},
        // shadowOpacity: 0.5,
      }}>
      <GooglePlacesAutocomplete
        ref={inputRef}
        styles={{
          container: {borderRadius: 50, zIndex: 100, width: '100%'},
          textInputContainer: {
            borderRadius: 50,
            zIndex: 100,
            width: '100%',
          },

          textInput: {
            paddingStart: 20,
            borderRadius: 50,
            zIndex: 100,
            marginTop: 5,
            borderColor: '#900',
            borderWidth: 2,
            color: '#900',
          },
        }}
        onPress={(data, details = null) => {
          // 'details' is provided when fetchDetails = true
          // console.log(data, details);
          setSearchLocation({
            address: data?.description,
            location: details?.geometry?.location,
          });
          handelAnimate();
          inputRef.current.setAddressText('');
          Keyboard.dismiss();
        }}
        query={{
          key: API_KEY,
          language: 'en',
        }}
        //  ref={inputRef}
        onFail={() => alert('something went wrong')}
        debounce={500}
        fetchDetails={true}
        GooglePlacesDetailsQuery={{fields: 'geometry'}}
        enablePoweredByContainer={false}
        placeholder="Find a safe route"
        nearbyPlacesAPI="GooglePlacesSearch"
      />
    </View>
  );
}

export default GoogleSearch;
