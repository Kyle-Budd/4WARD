import React from 'react';
import Icon from 'react-native-vector-icons/MaterialIcons';
import {HStack, Pressable, Box, Text, View} from 'native-base';
import {useNavigation} from '@react-navigation/native';

const CustomHeader = ({title}) => {
  const navigation = useNavigation();

  return (
    <View>
      <HStack
        // justifyContent={'space-between'}
        alignItems="center"
        backgroundColor={'#fff'}
        shadow={'6'}
        px="6"
        py={'3.5'}>
        <Pressable
          onPress={() => navigation.goBack()}
          android_ripple={{
            color: '#ddd',
            radius: 15,
            borderless: true,
            foreground: true,
          }}>
          <Box flex={1}>
            <Icon name="keyboard-backspace" size={30} color={'#888'} />
          </Box>
        </Pressable>
        <Text
          maxW={'90%'}
          color={'#888'}
          textTransform={'uppercase'}
          marginTop={1}
          marginLeft={5}
          fontWeight="bold"
          fontSize={16}>
          {title.length > 20 ? `${title.slice(0, 20)}...` : title}
        </Text>
      </HStack>
    </View>
  );
};

export default CustomHeader;
