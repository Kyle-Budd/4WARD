import React from 'react';
import {Spinner, View} from 'native-base';

const Customloader = ({color = '#000'}) => {
  return (
    <View flex={1} justifyContent={'center'} alignItems={'center'}>
      <Spinner color={'#900'} size={'lg'} />
    </View>
  );
};

export default Customloader;
