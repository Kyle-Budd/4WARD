import {HStack, Text} from 'native-base';
import React from 'react';
import Icon from 'react-native-vector-icons/MaterialIcons';

function DateComp({time, com}) {
  return (
    <HStack space={'2'}>
      {!com && <Icon name="access-time" size={20} color="#aaa" />}
      <HStack space={'2'}>
        <Text
          style={{
            fontSize: 14,
            color: '#000',
          }}>
          {new Date(time * 1000).toLocaleDateString()}
        </Text>
        <Text
          style={{
            fontSize: 14,
            color: '#000',
          }}>
          {new Date(time * 1000).toLocaleTimeString()}
        </Text>
      </HStack>
    </HStack>
  );
}

export default DateComp;
