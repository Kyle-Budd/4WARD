import React from 'react';
import {Spinner, View, HStack, Pressable} from 'native-base';
import Icon from 'react-native-vector-icons/MaterialIcons';
import MCIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import {useNavigation} from '@react-navigation/native';

const TabBar = () => {
  const navigation = useNavigation();

  return (
    <HStack justifyContent={'space-between'} p={'3'} px={'10'} bg={'#fff'}>
      <Pressable
        android_ripple={{
          color: '#ddd',
          radius: 15,
          borderless: true,
          foreground: true,
        }}
        onPress={() => navigation.navigate('Homepage')}>
        <Icon name="home-filled" size={25} color="#900" />
      </Pressable>
      {/* <Pressable
        android_ripple={{
          color: '#ddd',
          radius: 15,
          borderless: true,
          foreground: true,
        }}
        onPress={() => navigation.navigate('Camera')}
        // onPress={() => navigation.navigate('TakeSnap')}
      >
        <Icon name="camera-alt" size={25} color="#900" />
      </Pressable> */}

      <Pressable
        android_ripple={{
          color: '#ddd',
          radius: 15,
          borderless: true,
          foreground: true,
        }}
        onPress={() => navigation.navigate('Story')}>
        <Icon name="rss-feed" size={25} color="#900" />
      </Pressable>
      <Pressable
        android_ripple={{
          color: '#ddd',
          radius: 15,
          borderless: true,
          foreground: true,
        }}
        onPress={() => navigation.navigate('Profilepage')}>
        <MCIcon name="account" size={25} color="#900" />
      </Pressable>
      <Pressable
        android_ripple={{
          color: '#ddd',
          radius: 15,
          borderless: true,
          foreground: true,
        }}
        onPress={() => navigation.navigate('Contact')}>
        <MCIcon name="contacts" size={25} color="#900" />
      </Pressable>
    </HStack>
  );
};

export default TabBar;
