import {useNavigation} from '@react-navigation/native';
import {FlatList, Image, Pressable, Text, View} from 'native-base';
import React, {useCallback, useMemo, useRef} from 'react';
import {Dimensions, StyleSheet, Animated} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Video from 'react-native-video';

const {width, height} = Dimensions.get('screen');

const ITEM_WIDTH = width;
const ITEM_HEIGHT = height * 0.33;

const PostCaurosel = ({post, handelNavigateToMap, index, viewableItemId}) => {
  const scrollX = useRef(new Animated.Value(0)).current;
  const postData = useMemo(
    () => [
      {
        id: 1,
        type: post?.type,
      },
      {
        id: 2,
        type: post?.mapImage ? 'map' : null,
      },
    ],
    [post],
  );

  const paginationDots = useMemo(() => (post?.mapImage ? [1, 2] : [1]), [post]);

  const navigation = useNavigation();

  const iconImg = useMemo(
    () => post?.icId && post?.icId?.toLowerCase(),
    [post?.icId],
  );

  const handelNavigate = useCallback(() => {
    if (post?.type === 'image') {
      navigation.navigate('Media', {type: post?.type, path: post?.imageUrl});
    } else if (post?.type === 'video') {
      navigation.navigate('Media', {type: post?.type, path: post?.videoUrl});
    }
  }, [post?.videoUrl, post?.imageUrl, post?.type]);

  const renderItem = ({item}) => {
    if (item?.type === 'map' && item?.id == 2) {
      return (
        <Pressable onPress={handelNavigateToMap}>
          <Image
            alt="map-image"
            source={{
              uri: post?.mapImage,
            }}
            style={{
              // width: ITEM_WIDTH - 60,
              width: ITEM_WIDTH,
              height: ITEM_HEIGHT,
              resizeMode: 'cover',
            }}
          />
        </Pressable>
      );
    }

    if (post?.type === 'image' && item?.id == 1) {
      return (
        <Pressable onPress={handelNavigate} style={{position: 'relative'}}>
          <Image
            alt="snap"
            style={{
              // width: ITEM_WIDTH - 60,
              width: ITEM_WIDTH,
              height: ITEM_HEIGHT,
              resizeMode: 'cover',
            }}
            source={{uri: post?.imageUrl}}
          />
          <Image
            alt="sos-image"
            source={require(`../assets/images/4waed_logo.png`)}
            style={{
              width: 25,
              height: 25,
              resizeMode: 'contain',
              position: 'absolute',
              bottom: 5,
              right: 10,
            }}
          />
        </Pressable>
      );
    } else if (post?.type === 'video' && item?.id == 1) {
      return (
        <Pressable onPress={handelNavigate}>
          <Video
            alt="snap"
            resizeMode="cover"
            fullscreen={true}
            paused={viewableItemId == index ? false : true}
            style={{
              // width: ITEM_WIDTH - 60,
              width: ITEM_WIDTH,
              height: ITEM_HEIGHT,
            }}
            source={{uri: post?.videoUrl}}
          />
          {viewableItemId != index && (
            <Icon
              name="play-arrow"
              color={'#fff'}
              size={45}
              style={{position: 'absolute', top: '35%', left: '45%'}}
            />
          )}
          <Image
            alt="sos-image"
            source={require(`../assets/images/4waed_logo.png`)}
            style={{
              width: 25,
              height: 25,
              resizeMode: 'contain',
              position: 'absolute',
              bottom: 5,
              right: 10,
            }}
          />
        </Pressable>
      );
    }
  };

  const renderIcons = () => {
    return (
      <Pressable onPress={handelNavigateToMap} position="relative">
        <Image
          alt="map-image"
          source={{
            uri: post?.mapImage,
          }}
          style={{
            // width: ITEM_WIDTH - 60,
            width: ITEM_WIDTH,
            height: ITEM_HEIGHT,
            resizeMode: 'cover',
          }}
        />
        {post?.type === 'sos' && (
          <View position={'absolute'} top={3} left={3}>
            <Image
              alt="sos-image"
              source={require('../assets/images/siren.png')}
              style={{
                width: 50,
                height: 50,
                resizeMode: 'contain',
              }}
            />
          </View>
        )}
        {post?.type === 'icon' && (
          <View position={'absolute'} top={3} left={3}>
            <Image
              alt="poster-image"
              source={
                iconImg === 'rr'
                  ? require(`../assets/images/rr.png`)
                  : iconImg === 'kd'
                  ? require(`../assets/images/kd.png`)
                  : iconImg === 'bd'
                  ? require(`../assets/images/bd.png`)
                  : iconImg === 'rb'
                  ? require(`../assets/images/rb.png`)
                  : iconImg === 'ot'
                  ? require(`../assets/images/ot.png`)
                  : iconImg === 'gs'
                  ? require(`../assets/images/gs.png`)
                  : iconImg === 'fr'
                  ? require(`../assets/images/fr.png`)
                  : iconImg === 'ac' && require(`../assets/images/ac.png`)
              }
              style={{
                width: 50,
                height: 50,
                resizeMode: 'contain',
              }}
            />
          </View>
        )}
      </Pressable>
    );
  };

  return (
    <View>
      {post?.type === 'sos' || post?.type === 'icon' ? (
        renderIcons()
      ) : (
        <View>
          <FlatList
            data={postData}
            renderItem={renderItem}
            horizontal
            contentContainerStyle={{marginBottom: 15}}
            w={'full'}
            pagingEnabled
            showsHorizontalScrollIndicator={false}
          />

          <View style={styles.pagination}>
            {paginationDots?.map((_, i, arr) => {
              const inputRange = [(i - 1) * width, i * width, (i + 1) * width];

              const scale = scrollX.interpolate({
                inputRange,
                outputRange: [0.8, 1.4, 0.8],
                extrapolate: 'clamp',
              });

              return (
                <Animated.View
                  key={i}
                  style={[
                    styles.dot,
                    // {
                    //   transform: [
                    //     {
                    //       scale,
                    //     },
                    //   ],
                    // },
                  ]}
                />
              );
            })}
          </View>
        </View>
      )}
    </View>
  );
};

export default PostCaurosel;

const styles = StyleSheet.create({
  pagination: {
    flexDirection: 'row',
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  dot: {
    width: 10,
    height: 10,
    borderRadius: 10,
    borderColor: '#fff',
    borderWidth: 1,
    backgroundColor: '#900',
    marginHorizontal: 5,
  },
});

// return (
//               <View key={i}>
//                 <Text color={'#900'}>
//                   {i + 1}/{arr.length}
//                 </Text>
//               </View>
//             );
