import {FlatList, Image, Pressable, Text, View} from 'native-base';
import React, {useMemo, useRef} from 'react';
import {StyleSheet} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';

const PostFilterCmp = ({handelFilterPost, activeFilterId}) => {
  const flatRef = useRef(null);
  const filterData = useMemo(
    () => [
      {type: 'All', id: 1},
      {type: 'image', id: 3},
      {type: 'video', id: 4},

      {type: 'sos', id: 2, img: require('../assets/images/siren.png')},
      {
        id: 5,
        icId: 'AC',
        iconType: 'Accident',
        img: require('../assets/images/ac.png'),
      },
      {
        id: 6,
        icId: 'GS',
        iconType: 'Gun Shots',
        img: require('../assets/images/gs.png'),
      },
      {
        id: 7,
        icId: 'RR',
        iconType: 'Robbery',
        img: require('../assets/images/rr.png'),
      },
      {
        id: 8,
        icId: 'FR',
        iconType: 'Fire',
        img: require('../assets/images/fr.png'),
      },
      {
        id: 9,
        icId: 'BD',
        iconType: 'Bad Road',
        img: require('../assets/images/bd.png'),
      },
      {
        id: 10,
        icId: 'KD',
        iconType: 'Kidnap',
        img: require('../assets/images/kd.png'),
      },
      {
        id: 11,
        icId: 'RB',
        iconType: 'Road Block',
        img: require('../assets/images/rb.png'),
      },
      {
        id: 12,
        icId: 'OT',
        iconType: 'Other',
        img: require('../assets/images/ot.png'),
      },
    ],
    [],
  );

  return (
    <View bg="#fff">
      <FlatList
        ref={flatRef}
        data={filterData}
        initialScrollIndex={activeFilterId - 1}
        horizontal
        showsHorizontalScrollIndicator={false}
        onScrollToIndexFailed={() =>
          flatRef.current.scrollToIndex({
            animated: true,
            index: activeFilterId - 1,
          })
        }
        renderItem={({item, index}) => (
          <Pressable
            bg={activeFilterId == item?.id ? 'gray.200' : '#fff'}
            m={'2'}
            borderColor="error.500"
            borderRadius={'md'}
            borderWidth="1"
            p={'2'}
            w={16}
            h={16}
            justifyContent="center"
            alignItems={'center'}
            onPress={() => handelFilterPost(item.type, item.icId, item.id)}>
            {item?.type === 'All' && (
              <MaterialIcons name="rss-feed" size={30} color="#900" />
            )}
            {item?.type === 'image' && (
              <MaterialCommunityIcons name="camera" color={'#900'} size={30} />
            )}
            {item?.type === 'video' && (
              <MaterialCommunityIcons name="video" color={'#900'} size={30} />
            )}
            {item?.type === 'sos' && (
              <Image
                alt="ic-img"
                source={item.img}
                style={{maxWidth: 25, maxHeight: 25, marginBottom: 10}}
                resizeMode={'contain'}
              />
            )}
            {item?.icId && (
              <Image
                alt="ic-img"
                source={item.img}
                style={{maxWidth: 25, maxHeight: 25, marginBottom: 10}}
                resizeMode={'contain'}
              />
            )}
            <Text>{item?.icId ? item?.icId : item?.type}</Text>
          </Pressable>
        )}
        keyExtractor={(item, idx) => item?.id}
        onStartReachedThreshold={10}
        onEndReachedThreshold={10}
        contentContainerStyle={{paddingHorizontal: 10}}
      />
    </View>
  );
};

export default PostFilterCmp;

const styles = StyleSheet.create({});
