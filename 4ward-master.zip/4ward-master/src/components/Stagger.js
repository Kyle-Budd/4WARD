import {StyleSheet} from 'react-native';
import React from 'react';
import {
  Box,
  HStack,
  Icon,
  IconButton,
  Stagger,
  useDisclose,
  View,
} from 'native-base';
import {useNavigation} from '@react-navigation/native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

const StaggerCmp = () => {
  const {isOpen, onToggle} = useDisclose();
  const navigation = useNavigation();
  return (
    <View position={'absolute'} right="7" bottom={'5'}>
      <Box>
        <Stagger
          visible={isOpen}
          initial={{
            opacity: 0,
            scale: 0,
            translateY: 34,
          }}
          animate={{
            translateY: 0,
            scale: 1,
            opacity: 1,
            transition: {
              type: 'spring',
              mass: 0.8,
              stagger: {
                offset: 30,
                reverse: true,
              },
            },
          }}
          exit={{
            translateY: 34,
            scale: 0.5,
            opacity: 0,
            transition: {
              duration: 100,
              stagger: {
                offset: 30,
                reverse: true,
              },
            },
          }}>
          <IconButton
            onPress={() => navigation.navigate('Camera', {type: 'image'})}
            mb="4"
            variant="solid"
            bg="#900"
            colorScheme="yellow"
            borderRadius="full"
            icon={
              <Icon
                as={MaterialCommunityIcons}
                _dark={{
                  color: 'warmGray.50',
                }}
                size="6"
                name="camera"
                color="warmGray.50"
              />
            }
          />
          <IconButton
            onPress={() => navigation.navigate('Camera', {type: 'video'})}
            mb="4"
            variant="solid"
            bg="#900"
            colorScheme="teal"
            borderRadius="full"
            icon={
              <Icon
                as={MaterialCommunityIcons}
                _dark={{
                  color: 'warmGray.50',
                }}
                size="6"
                name="video"
                color="warmGray.50"
              />
            }
          />
        </Stagger>
      </Box>

      <HStack alignItems="center">
        <IconButton
          variant="solid"
          borderRadius="full"
          size="lg"
          onPress={onToggle}
          bg="#900"
          icon={
            <Icon
              as={MaterialCommunityIcons}
              size="6"
              name="plus"
              color="warmGray.50"
              _dark={{
                color: 'warmGray.50',
              }}
            />
          }
        />
      </HStack>
    </View>
  );
};

export default StaggerCmp;

const styles = StyleSheet.create({});
