import {StyleSheet} from 'react-native';
import React, {useCallback, useState} from 'react';
import {FormControl, Input, Text} from 'native-base';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const CustomInput = ({title, plh, onChangeText, value}) => {
  const [isDisabled, setisDisabled] = useState(true);

  const handelSetDiseable = useCallback(() => {
    setisDisabled(p => !p);
  }, []);

  return (
    <FormControl>
      <FormControl.Label fontSize={'lg'} justifyContent={'space-between'}>
        <Text fontSize={'xl'} color="#000">
          {title}
        </Text>
        <Icon
          onPress={handelSetDiseable}
          name="pencil-circle"
          size={35}
          color={'#000'}
        />
      </FormControl.Label>
      <Input
        isDisabled={isDisabled}
        isFocused={!isDisabled}
        placeholder={plh}
        size={'lg'}
        color={'#000'}
        value={value}
        onChangeText={onChangeText}
        selectionColor={'#000'}
      />
    </FormControl>
  );
};

export default CustomInput;

const styles = StyleSheet.create({});
