import React, { useState } from 'react';
import {
    View,
    Button,
    Text,
    Image,
    ImageSourcePropType,
    StyleSheet,
    SafeAreaView,
    TouchableOpacity,
    KeyboardAvoidingView,
    TextInput,
    ScrollView,
    ImageBackground
} from "react-native";
// import { createStackNavigator } from '@react-navigation/stack';
// import LinearGradient from 'react-native-linear-gradient';
import styles, { ThemeColors } from '../styles/main.style';
import pagestyles from '../styles/login.style';

// const Stack = createStackNavigator();

const AllowNotificationScreen = ({ }) => {
    return (
        <>
            <SafeAreaView style={{ flex: 1, backgroundColor: '#000', }}>
                {/* <ScrollView style={pagestyles.scrollView}> */}

                <ImageBackground source={require('../assets/images/loginbg.jpg')} resizeMode={'cover'}
                    style={pagestyles.loginBg}>

                    <View style={pagestyles.mb3}>
                        <Text style={pagestyles.mapTitle1}>Allow Notifications</Text>
                        <Text style={pagestyles.mapsubtxt1}> Get real-time alerts and </Text>
                        <Text style={pagestyles.mapsubtxt1}> real-time road conditions.</Text>
                    </View>

                    <View>



                        <View style={pagestyles.twoBtn}>
                            <TouchableOpacity >
                                <View style={pagestyles.btn3}>
                                    <Text style={pagestyles.signText}> DON'T ALLOW</Text>
                                </View>
                            </TouchableOpacity>

                            <TouchableOpacity >
                                <View style={[pagestyles.btn2,]}>
                                    <Text style={pagestyles.signText}> ALLOW </Text>
                                </View>
                            </TouchableOpacity>
                        </View>


                    </View>

                </ImageBackground>


                {/* </ScrollView> */}
            </SafeAreaView>

        </>
    );
};



export default AllowNotificationScreen;