import React from 'react';
import {
  ImageBackground,
  SafeAreaView,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
// import { createStackNavigator } from '@react-navigation/stack';
// import LinearGradient from 'react-native-linear-gradient';
import pagestyles from '../styles/emergencycontact.style';

// const Stack = createStackNavigator();

const SelectEmergencyContactScreen = ({}) => {
  return (
    <>
      <SafeAreaView style={{flex: 1, backgroundColor: '#000'}}>
        {/* <ScrollView style={pagestyles.scrollView}> */}

        <ImageBackground
          source={require('../assets/images/loginbg.jpg')}
          resizeMode={'cover'}
          style={pagestyles.loginBg}>
          <View style={pagestyles.mb3}>
            <Text style={pagestyles.mapTitle1}>Select Emergency Contacts</Text>
            <Text style={pagestyles.mapsubtxt1}>
              {' '}
              Alert family and friends when you are in danger or alert them of
              different hazardous conditions in your area.
            </Text>
          </View>

          <View>
            <View style={pagestyles.twoBtn}>
              <TouchableOpacity>
                <View style={[pagestyles.btn4]}>
                  <Text style={pagestyles.signText}> CONTINUE </Text>
                </View>
              </TouchableOpacity>
            </View>
          </View>
        </ImageBackground>

        {/* </ScrollView> */}
      </SafeAreaView>
    </>
  );
};

export default SelectEmergencyContactScreen;
