import axios from 'axios';
import {View} from 'native-base';
import React, {useCallback, useRef, useState} from 'react';
import {Dimensions, FlatList, SafeAreaView} from 'react-native';
import Customloader from '../components/loader';
import PostCard from '../components/PostCard';
import PostFilterCmp from '../components/PostFilterCmp';
import StaggerCmp from '../components/Stagger';
import {PostState} from '../context/postState';
import {baseUrl} from '../utils/baseUrl';
import {useInteractionManager} from '../utils/customHooks';

const StoryScreen = () => {
  const {loadScreen} = useInteractionManager();
  const {posts, filterPosts, setfilterPosts, isFilter, setisFilter} =
    PostState();

  const [activeFilterId, setActiveFilterId] = useState(1);
  const [isFilterLoading, setisFilterLoading] = useState(false);
  const [viewableItemId, setViewableItemId] = useState(0);

  const onViewRef = useRef(({viewableItems, changed}) => {
    setViewableItemId(viewableItems[0]?.index);
  });
  const viewConfigRef = useRef({viewAreaCoveragePercentThreshold: 50});

  const handelFilterPost = useCallback(async (type, icId, id) => {
    setActiveFilterId(id);
    if (type === 'All') {
      setisFilter(false);
      return;
    }
    try {
      setisFilterLoading(true);
      const {data} = await axios.post(`${baseUrl}/filterPosts`, {
        type,
        icId,
      });
      setfilterPosts(data?.posts);
      setisFilter(true);
    } catch (error) {
      console.error(error);
    } finally {
      setisFilterLoading(false);
    }
  }, []);

  if (loadScreen || isFilterLoading) {
    return <Customloader color={'#900'} />;
  }

  return (
    <>
      <SafeAreaView
        style={{
          flex: 1,
          backgroundColor: '#fff',
          height: Dimensions.get('window').height,
        }}>
        {/* <CustomHeader title="Feed" /> */}

        <PostFilterCmp
          handelFilterPost={handelFilterPost}
          activeFilterId={activeFilterId}
        />
        {isFilter ? (
          <>
            {filterPosts && filterPosts?.length > 0 && (
              <View style={{flex: 1, backgroundColor: '#fff'}}>
                <FlatList
                  data={filterPosts}
                  renderItem={({item, index}) => (
                    <PostCard
                      {...item}
                      viewableItemId={viewableItemId}
                      index={index}
                      isFilter
                    />
                  )}
                  keyExtractor={(item, idx) => item?.id}
                  onViewableItemsChanged={onViewRef.current}
                  viewabilityConfig={viewConfigRef.current}
                />
              </View>
            )}
          </>
        ) : (
          <>
            {posts && posts?.length > 0 && (
              <View style={{flex: 1, backgroundColor: '#fff'}}>
                <FlatList
                  data={posts}
                  renderItem={({item, index}) => (
                    <PostCard
                      {...item}
                      viewableItemId={viewableItemId}
                      index={index}
                    />
                  )}
                  keyExtractor={(item, idx) => item?.id}
                  onViewableItemsChanged={onViewRef.current}
                  viewabilityConfig={viewConfigRef.current}
                />
              </View>
            )}
          </>
        )}

        <StaggerCmp />
      </SafeAreaView>
    </>
  );
};

export default StoryScreen;

// item?.date?.toDate() ||

// const [loading, setloading] = useState(true);
// const [ploading, setploading] = useState(false);
// const [posts, setPosts] = useState([]);
// const [lastDocument, setLastDocument] = useState();

// useFocusEffect(
//   useCallback(() => {
//     let unsubscribe;
//     try {
//       unsubscribe = firestore()
//         .collection('posts')
//         .orderBy('date', 'desc')
//         .limit(50)
//         .onSnapshot(
//           async querySnapshot => {
//             // setLastDocument(
//             //   querySnapshot.docs[querySnapshot.docs.length - 1],
//             // );
//             console.log('Total posts: ', querySnapshot.size);

//             const userProfiles = await Promise.all(
//               querySnapshot.docs.map(documentSnapshot =>
//                 firestore()
//                   .collection('users')
//                   .doc(documentSnapshot.data().userId)
//                   .get(),
//               ),
//             );
//             setPosts(p => [
//               // ...p,
//               ...querySnapshot.docs.map(d => ({
//                 ...d.data(),
//                 user: userProfiles
//                   ?.find(u => u.id === d.data().userId)
//                   ?.data(),
//               })),
//             ]);
//             setloading(false);
//           },
//           err => {
//             alert('Something went wrong');
//             console.log(`Encountered error: ${err}`);
//             setloading(false);
//           },
//         );
//     } catch (error) {
//       console.error(error);
//       alert('faild to fetch posts');
//     }

//     return () => unsubscribe();
//   }, []),
// );

//  const loadData = useCallback(async () => {
//     if (lastDocument !== undefined) {
//       console.log('LOAD');
//       setploading(true);
//       await firestore()
//         .collection('posts')
//         .orderBy('date', 'desc')
//         .startAfter(lastDocument)
//         .limit(10)
//         .get()
//         .then(async querySnapshot => {
//           setLastDocument(querySnapshot.docs[querySnapshot.docs.length - 1]);
//           const userProfilePics = await Promise.all(
//             querySnapshot.docs.map(documentSnapshot =>
//               firestore()
//                 .collection('users')
//                 .doc(documentSnapshot.data().userId)
//                 .get(),
//             ),
//           );
//           setPosts(p => [
//             ...p,
//             ...querySnapshot.docs.map(d => ({
//               ...d.data(),
//               user: userProfilePics
//                 ?.find(u => u.id === d.data().userId)
//                 ?.data(),
//             })),
//           ]);
//         });

//       setploading(false);
//     }
//   }, [lastDocument]);

{
  /* {lastDocument && (
          <Button
            disabled={ploading}
            mt="2"
            mx={'auto'}
            bg={'#900'}
            onPress={loadData}
            w="1/2"
            justifyContent={'center'}
            alignItems="center">
            <Text color={'#fff'}>{ploading ? 'loading...' : 'Load more'}</Text>
          </Button>
        )} */
}

// useEffect(() => {
//   (async () => {
//     try {
//       const doc = await firestore()
//         .collection('posts')
//         .orderBy('date', 'desc')
//         .get();
//       console.log(doc.docs);
//       setPosts(doc.docs);
//     } catch (error) {
//       console.error(error);
//       alert('Something went erong');
//     } finally {
//       setloading(false);
//     }
//   })();
// }, []);
