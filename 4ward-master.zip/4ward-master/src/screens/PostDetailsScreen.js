import axios from 'axios';
import {
  HStack,
  Image,
  Input,
  ScrollView,
  Text,
  View,
  Pressable,
  VStack,
  Badge,
  KeyboardAvoidingView,
  Spinner,
  StatusBar,
} from 'native-base';
import Icon from 'react-native-vector-icons/MaterialIcons';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import React, {useCallback, useEffect, useMemo, useState} from 'react';
import {Dimensions, Keyboard, StyleSheet} from 'react-native';
import Video from 'react-native-video';
import CustomHeader from '../components/CustomHeader';
import Customloader from '../components/loader';
import PostActivity from '../components/PostActivity';
import {baseUrl} from '../utils/baseUrl';
import {useInteractionManager} from '../utils/customHooks';
import {AuthState} from '../context/authState';
import uuid from 'react-native-uuid';
import DateComp from '../components/DateComp';
import {useRef} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';
import ViewShot from 'react-native-view-shot';

const {width, height} = Dimensions.get('screen');

const ITEM_WIDTH = width;
const ITEM_HEIGHT = height * 0.33;

function calcCrow(lat1, lon1, lat2, lon2) {
  var R = 6371; // km
  var dLat = toRad(lat2 - lat1);
  var dLon = toRad(lon2 - lon1);
  var lat1 = toRad(lat1);
  var lat2 = toRad(lat2);

  var a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2);
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  var d = R * c;
  return d;
}

function toRad(Value) {
  return (Value * Math.PI) / 180;
}

const BadgeItem = ({cnt}) => (
  <Badge colorScheme="error" alignSelf="center" variant={'solid'} mr="auto">
    {cnt}
  </Badge>
);

const PostDetailsScreen = ({navigation, route}) => {
  const {loadScreen} = useInteractionManager();
  const {authUser, user} = AuthState();
  const [post, setPost] = useState(null);
  const [comments, setComments] = useState(null);
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [addComLoading, setAddComLoading] = useState(false);
  const scrollRef = useRef(null);
  const viewShotRef = useRef(null);

  const distance = useMemo(() => {
    const userLat = user?.location?.location?.latitude;
    const userLon = user?.location?.location?.longitude;
    const postLat =
      post?.coordinates && parseFloat(post?.coordinates?._latitude);

    const postLon =
      post?.coordinates && parseFloat(post?.coordinates?._longitude);

    return calcCrow(userLat, userLon, postLat, postLon);
  }, [user, post]);

  const iconImg = useMemo(
    () => post?.icId && post?.icId?.toLowerCase(),
    [post?.icId],
  );

  const isLiked = useMemo(
    () => post?.likes?.includes(authUser.uid),
    [post, authUser.uid],
  );
  const isDisLiked = useMemo(
    () => post?.disLikes?.includes(authUser.uid),
    [post, authUser.uid],
  );

  useEffect(() => {
    (async () => {
      try {
        const {data} = await axios.post(`${baseUrl}/getPostDetails`, {
          postId: route?.params?.postId,
        });
        if (data?.msg === 'success') {
          setPost(data?.data?.post);
          setComments(data?.data?.comments);
        }
      } catch (error) {
        console.error(error);
        alert('something went wrong!');
      } finally {
        setIsLoading(false);
      }
    })();
  }, [route?.params?.postId]);

  console.log('---postdata---', post, '---comments---', comments);

  const handelLikeUnlike = useCallback(async () => {
    try {
      const likeData = {
        postId: route?.params?.postId,
        userId: authUser.uid,
        type: isLiked ? 2 : 1,
      };
      const {data} = await axios.post(`${baseUrl}/likeUnlikePost`, likeData);
      console.log('---like-data---', data);
      if (data?.msg === 'success') {
        const {data} = await axios.post(`${baseUrl}/getPostDetails`, {
          postId: route?.params?.postId,
        });
        if (data?.msg === 'success') {
          setPost(data?.data?.post);
        }
        // setPost(p => ({
        //   ...p,
        //   likes: !isLiked
        //     ? p?.likes
        //       ? [...p.likes, authUser.uid]
        //       : [authUser.uid]
        //     : p?.likes && p.likes.filter(pl => pl !== authUser.uid),
        // }));
      }
    } catch (error) {
      console.error(error);
      alert('something went wrong!');
    }
  }, [isLiked, route?.params?.postId, authUser.uid]);

  const handelDisLike = useCallback(async () => {
    console.log('---runn---');
    try {
      const disLikeData = {
        postId: route?.params?.postId,
        userId: authUser.uid,
        type: isDisLiked ? 2 : 1,
      };
      const {data} = await axios.post(`${baseUrl}/disLikePost`, disLikeData);
      console.log('---dislike-data---', data);
      if (data?.msg === 'success') {
        const {data} = await axios.post(`${baseUrl}/getPostDetails`, {
          postId: route?.params?.postId,
        });
        if (data?.msg === 'success') {
          setPost(data?.data?.post);
        }
        // setPost(p => ({
        //   ...p,
        //   disLikes: !isDisLiked
        //     ? p?.disLikes
        //       ? [...p.disLikes, authUser.uid]
        //       : [authUser.uid]
        //     : p?.disLikes && p.disLikes.filter(pl => pl !== authUser.uid),
        // }));
      }
    } catch (error) {
      console.error(error);
      alert('something went wrong!');
    }
  }, [isDisLiked, route?.params?.postId, authUser.uid]);

  const addComments = useCallback(async () => {
    setAddComLoading(true);
    try {
      const newComment = {
        postId: route?.params?.postId,
        userId: authUser.uid,
        commentId: uuid.v4(),
        message,
      };
      const {data} = await axios.post(`${baseUrl}/addComment`, newComment);
      console.log('---com-data---', data);
      if (data?.msg === 'success') {
        setComments([data?.data, ...comments]);
      }
    } catch (error) {
      console.error(error);
      alert('something went wrong');
    } finally {
      setAddComLoading(false);
      setMessage('');
      Keyboard.dismiss();
    }
  }, [route?.params?.postId, authUser.uid, message]);

  const handelNavigateShare = useCallback(() => {
    viewShotRef.current.capture().then(uri => {
      console.log('do something with ', uri);
      navigation.navigate('Share', {
        data: {
          shareUri: uri,
          // imageUrl: post?.imageUrl,
          // videoUrl: post?.videoUrl,
        },
      });
    });
  }, [post]);

  const handelNavigate = useCallback(() => {
    if (post?.type === 'image') {
      navigation.navigate('Media', {type: post?.type, path: post?.imageUrl});
    } else if (post?.type === 'video') {
      navigation.navigate('Media', {type: post?.type, path: post?.videoUrl});
    }
  }, [post?.videoUrl, post?.imageUrl, post?.type]);

  const handelNavigateToMap = useCallback(() => {
    if (post?.location) {
      navigation.navigate('Homepage', {
        coords: {
          lat: post?.location?.location?.latitude,
          lon: post?.location?.location?.longitude,
        },
      });
    } else if (post?.center) {
      navigation.navigate('Homepage', {
        coords: {
          lat: parseFloat(post?.center?._latitude),
          lon: parseFloat(post?.center?._longitude),
        },
      });
    }
  }, [post]);

  const renderItem = () => {
    if (post?.type === 'image') {
      return (
        <Pressable onPress={handelNavigate} style={{position: 'relative'}}>
          <Image
            alt="snap"
            style={{
              // width: ITEM_WIDTH - 60,
              width: ITEM_WIDTH,
              height: ITEM_HEIGHT,
              resizeMode: 'cover',
            }}
            source={{uri: post?.imageUrl}}
          />
          <Image
            alt="sos-image"
            source={require(`../assets/images/4waed_logo.png`)}
            style={{
              width: 25,
              height: 25,
              resizeMode: 'contain',
              position: 'absolute',
              bottom: 5,
              right: 10,
            }}
          />
        </Pressable>
      );
    } else if (post?.type === 'video') {
      return (
        <Pressable onPress={handelNavigate} position="relative">
          <Video
            alt="snap"
            resizeMode="cover"
            fullscreen={true}
            paused={false}
            style={{
              width: ITEM_WIDTH,
              height: ITEM_HEIGHT,
            }}
            source={{uri: post?.videoUrl}}
          />
          {/* <Icon
            name="play-arrow"
            color={'#fff'}
            size={45}
            style={{position: 'absolute', top: '45%', left: '45%'}}
          /> */}
          <Image
            alt="sos-image"
            source={require(`../assets/images/4waed_logo.png`)}
            style={{
              width: 25,
              height: 25,
              resizeMode: 'contain',
              position: 'absolute',
              bottom: 5,
              right: 10,
            }}
          />
        </Pressable>
      );
    }
  };

  const renderIcons = () => {
    return (
      <Pressable onPress={handelNavigateToMap} position="relative">
        <Image
          alt="map-image"
          source={{
            uri: post?.mapImage,
          }}
          style={{
            // width: ITEM_WIDTH - 60,
            width: ITEM_WIDTH,
            height: ITEM_HEIGHT,
            resizeMode: 'cover',
          }}
        />
        {post?.type === 'sos' && (
          <View position={'absolute'} top={3} left={3}>
            <Image
              alt="sos-image"
              source={require('../assets/images/siren.png')}
              style={{
                width: 50,
                height: 50,
                resizeMode: 'contain',
              }}
            />
          </View>
        )}
        {post?.type === 'icon' && (
          <View position={'absolute'} top={3} left={3}>
            <Image
              alt="poster-image"
              source={
                iconImg === 'rr'
                  ? require(`../assets/images/rr.png`)
                  : iconImg === 'kd'
                  ? require(`../assets/images/kd.png`)
                  : iconImg === 'bd'
                  ? require(`../assets/images/bd.png`)
                  : iconImg === 'rb'
                  ? require(`../assets/images/rb.png`)
                  : iconImg === 'ot'
                  ? require(`../assets/images/ot.png`)
                  : iconImg === 'gs'
                  ? require(`../assets/images/gs.png`)
                  : iconImg === 'fr'
                  ? require(`../assets/images/fr.png`)
                  : iconImg === 'ac' && require(`../assets/images/ac.png`)
              }
              style={{
                width: 50,
                height: 50,
                resizeMode: 'contain',
              }}
            />
          </View>
        )}
      </Pressable>
    );
  };

  const onCapture = useCallback(uri => {
    console.log('do something with ', uri);
  }, []);

  if (loadScreen || isLoading) {
    return <Customloader />;
  }

  return (
    <KeyboardAvoidingView behavior="height" flex={1} bg="#fff">
      <SafeAreaView style={{flex: 1}}>
        <CustomHeader title={'Post details'} />
        {post && (
          <ScrollView ref={scrollRef}>
            <ViewShot
              style={{backgroundColor: '#fff'}}
              ref={viewShotRef}
              // onCapture={onCapture}
              // captureMode="mount"
            >
              {post?.type === 'sos' || post?.type === 'icon'
                ? renderIcons()
                : renderItem()}
              <HStack p={'4'} pb="0" space="4" alignItems={'center'}>
                {post?.identity ? (
                  post.user?.profilePic ? (
                    <Image
                      src={post.user?.profilePic}
                      w={58}
                      h={58}
                      borderRadius="full"
                      resizeMode="contain"
                    />
                  ) : (
                    <Icon name="account-circle" size={40} color="#aaa" />
                  )
                ) : (
                  <Image
                    alt="sos-image"
                    source={require(`../assets/images/4waed_logo.png`)}
                    style={{
                      width: 40,
                      height: 40,
                      resizeMode: 'contain',
                    }}
                  />
                )}
                {post?.identity ? (
                  post.user?.userName ? (
                    <Text fontWeight={'bold'} fontSize="lg">
                      {post.user?.userName}
                    </Text>
                  ) : (
                    <Text fontWeight={'bold'} fontSize="lg">
                      User ${post?.userId.slice(-5)}
                    </Text>
                  )
                ) : (
                  <Text fontWeight={'bold'} fontSize="lg">
                    4WARD user
                  </Text>
                )}
              </HStack>

              <VStack p={'4'} mt="2" space={'4'}>
                {post?.type === 'image' && <BadgeItem cnt={'SNAP SHOT'} />}
                {post?.type === 'video' && <BadgeItem cnt={'LIVE RECORD'} />}
                {post?.type === 'sos' && <BadgeItem cnt={'SAVE OUR SOULS'} />}
                {post?.iconType && (
                  <BadgeItem cnt={post?.iconType.toUpperCase()} />
                )}
                {post && post?.description && (
                  <Text fontSize={'md'} fontWeight="medium">
                    {post?.description}
                  </Text>
                )}
                {post?.location && (
                  <Pressable onPress={handelNavigateToMap}>
                    <HStack space={'2'} justifyContent="center">
                      <Icon name="location-on" size={20} color="#aaa" />
                      <Text
                        style={{
                          flex: 1,
                          flexWrap: 'wrap',
                          color: '#000',
                          // marginBottom: 10,
                        }}>
                        {post?.location?.address}
                      </Text>
                    </HStack>
                  </Pressable>
                )}
                {post?.address && (
                  <Pressable onPress={handelNavigateToMap}>
                    <HStack space={'2'} justifyContent="center">
                      <Icon name="location-on" size={20} color="#aaa" />
                      <Text
                        style={{
                          flex: 1,
                          flexWrap: 'wrap',
                          color: '#000',
                        }}>
                        {post?.address}
                      </Text>
                    </HStack>
                  </Pressable>
                )}
                {post?.coordinates && (
                  <HStack space={'2'} justifyContent="center">
                    <MaterialCommunityIcons
                      name="signal-distance-variant"
                      size={20}
                      color="#aaa"
                    />

                    <Text style={[{flex: 1, flexWrap: 'wrap', color: '#000'}]}>
                      {distance.toFixed(2)}
                      <Text> KM Away</Text>
                    </Text>
                  </HStack>
                )}
                <>
                  <DateComp time={post?.date?._seconds} />
                </>
              </VStack>

              <View pt="2">
                <PostActivity
                  handelNavigateShare={handelNavigateShare}
                  handelLikeUnlike={handelLikeUnlike}
                  handelDisLike={handelDisLike}
                  isLiked={isLiked}
                  isDisLiked={isDisLiked}
                  likes={post?.likes?.length || 0}
                  disLikes={post?.disLikes?.length || 0}
                  comments={comments?.length || 0}
                  showShare={true}
                  // showShare={post?.type === 'image' || post?.type === 'video'}
                />
              </View>
              <View mb={'2'}>
                {(post.type === 'image' || post.type === 'video') &&
                  renderIcons()}
              </View>
            </ViewShot>

            {comments.length > 0 && (
              <VStack>
                <View py="2">
                  <Text
                    fontSize={'md'}
                    fontWeight="medium"
                    py="2"
                    px="4"
                    mb={'2'}
                    bg={'error.100'}>
                    Comments
                  </Text>
                </View>
                {comments.length > 0 && (
                  <VStack pb="4" space="2">
                    {comments.map((com, id) => (
                      <VStack key={id} space="2" px={'4'} py="2" bg="error.50">
                        <HStack justifyContent={'space-between'}>
                          <HStack space={'2'} alignItems="center">
                            {com.user?.profilePic ? (
                              <Image
                                src={com.user?.profilePic}
                                w={'8'}
                                h={'8'}
                                borderRadius="full"
                                resizeMode="contain"
                              />
                            ) : (
                              <Icon
                                name="account-circle"
                                size={30}
                                color="#aaa"
                              />
                            )}
                            <Text fontWeight={'bold'} fontSize="md">
                              {com.user?.userName
                                ? com.user?.userName
                                : `User ${com?.userId.slice(-5)}`}
                            </Text>
                          </HStack>
                          <DateComp time={com?.date?._seconds} com />
                        </HStack>
                        <Text fontWeight={'normal'} fontSize="lg">
                          {com?.message}
                        </Text>
                      </VStack>
                    ))}
                  </VStack>
                )}
              </VStack>
            )}
          </ScrollView>
        )}

        <HStack p="4" bg="#fff" w={'full'} space="4" alignItems={'center'}>
          <Input
            placeholder="comments here..."
            w={'90%'}
            size="lg"
            multiline
            value={message}
            onChangeText={setMessage}
            keyboardType="default"
            color={'#900'}
            placeholderTextColor={'#900'}
            onFocus={() => scrollRef.current.scrollToEnd()}
          />
          {addComLoading ? (
            <Spinner color={'#900'} size={'sm'} />
          ) : (
            <Pressable
              disabled={addComLoading}
              isDisabled={addComLoading}
              onPress={addComments}>
              <Icon name="send" size={30} color="#900" />
            </Pressable>
          )}
        </HStack>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};

export default PostDetailsScreen;

const styles = StyleSheet.create({});
