import React, {useCallback, useMemo} from 'react';
import {
  Image,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Pressable,
  Dimensions,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Video from 'react-native-video';
import Customloader from '../components/loader';
import {useInteractionManager} from '../utils/customHooks';

export function MediaPage({navigation, route}) {
  const {loadScreen} = useInteractionManager();

  const {path, type} = route.params;

  const source = useMemo(() => ({uri: path}), [path]);

  const handelBuffer = useCallback(() => {
    alert('buffering...');
  }, []);

  if (loadScreen) {
    return <Customloader />;
  }

  return (
    <SafeAreaView
      style={{
        // position: 'relative',
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
      }}>
      <Pressable
        style={[StyleSheet.absoluteFill, {backgroundColor: '#000'}]}
        onPress={navigation.goBack}
      />
      <TouchableOpacity style={styles.closeButton} onPress={navigation.goBack}>
        <Icon name="close" color={'#fff'} size={30} />
      </TouchableOpacity>
      {type === 'image' && (
        <Image
          source={source}
          style={{
            width: Dimensions.get('window').width,
            height: Dimensions.get('window').height * 0.85,
          }}
          resizeMode="contain"
        />
      )}
      {type === 'video' && (
        <Video
          source={source}
          style={{
            width: Dimensions.get('window').width,
            height: Dimensions.get('window').height * 0.85,
          }}
          resizeMode="contain"
          controls={true}
          // onBuffer={handelBuffer}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
  },
  closeButton: {
    // position: 'absolute',
    // top: 10,
    // right: 10,
    marginLeft: 'auto',
    width: 40,
    height: 40,
  },
  icon: {
    textShadowColor: 'black',
    textShadowOffset: {
      height: 0,
      width: 0,
    },
    textShadowRadius: 1,
  },
});
