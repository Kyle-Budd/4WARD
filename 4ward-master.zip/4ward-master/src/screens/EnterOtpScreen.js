import auth from '@react-native-firebase/auth';
import firestore from '@react-native-firebase/firestore';
import React, {useCallback, useState} from 'react';
import {
  KeyboardAvoidingView,
  ScrollView,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import Customloader from '../components/loader';
import {AuthState} from '../context/authState';
import pagestyles from '../styles/setupprofile.style';
import {useInteractionManager} from '../utils/customHooks';

const EnterOtpScreen = ({navigation}) => {
  const {loadScreen} = useInteractionManager();

  const {
    confirm,
    setConfirm,
    phoneNumber,
    countryCode,
    myLocation,
    deviceToken,
    setUserBan,
  } = AuthState();

  const [code, setCode] = useState(null);

  const handelConfirmCode = useCallback(async () => {
    try {
      await confirm.confirm(code);

      if (!myLocation) {
        alert('Location not found');
        return;
      }

      auth().onAuthStateChanged(async user => {
        const userRef = firestore().collection('users');

        const whereUser = (await userRef.where('id', '==', user.uid).get())
          .docs;
        if (whereUser.length == 0) {
          // user not exists
          await userRef.doc(user.uid).set({
            id: user.uid,
            phone: user.phoneNumber.slice(1),
            location: myLocation,
            token: deviceToken,
          });
        } else {
          //   user exists
          console.log('-----whereUser-----', whereUser[0]._data?.banStatus);
          if (whereUser[0]._data?.banStatus) {
            alert('Your account is deactivated');
            setUserBan(whereUser[0]._data.banStatus);
            return;
          } else {
            setUserBan(false);
            await userRef.doc(user.uid).update({
              id: user.uid,
              phone: user.phoneNumber.slice(1),
              location: myLocation,
              token: deviceToken,
            });
          }
        }
      });
    } catch (error) {
      alert(error);
      console.error('----error---', error);
    } finally {
      setCode(null);
      // setIsUserExists(false);
    }
  }, [code, myLocation, deviceToken]);

  const handelResendCode = useCallback(async () => {
    try {
      const confirmation = await auth().signInWithPhoneNumber(
        `+${countryCode}${phoneNumber}`,
      );
      setConfirm(confirmation);
      alert('Successfully send code');
      // console.log(phoneNumber);
    } catch (error) {
      console.error(error);
      alert('Something went wrong');
    }
  }, [phoneNumber, countryCode]);

  if (loadScreen) {
    return <Customloader />;
  }

  return (
    <>
      <KeyboardAvoidingView
        // behavior="height"
        style={{flex: 1, backgroundColor: '#000'}}>
        <ScrollView style={pagestyles.scrollView}>
          <View style={pagestyles.contentContainer}>
            <View>
              <Text style={pagestyles.title1}>We just sent a code to</Text>
              <Text style={pagestyles.subTxt}>
                {countryCode}
                {phoneNumber}
              </Text>
            </View>

            <View style={pagestyles.formsetup}>
              <View style={{paddingBottom: 20}}>
                <Text style={pagestyles.lableTitle}>*ENTER CODE</Text>
                <TextInput
                  style={{
                    fontSize: 18,
                    textAlign: 'left',
                    backgroundColor: '#7D797A',
                    borderRadius: 10,
                    padding: 13,
                    // textAlign: 'left',
                  }}
                  placeholder=""
                  // underlineColorAndroid="transparent"
                  placeholderTextColor="#fff"
                  color="#fff"
                  value={code}
                  onChangeText={setCode}
                  secureTextEntry={false}
                  keyboardType={'numeric'}
                />
              </View>

              <TouchableOpacity
                style={{marginBottom: 20}}
                onPress={handelConfirmCode}>
                <View style={pagestyles.btn2}>
                  <Text style={pagestyles.signText}> VERIFY CODE </Text>
                </View>
              </TouchableOpacity>

              <View style={pagestyles.terms}>
                <Text style={[pagestyles.whitClr]}> Haven't receive it? </Text>
                <TouchableOpacity onPress={handelResendCode}>
                  <Text style={pagestyles.redColor}>Resend</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </>
  );
};

export default EnterOtpScreen;

//  userRef
//           .doc(user.uid)
//           .get()
//           .then(async docSnapShot => {
//             console.log('---existing---', docSnapShot);
//             if (!docSnapShot?.exists) {
//               console.log('---user not exist---');

//               userRef
//                 .doc(user.uid)
//                 .set({
//                   id: user.uid,
//                   phone: user.phoneNumber.slice(1),
//                   location: myLocation,
//                   token,
//                 })
//                 .then(() => console.log('---userset---'))
//                 .catch(e => console.log('----user-not-set----', e));
//             } else {
//               console.log('---user exists---');

//               await userRef.doc(user.uid).update({
//                 id: user.uid,
//                 phone: user.phoneNumber.slice(1),
//                 location: myLocation,
//                 token,
//               });
//             }
//           })
//           .catch(e => {
//             console.error('---error---', e);
//           });
