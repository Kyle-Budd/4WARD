import {HStack, Text, View} from 'native-base';
import React, {useEffect} from 'react';
import {PermissionsAndroid, SafeAreaView, ScrollView} from 'react-native';
import Contacts from 'react-native-contacts';
import Customloader from '../components/loader';
import {AuthState} from '../context/authState';
import pagestyles from '../styles/contact.style';
import {useInteractionManager} from '../utils/customHooks';

const ContactScreen = ({}) => {
  const {loadScreen} = useInteractionManager();

  const {contacts, loadContacts} = AuthState();
  // const navigation = useNavigation();

  console.log('---contacts---', contacts);

  // PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.READ_CONTACTS)
  //   .then(async () => {
  //     loadContacts();
  //   })
  //   .catch(() => {
  //     alert('Please allow contacts permission');
  //   });

  useEffect(() => {
    Contacts.checkPermission().then(permission => {
      // Contacts.PERMISSION_AUTHORIZED || Contacts.PERMISSION_UNDEFINED || Contacts.PERMISSION_DENIED
      if (permission === 'undefined') {
        Contacts.requestPermission().then(permission => {
          // alert('Permission not found');
          console.log('contsct permission undefined');
        });
      }
      if (permission === 'authorized') {
        //   alert('Permission allowed');
        console.log('contsct permission allowed');
        loadContacts();
      }
      if (permission === 'denied') {
        alert('Please allow contact permission');
      }
    });
  }, []);

  if (loadScreen) {
    return <Customloader />;
  }

  return (
    <>
      <SafeAreaView style={{flex: 1, backgroundColor: '#fff'}}>
        <ScrollView style={pagestyles.scrollView}>
          <View style={pagestyles.container}>
            <HStack
              style={pagestyles.headerSec}
              space="4"
              alignItems={'center'}>
              {/* <Pressable onPress={() => navigation.goBack()}>
                <MCIcon name="keyboard-backspace" size={25} color="#000" />
              </Pressable> */}
              <Text fontWeight={'bold'} fontSize="lg" color={'#000'}>
                My Contacts
              </Text>
              {/* <Image
                source={require('../assets/images/user1.png')}
                style={pagestyles.user}
              /> */}
            </HStack>
            {contacts &&
              contacts.length > 0 &&
              contacts.map((c, i) => (
                <View
                  key={i}
                  style={[
                    pagestyles.contactList,
                    {justifyContent: 'space-between'},
                  ]}>
                  <View style={pagestyles.leftTxt} flex={3}>
                    <Text style={pagestyles.titleSec}>{c?.givenName}</Text>
                    <Text style={pagestyles.subList}>
                      {c?.phoneNumbers[0]?.number}
                      {/* {JSON.stringify(c.phoneNumbers)} */}
                    </Text>
                  </View>

                  {/* <View style={pagestyles.btnSec} flex={1}>
                    <TouchableOpacity>
                      <Text style={pagestyles.inviteSec}>INVITE</Text>
                    </TouchableOpacity>
                  </View> */}
                </View>
              ))}
          </View>
        </ScrollView>
      </SafeAreaView>
    </>
  );
};

export default ContactScreen;
