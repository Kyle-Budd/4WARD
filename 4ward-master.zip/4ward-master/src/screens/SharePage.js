import {
  Button,
  HStack,
  Image,
  Input,
  Pressable,
  Text,
  View,
  VStack,
} from 'native-base';
import React, {useCallback, useMemo, useState} from 'react';
import {Dimensions, KeyboardAvoidingView, StyleSheet} from 'react-native';
import Share from 'react-native-share';
import RNFetchBlob from 'rn-fetch-blob';

const SharePage = ({navigation, route}) => {
  const {data} = route?.params;

  // console.log('-----post-data-----', data);

  const [message, setmessage] = useState('');
  const [loading, setLoading] = useState(false);

  const handelShare = useCallback(() => {
    if (data?.shareUri) {
      setLoading(true);
      try {
        let imgdata = '';
        RNFetchBlob.fs
          .readStream(
            // file path
            data?.shareUri,
            // encoding, should be one of `base64`, `utf8`, `ascii`
            'base64',
            // (optional) buffer size, default to 4096 (4095 for BASE64 encoded data)
            // when reading file in BASE64 encoding, buffer size must be multiples of 3.
            4095,
          )
          .then(ifstream => {
            ifstream.open();
            ifstream.onData(chunk => {
              // when encoding is `ascii`, chunk will be an array contains numbers
              // otherwise it will be a string
              imgdata += chunk;
            });
            ifstream.onError(err => {
              console.log('oops', err);
            });
            ifstream.onEnd(async () => {
              // <Image source={{uri: 'data:image/png,base64' + imgdata}} />;
              const base64Str = 'data:image/webp;base64,' + imgdata;
              console.log('---base64Str---', base64Str);
              const shareOptions = {
                title: 'Share Via',
                message,
                url: base64Str,
              };

              await Share.open(shareOptions);
            });
          });
      } catch (error) {
        console.error('error---', error);
      } finally {
        setLoading(false);
      }
    }
  }, [data?.shareUri]);

  // const handelShare = useCallback(async () => {
  //   if (data?.imageUrl || data?.videoUrl ) {
  //     try {
  //       setLoading(true);
  //       let base64Str;

  //       const res = await RNFetchBlob.fetch(
  //         'GET',
  //         data?.imageUrl ? data?.imageUrl : data?.videoUrl,
  //       );

  //       let status = res.info().status;
  //       console.log('---share---');

  //       if (status == 200) {
  //         base64Str = res.base64();
  //       } else {
  //         console.log('------error----');
  //         alert('something went wrong');
  //       }
  //       const shareOptions = {
  //         title: 'Share Via',
  //         message,
  //         url: data?.videoUrl
  //           ? `data:video/mp4;base64,${base64Str}`
  //           : `data:image/webp;base64,${base64Str}`,
  //       };

  //       await Share.open(shareOptions);
  //     } catch (error) {
  //       console.error(error);
  //       // alert('Can not share file');
  //     } finally {
  //       setLoading(false);
  //       navigation.goBack();
  //     }
  //   }
  // }, [data, message]);

  return (
    <KeyboardAvoidingView
      behavior="height"
      style={{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
      }}>
      <Pressable
        style={[
          StyleSheet.absoluteFill,
          {backgroundColor: 'rgba(0, 0, 0, 0.5)'},
        ]}
        onPress={navigation.goBack}
      />
      <VStack
        bg={'#fff'}
        style={{
          padding: 25,
          width: '100%',
          position: 'absolute',
          // top: Dimensions.get('screen').height * 0.3,
        }}>
        <VStack w={'full'} mt={5} space={'4'}>
          {data?.shareUri && (
            <View flex={1} alignItems="center">
              <Image
                alt="share-img"
                source={{uri: data?.shareUri}}
                resizeMode="contain"
                h={'lg'}
                w={'full'}
              />
            </View>
          )}
          {/* <HStack alignItems={'center'} justifyContent={'space-between'}>
            <Text fontSize={20} fontWeight={'800'}>
              Send message (optional)
            </Text>
          </HStack>
          <Input onChangeText={setmessage} value={message} /> */}

          <Button
            bg={'#900'}
            onPress={handelShare}
            disabled={loading}
            isLoading={loading}>
            <Text color={'#fff'} fontSize={16} fontWeight={'800'}>
              Share
            </Text>
          </Button>
        </VStack>
      </VStack>
    </KeyboardAvoidingView>
  );
};

export default SharePage;

const styles = StyleSheet.create({});

// const imgExt = useMemo(
//   () =>
//     data?.imageUrl &&
//     data?.imageUrl
//       .split('post-images')[1]
//       ?.split('?')[0]
//       ?.split('.')[1]
//       ?.trim(),
//   [data?.imageUrl],
// );
