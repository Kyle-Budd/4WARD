import auth from '@react-native-firebase/auth';
import firestore from '@react-native-firebase/firestore';
import {useFocusEffect} from '@react-navigation/native';
import {
  HStack,
  KeyboardAvoidingView,
  Menu,
  Pressable,
  ScrollView,
  Slider,
  Switch,
  Text,
  useToast,
  View,
  VStack,
} from 'native-base';
import React, {useCallback, useState} from 'react';
import {SafeAreaView, StyleSheet, TouchableOpacity} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import CustomInput from '../components/CustomInput';
import Customloader from '../components/loader';
import ProfileImage from '../components/ProfileImage';
import {AuthState} from '../context/authState';
import {useInteractionManager} from '../utils/customHooks';
const ProfileScreen = () => {
  const {loadScreen} = useInteractionManager();
  const toast = useToast();

  const {user, setAuthUser, setuser} = AuthState();
  // const {setPostRadius} = PostState();
  const [userName, setUserName] = useState(user ? user.userName : '');
  const [radiusUnit, setRadiusUnit] = useState(user?.radiusUnit || 'Kilometer');
  const [email, setEmail] = useState(user ? user.email : '');
  const [radius, setRadius] = useState(user?.radius || 500);
  const [identity, setIdentity] = useState(user?.identity || false);

  const [loading, setloading] = useState(false);

  // useFocusEffect(
  //   useCallback(() => {
  //     console.log('');

  //     return () => {
  //       if (radius !== user?.radius || identity !== user?.identity) {
  //         alert('Your changes may not be saved');
  //       }
  //     };
  //   }, [radius, identity, user?.radius, user?.identity]),
  // );

  const handelLogout = useCallback(() => {
    auth().signOut();
    setAuthUser(null);
    setuser(null);
  }, []);

  const handelUpdateProfile = useCallback(async () => {
    if (email.trim() === '' || userName.trim() === '') {
      alert('some fields are missing');
      return;
    }
    try {
      setloading(true);
      await firestore()
        .doc(`users/${user?.id}`)
        .update({
          email,
          userName,
          identity,
          radius: radiusUnit === 'Mile' ? radius * 1.6 : radius,
          radiusUnit,
        });
      // setPostRadius(radius);
      toast.show({
        description: 'Profile updated',
      });
    } catch (error) {
      console.error(error);
      alert('profile update failed');
    } finally {
      setloading(false);
    }
  }, [email, userName, user, radius, radiusUnit, identity]);

  // console.log('---identity---', identity);

  if (loadScreen) {
    return <Customloader />;
  }

  return (
    <KeyboardAvoidingView
      behavior="height"
      style={{flex: 1, backgroundColor: '#fff', height: '100%'}}>
      {/* <CustomHeader title="Profile" /> */}
      <SafeAreaView>
        <ScrollView>
          <VStack
            justifyContent={'center'}
            alignItems={'center'}
            space={'4'}
            bg={'#fff'}
            paddingX={'3.5'}
            paddingY={'4'}>
            <ProfileImage />

            <VStack mt={10} space={'1'}>
              <Text fontSize={'xl'} color={'#000'} textAlign="center">
                Phone
              </Text>
              <Text fontSize={'2xl'} color={'#000'}>
                {user && user?.phone}
              </Text>
            </VStack>
            <VStack space={'1'} justifyContent="center" w="80%">
              <Text fontSize={'xl'} color={'#000'}>
                Address
              </Text>
              <Text fontSize={20} color={'#000'}>
                {user?.location?.address}
              </Text>
            </VStack>
            <HStack w={'80%'} justifyContent="flex-start" space={'2'}>
              <Text fontSize={'xl'} color={'#000'}>
                Show Identity
              </Text>
              <Switch
                colorScheme={'error'}
                size="sm"
                value={identity}
                onValueChange={setIdentity}
              />
              {identity ? (
                <Text fontWeight={'bold'} fontSize={'xl'} color={'green.500'}>
                  ON
                </Text>
              ) : (
                <Text fontWeight={'bold'} fontSize={'xl'} color={'error.500'}>
                  OFF
                </Text>
              )}
            </HStack>
            <VStack w="80%" justifyContent={'center'}>
              <HStack space={'4'}>
                <Text fontSize={'xl'} color={'#000'}>
                  Set radius in
                </Text>
                <Menu
                  w="190"
                  trigger={triggerProps => {
                    return (
                      <Pressable
                        flexDirection={'row'}
                        accessibilityLabel="More options menu"
                        {...triggerProps}>
                        <Text fontSize={'xl'} color={'#000'}>
                          {radiusUnit}
                        </Text>
                        <MaterialCommunityIcons
                          name="chevron-down"
                          size={20}
                          style={{marginTop: 5, marginLeft: 5}}
                        />
                      </Pressable>
                    );
                  }}>
                  <Menu.Item onPress={() => setRadiusUnit('Kilometer')}>
                    Kilometer
                  </Menu.Item>
                  <Menu.Item onPress={() => setRadiusUnit('Mile')}>
                    Mile
                  </Menu.Item>
                </Menu>
              </HStack>
              <Slider
                mt={'5'}
                defaultValue={radius}
                colorScheme="error"
                minValue={10}
                maxValue={1000}
                onChange={v => {
                  v && setRadius(Math.floor(v));
                }}
                onChangeEnd={v => {
                  v && setRadius(Math.floor(v));
                }}>
                <Slider.Track>
                  <Slider.FilledTrack />
                </Slider.Track>
                <Slider.Thumb borderWidth="0" bg="transparent">
                  <View
                    w="10"
                    h="10"
                    borderRadius={'full'}
                    bg={'#fff'}
                    justifyContent="center"
                    alignItems={'center'}
                    borderColor="error.300"
                    borderWidth={1}>
                    <Text fontWeight={'bold'} fontSize="sm" color={'error.400'}>
                      {radius}
                    </Text>
                  </View>
                </Slider.Thumb>
              </Slider>
            </VStack>
            <VStack space={'5'} mt="2" w="80%" alignItems={'center'}>
              <CustomInput
                title={'Username'}
                plh={'Enter username'}
                onChangeText={setUserName}
                value={userName}
              />
              <CustomInput
                title={'Email'}
                plh={'Enter email'}
                onChangeText={setEmail}
                value={email}
              />
            </VStack>
            <TouchableOpacity
              disabled={loading}
              style={[pagestyles.btn, {marginTop: 20}]}
              onPress={handelUpdateProfile}>
              {loading ? (
                <Customloader />
              ) : (
                <Text style={pagestyles.btnTxt}>UPDATE PROFILE</Text>
              )}
            </TouchableOpacity>
            <TouchableOpacity
              style={[pagestyles.btn, {marginTop: 20}]}
              onPress={handelLogout}>
              <Text style={pagestyles.btnTxt}>LOGOUT</Text>
            </TouchableOpacity>
          </VStack>
        </ScrollView>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};

export default ProfileScreen;

const pagestyles = StyleSheet.create({
  btn: {
    width: '48%',
    backgroundColor: '#ddd',
    height: 48,
    padding: 5,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
    borderRadius: 15,
    flexDirection: 'row',
  },
  btnTxt: {
    fontSize: 15,
    color: '#000',
  },
});
