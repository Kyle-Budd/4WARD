import {useIsFocused} from '@react-navigation/native';
import {Box, HStack, Image, Pressable, Text} from 'native-base';
import React, {useCallback, useRef} from 'react';
import {Dimensions, SafeAreaView, StyleSheet} from 'react-native';
import McIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import {Camera, useCameraDevices} from 'react-native-vision-camera';
import Customloader from '../components/loader';
import {AuthState} from '../context/authState';
import {PostState} from '../context/postState';
import {useAskMediaPermission} from '../utils/customHooks';

const TakeSnapScreen = ({navigation}) => {
  const camera = useRef(null);
  const isFocused = useIsFocused();
  const {user} = AuthState();
  const {imageSrc, setimageSrc} = PostState();

  const devices = useCameraDevices('wide-angle-camera');
  const device = devices.back;
  useAskMediaPermission();

  const handelTakePhoto = useCallback(async () => {
    try {
      console.log('---runcamera----');
      const photo = await camera.current.takeSnapshot({});
      if (photo?.path) {
        setimageSrc(`file://${photo.path}`);
      }
    } catch (error) {
      console.error(error);
      alert('can not capture image!');
      navigation.navigate('MainTab', {screen: 'Homepage'});
    }
  }, [camera]);

  const handelNavigate = useCallback(() => {
    if (!imageSrc) {
      alert('please take a snap');
      return;
    }
    navigation.navigate('SnapShot', {type: 'image'});
  }, [imageSrc]);

  const handelNavigateVideo = useCallback(() => {
    navigation.navigate('TakeVideo');
  }, []);

  if (device == null) return <Customloader />;

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#000'}}>
      <HStack
        w="full"
        justifyContent={'space-between'}
        alignItems="center"
        p={'5'}>
        {user ? (
          <Image
            alt="my-img"
            source={{
              uri: user?.profilePic,
            }}
            style={[styles.user]}
          />
        ) : (
          <Image
            alt="my-img"
            source={require('../assets/images/user1.png')}
            style={[styles.user]}
          />
        )}
        <Text color="#fff" fontSize={22}>
          Take a Snap
        </Text>
        <McIcon
          name="close"
          color={'#fff'}
          size={30}
          onPress={() => navigation.navigate('MainTab', {screen: 'Homepage'})}
        />
      </HStack>

      <Camera
        photo={true}
        ref={camera}
        style={styles.camera}
        device={device}
        isActive={isFocused}
        onError={() => console.log('can not take the picture')}
      />
      <HStack
        space={'10'}
        justifyContent={'center'}
        alignItems="center"
        w={'full'}
        p="2"
        flex={1}>
        {imageSrc ? (
          <Image
            alt="img"
            source={{uri: imageSrc}}
            w={'12'}
            h={'12'}
            rounded={'full'}
          />
        ) : (
          <Box w={'12'} h={'12'} rounded={'full'} bg={'amber.100'} />
        )}
        {/* <Pressable
          bg={'#fff'}
          w={'10'}
          h={'10'}
          rounded={'full'}
          justifyContent="center"
          alignItems={'center'}
          onPress={handelNavigateVideo}>
          <McIcon name="video" size={20} />
        </Pressable> */}
        <Pressable
          bg={'#fff'}
          w={'16'}
          h={'16'}
          rounded={'full'}
          justifyContent="center"
          alignItems={'center'}
          onPress={handelTakePhoto}>
          <McIcon name="camera" size={30} />
        </Pressable>
        <Pressable
          onPress={handelNavigate}
          bg={'#900'}
          w={'12'}
          h={'12'}
          rounded={'full'}
          justifyContent="center"
          alignItems={'center'}>
          <McIcon name="arrow-right" size={30} color={'#fff'} />
        </Pressable>
      </HStack>
    </SafeAreaView>
  );
};

export default TakeSnapScreen;

const styles = StyleSheet.create({
  camera: {
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height * 0.75,
  },
  user: {
    width: 48,
    height: 48,
    borderRadius: 50,
  },
});
