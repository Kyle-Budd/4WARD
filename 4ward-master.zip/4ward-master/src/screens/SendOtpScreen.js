import React, { useState } from 'react';
import {
    View,
    Button,
    Text,
    Image,
    ImageSourcePropType,
    StyleSheet,
    SafeAreaView,
    TouchableOpacity,
    KeyboardAvoidingView,
    TextInput,
    ScrollView,
    ImageBackground,
} from 'react-native';

// import { createStackNavigator } from '@react-navigation/stack';
// import LinearGradient from 'react-native-linear-gradient';
import styles, { ThemeColors } from '../styles/main.style';
import pagestyles from '../styles/setupprofile.style';

// const Stack = createStackNavigator();

const SendOtpScreen = ({ }) => {
    return (
        <>
            <SafeAreaView style={{ flex: 1, backgroundColor: '#000' }}>
                <ScrollView style={pagestyles.scrollView}>
                    <View style={pagestyles.contentContainer}>
                        <View>
                            <Text style={pagestyles.title1}>Bowie, Maryland</Text>
                            <Text style={pagestyles.subTxt}>Enter your phone number </Text>
                            <Text style={pagestyles.subTxt}>sign up or login.</Text>
                        </View>

                        <View style={pagestyles.formsetup}>
                            <View style={{ paddingBottom: 20 }}>
                                <Text style={pagestyles.lableTitle}>*PHONE NUBMER</Text>
                                <TextInput
                                    style={{
                                        fontSize: 18,
                                        textAlign: 'left',
                                        backgroundColor: '#7D797A',
                                        borderRadius: 10,
                                    }}
                                    placeholder=""
                                    // underlineColorAndroid="transparent"
                                    placeholderTextColor="#fff"
                                    color="#fff"
                                    // value={text}
                                    secureTextEntry={false}
                                />
                            </View>

                            <TouchableOpacity>
                                <View style={pagestyles.btn2}>
                                    <Text style={pagestyles.signText}> SEND CODE </Text>
                                </View>
                            </TouchableOpacity>

                            <Text style={pagestyles.mapsubtxt2}>
                                By continuing, you agree to our{' '}
                            </Text>
                            <View style={pagestyles.terms}>
                                <TouchableOpacity>
                                    <Text style={pagestyles.redColor}>Terms of Use</Text>
                                </TouchableOpacity>
                                <Text style={pagestyles.whitClr}> and </Text>
                                <TouchableOpacity>
                                    <Text style={pagestyles.redColor}>Privacy Policye</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>
                </ScrollView>
            </SafeAreaView>
        </>
    );
};

export default SendOtpScreen;
