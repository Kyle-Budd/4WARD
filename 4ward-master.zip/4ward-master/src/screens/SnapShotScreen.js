import firestore from '@react-native-firebase/firestore';
import storage from '@react-native-firebase/storage';
import {useRoute} from '@react-navigation/native';
import axios from 'axios';
import {
  HStack,
  Image,
  Pressable,
  Switch,
  Text,
  TextArea,
  View,
} from 'native-base';
import React, {useCallback, useState} from 'react';
import {
  Platform,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import uuid from 'react-native-uuid';
import CustomHeader from '../components/CustomHeader';
import Customloader from '../components/loader';
import {AuthState} from '../context/authState';
import {PostState} from '../context/postState';
import pagestyles from '../styles/snapshot.style';
import {baseUrl} from '../utils/baseUrl';
import * as geofirestore from 'geofirestore';
import {API_KEY} from '../utils/apiKey';

const firestoreApp = firestore();
const GeoFirestore = geofirestore.initializeApp(firestoreApp);

const SnapShotScreen = ({navigation}) => {
  const {params} = useRoute();
  const {imageSrc, videoSrc, setimageSrc, setvideoSrc} = PostState();
  const {authUser, myLocation} = AuthState();

  const [desc, setdesc] = useState('');
  const [loading, setLoading] = useState(false);
  const [identity, setIdentity] = useState(false);

  const handelPostSubmit = useCallback(async () => {
    if (!myLocation) {
      alert('No location found');
      return;
    }

    if (params?.type === 'image' && (!authUser || !desc || !imageSrc)) {
      alert('Please add content');
      return;
    }
    if (params?.type === 'video' && (!authUser || !desc || !videoSrc)) {
      alert('Please add content');
      return;
    }
    let filename;
    let reference;
    let url;
    let postData;
    const id = uuid.v4();

    try {
      setLoading(true);
      if (params?.type === 'image' && imageSrc) {
        filename = imageSrc.split('/')[imageSrc.split('/').length - 1];
        reference = storage().ref(`post-images/${filename}`);
        await reference.putFile(imageSrc);
        url = await storage().ref(`post-images/${filename}`).getDownloadURL();
        console.log(url);
        if (url) {
          postData = {
            id,
            userId: authUser?.uid,
            type: 'image',
            imageUrl: url,
            description: desc,
            identity,
            address: myLocation?.address,
            coordinates: new firestore.GeoPoint(
              myLocation?.location?.latitude,
              myLocation?.location?.longitude,
            ),
            mapImage: `https://maps.googleapis.com/maps/api/staticmap?zoom=15&size=400x400&format=PNG&markers=${myLocation?.location?.latitude},${myLocation?.location?.longitude}&key=${API_KEY}`,
            // location: myLocation,
            date: firestore.FieldValue.serverTimestamp(),
          };
        }
      } else if (params?.type === 'video' && videoSrc) {
        filename = videoSrc.split('/')[videoSrc.split('/').length - 1];
        reference = storage().ref(`post-videos/${filename}`);
        await reference.putFile(videoSrc);
        url = await storage().ref(`post-videos/${filename}`).getDownloadURL();
        if (url) {
          postData = {
            id,
            userId: authUser?.uid,
            type: 'video',
            videoUrl: url,
            description: desc,
            identity,
            address: myLocation?.address,
            coordinates: new firestore.GeoPoint(
              myLocation?.location?.latitude,
              myLocation?.location?.longitude,
            ),
            mapImage: `https://maps.googleapis.com/maps/api/staticmap?zoom=15&size=400x400&format=PNG&markers=${myLocation?.location?.latitude},${myLocation?.location?.longitude}&key=${API_KEY}`,
            // location: myLocation,
            date: firestore.FieldValue.serverTimestamp(),
          };
        }
      }
      if (postData) {
        await GeoFirestore.collection('posts').doc(id).set(postData);
        // await firestore().collection('posts').doc(id).set(postData);
        // await axios.post(`${baseUrl}/sendNotifications`, {
        //   uid: authUser?.uid,
        //   type: params?.type,
        //   location: myLocation,
        // });
        navigation.navigate('MainTab', {screen: 'Story'});
      }
    } catch (error) {
      console.error(error);
      // alert('Something went wrong');
    } finally {
      setimageSrc(null);
      setvideoSrc(null);
      setdesc('');
      setLoading(false);
    }
  }, [desc, imageSrc, authUser, identity, myLocation]);

  const handelNavigate = useCallback(() => {
    if (params?.type === 'image') {
      navigation.navigate('Media', {type: params?.type, path: imageSrc});
    } else if (params?.type === 'video') {
      navigation.navigate('Media', {type: params?.type, path: videoSrc});
    }
  }, [videoSrc, imageSrc, params?.type]);

  return (
    <>
      <SafeAreaView style={{flex: 1, backgroundColor: '#fff'}}>
        <CustomHeader
          title={params?.type === 'image' ? 'Snap Shot' : 'Live record'}
        />
        <ScrollView style={pagestyles.scrollView}>
          <View style={pagestyles.container}>
            <View style={{maxHeight: 170}}>
              {Platform.OS === 'android' && (
                <Text style={pagestyles.comnTitle}>Preview</Text>
              )}
              <Pressable onPress={handelNavigate}>
                {params?.type === 'image' ? (
                  <Image
                    alt="img"
                    source={{uri: imageSrc}}
                    width={125}
                    height={123}
                    mt={'5'}
                  />
                ) : params?.type === 'video' && Platform.OS === 'android' ? (
                  <Image
                    alt="video"
                    source={{uri: videoSrc}}
                    width={125}
                    height={123}
                    mt={'5'}
                  />
                ) : (
                  <View
                    style={{
                      maxWidth: 125,
                      maxHeight: 125,
                      marginTop: 5,
                    }}
                  />
                )}
              </Pressable>
            </View>
            <HStack mr="1/2" space={'2'} my="4">
              <Text fontSize={'xl'} color={'#000'}>
                Identity
              </Text>
              <Switch
                colorScheme={'error'}
                size="sm"
                value={identity}
                onValueChange={setIdentity}
              />
               {identity ? (
                <Text fontWeight={'bold'} fontSize={'xl'} color={'green.500'}>
                  ON
                </Text>
              ) : (
                <Text fontWeight={'bold'} fontSize={'xl'} color={'error.500'}>
                  OFF
                </Text>
              )}
            </HStack>
            <View mt={'5'}>
              <Text style={pagestyles.comnTitle}> WRITE DESCRIPTION </Text>
              <View my={'5'}>
                <TextArea
                  h={200}
                  fontSize={'md'}
                  placeholder="Description"
                  w="full"
                  color={'#000'}
                  value={desc}
                  onChangeText={setdesc}
                />
              </View>
            </View>

            <View>
              <TouchableOpacity onPress={handelPostSubmit} disabled={loading}>
                <View style={pagestyles.btn1}>
                  {loading ? (
                    <Customloader />
                  ) : (
                    <Text style={pagestyles.signText}> POST </Text>
                  )}
                </View>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    </>
  );
};

export default SnapShotScreen;

//  <Video
//                 resizeMode="cover"
//                 source={{uri: videoSrc}}
//                 paused={true}
//                 style={{
//                   width: 125,
//                   height: 123,
//                   marginTop: 5,
//                 }}
//               />

{
  /* <View style={pagestyles.headerSec}>
              <Image
                source={require('../assets/images/user1.png')}
                style={pagestyles.user}
              />
              <Text style={pagestyles.midleTitle}>Post</Text>
            </View> */
}

{
  /* <View style={pagestyles.switch}>
              <Text style={pagestyles.comnTitle}>IDENTITY</Text>
              <Switch
                trackColor={{false: '#2A2727', true: '#fff'}}
                thumbColor={isEnabled ? '#F60404' : '#F60404'}
                ios_backgroundColor="#2A2727"
                onValueChange={toggleSwitch}
                value={isEnabled}
              />
            </View> */
}

{
  /* <View style={pagestyles.SearchSec}>
                <View style={pagestyles.SectionStyle}>
                  <TextInput
                    style={{
                      fontSize: 14,
                      borderRadius: 15,
                      justifyContent: 'flex-start',
                    }}
                    value={desc}
                    onChangeText={setdesc}
                    placeholder=""
                    underlineColorAndroid="transparent"
                    placeholderTextColor="#fff"
                    color="#fff"
                    keyboardType="default"
                    // secureTextEntry={true}
                  />
                </View>
              </View> */
}
