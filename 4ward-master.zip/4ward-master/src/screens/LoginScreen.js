/* eslint-disable react/no-children-prop */
import auth from '@react-native-firebase/auth';
import {Input, InputGroup, InputLeftAddon, Stack, Text} from 'native-base';
import React, {useCallback, useState} from 'react';
import {
  ImageBackground,
  KeyboardAvoidingView,
  TouchableOpacity,
  View,
} from 'react-native';
import CountryPicker from 'react-native-country-picker-modal';
import Customloader from '../components/loader';
import {AuthState} from '../context/authState';
import pagestyles from '../styles/login.style';
import {useInteractionManager} from '../utils/customHooks';

const LoginScreen = ({navigation}) => {
  const {loadScreen} = useInteractionManager();

  const {
    setConfirm,
    phoneNumber,
    setphoneNumber,
    countryCode,
    setCountryCode,
    myLocation,
  } = AuthState();
  const [show, setShow] = useState(false);

  const [withCallingCode] = useState(true);

  console.log(myLocation);

  // useEffect(() => {
  //   (async () => {
  //     const users = await firestore().collection('Users').get();
  //     console.log(users);
  //   })();
  // }, []);

  const handelSendCode = useCallback(async () => {
    try {
      if (!countryCode || !phoneNumber) {
        alert('Please select country');
        return;
      }
      const confirmation = await auth().signInWithPhoneNumber(
        `+${countryCode}${phoneNumber}`,
      );
      setConfirm(confirmation);
      setphoneNumber('');
      setCountryCode('');
      navigation.navigate('EnterOtp');

      // console.log(phoneNumber);
    } catch (error) {
      console.error(error);
      alert('Phone validation faild, select valid phonenumber');
    }
  }, [phoneNumber, countryCode]);

  const onSelect = useCallback(country => {
    console.log('code', country.callingCode[0]);
    const code = country?.callingCode[0];
    if (code) {
      setCountryCode(code);
    }
  }, []);

  if (loadScreen) {
    return <Customloader />;
  }

  return (
    <>
      <KeyboardAvoidingView
        behavior="height"
        style={{
          flex: 1,
          backgroundColor: '#000',
        }}>
        {/* <ScrollView style={pagestyles.scrollView}> */}

        <ImageBackground
          source={require('../assets/images/loginbg.jpg')}
          resizeMode={'cover'}
          style={pagestyles.loginBg}>
          {myLocation && (
            <View style={pagestyles.mb3}>
              <Text style={pagestyles.mapTitle1}>{myLocation?.address}</Text>
              <Text style={pagestyles.mapsubtxt1}>
                {' '}
                Enter your phone number.
              </Text>
              <Text style={pagestyles.mapsubtxt1}> sign up or login.</Text>
            </View>
          )}

          <CountryPicker
            withFilter
            {...{
              withCallingCode,
              onSelect,
            }}
            visible={show}
          />
          <View>
            <Text style={pagestyles.cmnTitle}>*PHONE NUMBER</Text>
            <Stack alignItems="center">
              <InputGroup w={'100%'}>
                <InputLeftAddon
                  children={
                    <TouchableOpacity onPress={() => setShow(p => !p)}>
                      {countryCode?.length > 0 ? (
                        <Text>+{countryCode}</Text>
                      ) : (
                        <Text color={'#000'}>+234</Text>
                      )}
                    </TouchableOpacity>
                  }
                />
                <Input
                  flex={1}
                  placeholder=""
                  color={'#fff'}
                  value={phoneNumber}
                  fontSize={'lg'}
                  onChangeText={setphoneNumber}
                  secureTextEntry={false}
                  keyboardType={'default'}
                />
              </InputGroup>
            </Stack>

            <TouchableOpacity onPress={handelSendCode}>
              <View
                style={{
                  backgroundColor: '#F60404',
                  height: 48,
                  borderRadius: 10,
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginTop: 15,
                }}>
                <Text style={pagestyles.signText}> SEND CODE </Text>
              </View>
            </TouchableOpacity>
            {/* <TouchableOpacity >
              <View style={{ backgroundColor: '#F60404', height: 48, borderRadius: 10, justifyContent: 'center', alignItems: 'center', marginTop: 15, }}>
                <Text style={pagestyles.signText}> SIGN IN  </Text>
              </View>
            </TouchableOpacity> */}

            <Text style={pagestyles.mapsubtxt2}>
              By continuing, you agree to our{' '}
            </Text>

            <View style={pagestyles.terms}>
              <TouchableOpacity>
                <Text style={pagestyles.redColor}>Terms of Use</Text>
              </TouchableOpacity>
              <Text style={pagestyles.whitClr}> and </Text>
              <TouchableOpacity>
                <Text style={pagestyles.redColor}>Privacy Policy</Text>
              </TouchableOpacity>
            </View>
          </View>
        </ImageBackground>

        {/* </ScrollView> */}
      </KeyboardAvoidingView>
    </>
  );
};

export default LoginScreen;

{
  /* <TextInput
              style={{
                // flex: 1,
                fontSize: 18,
                backgroundColor: '#7D797A',
                borderRadius: 10,
                padding: 13,
                textAlign: 'left',
                // paddingHorizontal: 10,
                // height: 20,
              }}
              placeholder=""
              // underlineColorAndroid="transparent"
              placeholderTextColor="#fff"
              color="#fff"
              value={phoneNumber}
              onChangeText={setphoneNumber}
              secureTextEntry={false}
              keyboardType={'default'}
            /> */
}
