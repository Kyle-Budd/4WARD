import {Dimensions, Platform, StyleSheet} from 'react-native';
import React from 'react';
import {Camera, useCameraDevices} from 'react-native-vision-camera';
import {useRef} from 'react';
import {useIsFocused} from '@react-navigation/native';
import {
  getReturnValues,
  useAskMediaPermission,
  useCountdown,
} from '../utils/customHooks';
import Customloader from '../components/loader';
import {Box, HStack, Image, Pressable, Text, View, VStack} from 'native-base';
import {PostState} from '../context/postState';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {useCallback} from 'react';
import {useState} from 'react';

const CameraScreen = ({navigation, route}) => {
  const androidPlt = Platform.OS === 'android';
  const iosPlt = Platform.OS === 'ios';
  const [mediaType, setmediaType] = useState(route?.params?.type || 'image');
  const [isRecord, setisRecord] = useState(false);
  const [vedioDetails, setVedioDetails] = useState(null);
  const [minutes, seconds] = useCountdown(isRecord);

  const camera = useRef(null);
  const isFocused = useIsFocused();
  const {imageSrc, setimageSrc, videoSrc, setvideoSrc} = PostState();

  const devices = useCameraDevices('wide-angle-camera');
  const device = devices.back;
  useAskMediaPermission();

  const handelNavigate = useCallback(() => {
    if (mediaType === 'image') {
      if (!imageSrc) {
        alert('please take a snap');
        return;
      } else {
        navigation.navigate('SnapShot', {type: 'image'});
      }
    } else if (mediaType === 'video') {
      // console.log('---runn---');
      if (!videoSrc) {
        alert('please record a video');
        return;
      } else {
        navigation.navigate('SnapShot', {type: 'video'});
      }
    }
  }, [imageSrc, mediaType, videoSrc]);

  const handelNavigateMedia = useCallback(() => {
    if (mediaType === 'image') {
      navigation.navigate('Media', {type: mediaType, path: imageSrc});
    } else if (mediaType === 'video') {
      navigation.navigate('Media', {type: mediaType, path: videoSrc});
    }
  }, [videoSrc, imageSrc, mediaType]);

  const handelSwitchMedia = useCallback(() => {
    setmediaType(p => (p === 'image' ? 'video' : 'image'));
  }, []);

  const handelTakePhoto = useCallback(async () => {
    try {
      const photo = await camera.current.takePhoto({});
      if (photo?.path) {
        setimageSrc(`file://${photo.path}`);
      }
    } catch (error) {
      console.error(error);
      alert('can not capture image!');
      navigation.navigate('MainTab', {screen: 'Homepage'});
    }
  }, [camera]);

  const handelrecordVideo = useCallback(async () => {
    try {
      await camera.current.startRecording({
        onRecordingFinished: video => {
          console.log('----video---', video);
          setvideoSrc(video?.path);
          setVedioDetails({
            duration: {
              mins: getReturnValues(parseInt(video?.duration))[0],
              secs: getReturnValues(parseInt(video?.duration))[1] + 1,
            },
            size: (video?.size / 1000).toFixed(2),
          });
        },
        onRecordingError: error => {
          console.error(error);
          alert('can not record a video!');
          navigation.navigate('MainTab', {screen: 'Homepage'});
        },
      });
      setisRecord(true);
    } catch (error) {
      console.error('---err---', error);
      alert('can not record a video!');
      navigation.navigate('MainTab', {screen: 'Homepage'});
    }
  }, [camera]);

  const handelStopRecord = useCallback(async () => {
    await camera.current.stopRecording();
    setisRecord(false);
  }, []);

  if (device == null) return <Customloader />;

  return (
    <View position={'absolute'}>
      {/* <View bg="black" style={styles.camera} /> */}
      <Camera
        photo={mediaType === 'image'}
        video={mediaType === 'video'}
        audio={mediaType === 'video'}
        ref={camera}
        style={styles.camera}
        device={device}
        isActive={isFocused}
        // onError={() => alert('something went wrong')}
      />

      <HStack
        position={'relative'}
        bottom={androidPlt ? 130 : 180}
        space={'10'}
        justifyContent={'center'}
        alignItems="center"
        w={'full'}
        p="2"
        flex={1}>
        {mediaType === 'image' ? (
          <>
            {imageSrc ? (
              <Pressable onPress={handelNavigateMedia}>
                <Image
                  alt="img"
                  source={{uri: imageSrc}}
                  w={'12'}
                  h={'12'}
                  rounded={'full'}
                />
              </Pressable>
            ) : (
              <Box w={'12'} h={'12'} rounded={'full'} bg={'amber.100'} />
            )}
          </>
        ) : (
          mediaType === 'video' && (
            <VStack>
              {isRecord ? (
                <MaterialCommunityIcons
                  name="record-rec"
                  size={40}
                  color={'#900'}
                />
              ) : videoSrc ? (
                <Pressable onPress={handelNavigateMedia}>
                  <Image
                    alt="img"
                    source={{uri: videoSrc}}
                    w={'12'}
                    h={'12'}
                    rounded={'full'}
                  />
                </Pressable>
              ) : (
                <MaterialCommunityIcons
                  name="record"
                  size={40}
                  color={'#900'}
                />
              )}
            </VStack>
          )
        )}
        <Pressable
          bg={'#fff'}
          w={'10'}
          h={'10'}
          rounded={'full'}
          justifyContent="center"
          alignItems={'center'}
          onPress={handelSwitchMedia}>
          <MaterialCommunityIcons
            name={mediaType === 'image' ? 'video' : 'camera'}
            size={20}
            color="#000"
          />
        </Pressable>
        {mediaType === 'image' ? (
          <Pressable
            bg={'#fff'}
            w={'16'}
            h={'16'}
            rounded={'full'}
            justifyContent="center"
            alignItems={'center'}
            onPress={handelTakePhoto}>
            <MaterialCommunityIcons name="camera" size={30} color="#000" />
          </Pressable>
        ) : (
          <>
            {!isRecord ? (
              <Pressable
                bg={'#fff'}
                w={'16'}
                h={'16'}
                rounded={'full'}
                justifyContent="center"
                alignItems={'center'}
                onPress={handelrecordVideo}>
                <MaterialCommunityIcons name="video" size={30} color="#000" />
              </Pressable>
            ) : (
              <Pressable
                bg={'#fff'}
                w={'16'}
                h={'16'}
                rounded={'full'}
                justifyContent="center"
                alignItems={'center'}
                onPress={handelStopRecord}>
                <Box bg={'#900'} w={'12'} h={'12'} rounded={'full'} />
              </Pressable>
            )}
          </>
        )}
        <Pressable
          onPress={handelNavigate}
          bg={'#900'}
          w={'12'}
          h={'12'}
          rounded={'full'}
          justifyContent="center"
          alignItems={'center'}>
          <MaterialCommunityIcons name="arrow-right" size={30} color={'#fff'} />
        </Pressable>
      </HStack>

      {mediaType === 'video' && !vedioDetails && (
        <HStack
          position={'relative'}
          bottom={androidPlt ? 250 : 300}
          justifyContent={'center'}
          alignItems="center"
          w={'full'}
          mt="2">
          <Text color={'#fff'} fontWeight="semibold" fontSize="lg">
            {minutes} : {seconds ? seconds + 1 : 0}
          </Text>
        </HStack>
      )}

      {mediaType === 'video' && !isRecord && vedioDetails && (
        <HStack
          position={'relative'}
          bottom={androidPlt ? 250 : 300}
          space={'4'}
          justifyContent={'center'}
          alignItems="center"
          w={'full'}
          my="2">
          <Text color={'#fff'} fontWeight="semibold" fontSize="md">
            duration:{' '}
            {vedioDetails?.duration?.mins > 0
              ? vedioDetails?.duration?.mins
              : 0}{' '}
            : {vedioDetails?.duration?.secs}
          </Text>
          {Platform.OS === 'android' && (
            <Text color={'#fff'} fontWeight="semibold" fontSize="md">
              size: {vedioDetails?.size} mb
            </Text>
          )}
        </HStack>
      )}

      <Pressable
        position={'absolute'}
        top={5}
        right={5}
        onPress={() => navigation.navigate('MainTab', {screen: 'Homepage'})}>
        <MaterialCommunityIcons name="close" color={'#fff'} size={30} />
      </Pressable>
    </View>
  );
};

export default CameraScreen;

const styles = StyleSheet.create({
  camera: {
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height,
  },
});
