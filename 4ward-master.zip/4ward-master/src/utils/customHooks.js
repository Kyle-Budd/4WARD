import {useFocusEffect, useNavigation} from '@react-navigation/native';
import {useCallback, useEffect, useState} from 'react';
import {InteractionManager, Linking} from 'react-native';
import {Camera} from 'react-native-vision-camera';
import {AppState, AppStateStatus} from 'react-native';

export const useInteractionManager = () => {
  const [loadScreen, setLoadScreen] = useState(true);

  useFocusEffect(
    useCallback(() => {
      const task = InteractionManager.runAfterInteractions(() => {
        setLoadScreen(false);
      });

      return () => task.cancel();
    }, []),
  );

  return {loadScreen, setLoadScreen};
};

export const useCountdown = start => {
  const [videoTime, setVideoTime] = useState(0);
  useEffect(() => {
    let interval = () => {};
    if (start) {
      interval = setInterval(() => {
        setVideoTime(t => t + 1);
      }, 1000);
    } else {
      setVideoTime(0);
    }

    return () => clearInterval(interval);
  }, [start]);

  return getReturnValues(videoTime);
};

export const getReturnValues = videoTime => {
  let minutes = 0;
  let seconds = videoTime;

  if (videoTime % 60 == 0) {
    minutes = parseInt(videoTime / 60);
    seconds = 0;
  } else if (videoTime >= 60) {
    minutes = parseInt(videoTime / 60);
    seconds = videoTime % 60;
  }

  return [minutes, seconds];
};

export const useAskMediaPermission = () => {
  const navigation = useNavigation();
  const [isCameraPermission, setisCameraPermission] = useState(false);
  const [isMicPermission, setisMicPermission] = useState(false);

  useEffect(() => {
    (async () => {
      const cameraPermission = await Camera.getCameraPermissionStatus();
      const microphonePermission = await Camera.getMicrophonePermissionStatus();

      if (cameraPermission === 'denied') {
        const newCameraPermission = await Camera.requestCameraPermission();
        if (newCameraPermission === 'denied') {
          alert('Please allow camera permission');
          navigation.goBack();
          Linking.openSettings();
        }
      } else {
        console.log(cameraPermission);
        setisCameraPermission(true);
      }

      if (microphonePermission === 'denied') {
        const newMicrophonePermission =
          await Camera.requestMicrophonePermission();

        if (newMicrophonePermission === 'denied') {
          alert('Please allow microphone permission');
          navigation.goBack();
          Linking.openSettings();
        }
      } else {
        console.log(microphonePermission);
        setisMicPermission(true);
      }
    })();
  }, []);

  return {isCameraPermission, isMicPermission};
};

export const useIsForeground = () => {
  const [isForeground, setIsForeground] = useState(true);

  useEffect(() => {
    const onChange = state => {
      setIsForeground(state === 'active');
    };
    const listener = AppState.addEventListener('change', onChange);
    return () => listener.remove();
  }, [setIsForeground]);

  return isForeground;
};
