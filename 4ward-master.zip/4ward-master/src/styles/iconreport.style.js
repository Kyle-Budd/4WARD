import {StyleSheet, PixelRatio, Dimensions} from 'react-native';
import {ThemeColors} from '../styles/main.style';
let ScreenHeight = Dimensions.get('window').height;
let ScreenWidth = Dimensions.get('window').width;

export default StyleSheet.create({
  container: {
    padding: 30,
  },
  headerSec: {
    paddingBottom: 50,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  user: {
    width: 48,
    height: 48,
    position: 'absolute',
    left: 0,
    top: 0,
  },
  midleTitle: {
    position: 'relative',
    top: 12,
    fontSize: 20,
    color: '#fff',
  },
  icn: {
    maxWidth: 40,
    maxHeight: 36,
    marginBottom: 10,
  },
  icnList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    paddingTop: 30,
  },
  listBx: {
    width: '24%',
    alignItems: 'center',
    marginBottom: 15,
    paddingTop: 10,
    paddingBottom: 10,
  },
  active: {
    borderWidth: 2,
    borderColor: '#6b0404',
    marginLeft: 5,
    borderRadius: 10,
  },
  icnTxt: {
    fontSize: 13,
    color: '#000',
  },
  comnTitle: {
    color: '#000',
    fontSize: 16,
  },
  SearchSec: {
    marginTop: 10,
  },
  SectionStyle: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 5,
    width: '100%',
    color: '#000',
    // borderColor: '#7D797A',
    // backgroundColor: '#7D797A',
    // borderWidth: 1,
    paddingRight: 10,
    // paddingLeft: 15,
    fontSize: 14,
    height: 48,
    marginBottom: 30,
  },
  ImageStyle: {
    maxWidth: 20,
    maxHeight: 20,
  },
  switch: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    marginBottom: 30,
  },
  btn1: {
    backgroundColor: '#F60404',
    height: 48,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    margin: 30,
  },
  signText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
  },
});
