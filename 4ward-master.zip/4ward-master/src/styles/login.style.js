import {StyleSheet, PixelRatio, Dimensions} from 'react-native';
import {ThemeColors} from '../styles/main.style';
let ScreenHeight = Dimensions.get('window').height;
let ScreenWidth = Dimensions.get('window').width;

export default StyleSheet.create({
  loginBg: {
    flex: 1,
    justifyContent: 'flex-end',
    padding: 30,
  },
  scrollView: {
    flex: 1,
  },
  signText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
  },
  mapTitle1: {
    fontSize: 20,
    color: '#fff',
    marginBottom: 10,
  },
  mapsubtxt1: {
    color: '#646464',
    fontSize: 18,
  },
  mb3: {
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 30,
  },
  cmnTitle: {
    color: '#fff',
    paddingBottom: 10,
  },
  terms: {
    flexDirection: 'row',
    justifyContent: 'center',
    color: '#fff',
  },
  redColor: {
    color: '#F60404',
    fontSize: 16,
  },
  whitClr: {
    color: '#fff',
    fontSize: 16,
  },
  mapsubtxt2: {
    justifyContent: 'center',
    textAlign: 'center',
    color: '#fff',
    marginTop: 15,
    fontSize: 16,
  },
  btn2: {
    backgroundColor: '#F60404',
    height: 48,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 15,
    minWidth: '45%',
  },
  btn3: {
    backgroundColor: '#313131',
    height: 48,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 15,
    minWidth: '45%',
  },
  twoBtn: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
});
