import {StyleSheet, PixelRatio, Dimensions} from 'react-native';
import {ThemeColors} from '../styles/main.style';
let ScreenHeight = Dimensions.get('window').height;
let ScreenWidth = Dimensions.get('window').width;

export default StyleSheet.create({
  container: {
    padding: 15,
    flex: 1,
  },
  SearchSec: {
    marginTop: 5,
    flex: 1,
  },
  SectionStyle: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 5,
    width: '100%',
    color: '#000',
    borderColor: '#7D797A',
    backgroundColor: '#7D797A',
    borderWidth: 1,
    paddingRight: 10,
    paddingLeft: 15,
    fontSize: 14,
    borderRadius: 15,
    height: 48,
    marginBottom: 30,
  },
  ImageStyle: {
    maxWidth: 16,
    maxHeight: 16,
  },
  user: {
    width: 48,
    height: 48,
    marginRight: 10,
    position: 'relative',
  },
  headerSec: {
    flexDirection: 'row',
  },
  mapBg: {
    flex: 1,
  },
  locatnCircl: {
    width: 139,
    height: 139,
    backgroundColor: 'rgba(246, 4, 4, 0.3)',
    borderRadius: 100,
    justifyContent: 'center',
    alignItems: 'center',
  },
  locatnWrap: {
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 60,
    marginBottom: 50,
  },
  innerContainer: {
    backgroundColor: '#fff',
    padding: 15,
    borderTopRightRadius: 20,
    borderTopLeftRadius: 20,
  },
  btnSec: {
    marginBottom: 20,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  btn: {
    width: '100%',
    backgroundColor: '#ddd',
    height: 48,
    padding: 5,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
    borderRadius: 15,
    flexDirection: 'row',
    // borderColor: '#320202',
    // borderWidth: 2,
  },
  icn: {
    width: 15,
    height: 15,
    marginRight: 10,
  },
  title: {
    fontSize: 15,
    color: '#F60404',
    // marginTop: 10,
    fontWeight: '600',
  },
  btnTxt: {
    fontSize: 15,
    color: '#320202',
  },
  ulList: {
    // paddingTop: 10,
    marginBottom: 10,
  },
  liList: {
    // borderBottomColor: '#320202',
    // borderBottomWidth: 1,
    paddingBottom: 15,
    marginBottom: 15,
  },
  arw2: {
    width: 24,
    height: 16,
  },
  forwardSec: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  listTitle: {
    fontSize: 15,
    color: '#000',
    paddingBottom: 10,
  },
  subTxt: {
    color: '#646464',
  },
  path2: {
    width: 174,
    height: 167,
  },
});
