import {StyleSheet, PixelRatio, Dimensions} from 'react-native';
import {ThemeColors} from '../styles/main.style';
let ScreenHeight = Dimensions.get('window').height;
let ScreenWidth = Dimensions.get('window').width;

export default StyleSheet.create({
  container: {
    padding: 30,
  },
  headerSec: {
    paddingBottom: 50,
  },
  user: {
    width: 48,
    height: 48,
  },
  contactList: {
    flexDirection: 'row',
    marginBottom: 20,
    paddingBottom: 20,
    // borderBottomColor: '#340101',
    // borderBottomWidth: 2,
  },
  leftTxt: {
    paddingRight: 15,
  },
  titleSec: {
    color: '#000',
    fontSize: 16,
    textTransform: 'uppercase',
    paddingBottom: 5,
  },
  subList: {
    fontSize: 14,
    color: '#646464',
  },
  inviteSec: {
    fontSize: 14,
    color: '#F60404',
    borderColor: '#F60404',
    borderWidth: 1,
    borderRadius: 5,
    minWidth: 91,
    padding: 10,
    justifyContent: 'center',
    alignItems: 'center',
    textAlign: 'center',
  },
});
