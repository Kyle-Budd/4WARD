import {StyleSheet, PixelRatio, Dimensions} from 'react-native';
import {ThemeColors} from '../styles/main.style';
let ScreenHeight = Dimensions.get('window').height;
let ScreenWidth = Dimensions.get('window').width;

export default StyleSheet.create({
  getstatedWrap:{
    backgroundColor:'#fff',
    flex: 1,
    display:'flex',
    height:'100%',
    justifyContent:'space-evenly',
    alignItems:'center',
    padding:15,
  },
  scrollView:{
    flex:1,
  },
 
  contentContainer:{
    justifyContent:'center',
    alignItems:'center',
    flex:1,
    backgroundColor:'#000',
    height:'100%',
  },
    RoundContainer:{
    padding: 30,
    backgroundColor:'#fff',
    borderTopLeftRadius:30,
    borderTopRightRadius:30,
    flex:1,
    marginTop:-30,
  },
 

  TitleOne:{
    color: '#000',
    fontSize: 20, 
    fontWeight: 'bold',
    textAlign:'center',
  },
 
subTxt:{
  color: '#6B6B6B', 
  fontSize: 16, 
  textAlign: 'center',
},
btn1:{
  width: 265, 
  height: 69, 
  justifyContent: 'center', 
  alignItems: 'center',
},
redTxt:{
  color: '#F60404', 
  fontSize: 12, 
  fontWeight:'600'
},
lockSec:{
  justifyContent: 'center', 
  alignItems: 'center',
 
},
lockWrap:{
  display: 'flex', 
  flexDirection: 'row',
  alignItems:'center',
  marginBottom:10,
  paddingLeft:15,
  paddingRight:15,
},
lockImg:{
  width: 18, 
  height: 23,
  marginRight:9,
},
getTxt:{
  color: '#fff', 
  fontSize: 18, 
  fontWeight: 'bold',
}

});
