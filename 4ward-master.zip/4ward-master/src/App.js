import React from 'react';
import {AuthContextProvider} from './context/authState';
import {NativeBaseProvider} from 'native-base';
import RootNavigation from './navigation';
import {PostContextProvider} from './context/postState';

const App = () => {
  return (
    <>
      <NativeBaseProvider>
        <AuthContextProvider>
          <PostContextProvider>
            <RootNavigation />
          </PostContextProvider>
        </AuthContextProvider>
      </NativeBaseProvider>
    </>
  );
};

export default App;

// AIzaSyCtjsZQHADLPVsE1X8iZu6iWG9Eopm00OA

// app store email vincent@mcholmescorp.com
// app store pass Kushanku1979

// google account pass 4WARD2022!

// google play store email Vincent@mcholmescorp.com
// google play pass Kushanku00

// twilio email info@the4wardapp.com
// twilio pass VinceHolmes2022!!

// "android_app_id": "ca-app-pub-1162359436302937~5026667913",
// "ios_app_id": "ca-app-pub-1162359436302937~7760055737"

// ca-app-pub-3940256099942544/6300978111


//  Vincent@mcholmescorp.com
// Kushanku00