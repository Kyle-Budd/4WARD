import {createNativeStackNavigator} from '@react-navigation/native-stack';
import React from 'react';
import EnterOtpScreen from '../screens/EnterOtpScreen';
import LoginScreen from '../screens/LoginScreen';
import SendOtpScreen from '../screens/SendOtpScreen';

function AuthStack() {
  const Stack = createNativeStackNavigator();

  return (
    <Stack.Navigator screenOptions={{headerShown: false}}>
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="EnterOtp" component={EnterOtpScreen} />
      <Stack.Screen name="SendOtp" component={SendOtpScreen} />
    </Stack.Navigator>
  );
}

export default AuthStack;
