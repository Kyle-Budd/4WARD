import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import React from 'react';
import {StyleSheet} from 'react-native';
import TabBar from '../components/TabBar';
import ContactScreen from '../screens/ContactScreen';
import HomepageScreen from '../screens/HomepageScreen';
import ProfileScreen from '../screens/ProfileScreen';
import StoryScreen from '../screens/StoryScreen';

const Tab = createBottomTabNavigator();

const MainTab = () => {
  return (
    <Tab.Navigator
      screenOptions={{headerShown: false}}
      initialRouteName="Home"
      tabBar={props => <TabBar {...props} />}>
      <Tab.Screen name="Homepage" component={HomepageScreen} />
      <Tab.Screen name="Profilepage" component={ProfileScreen} />
      <Tab.Screen name="Story" component={StoryScreen} />
      <Tab.Screen name="Contact" component={ContactScreen} />
    </Tab.Navigator>
  );
};

export default MainTab;

const styles = StyleSheet.create({});
