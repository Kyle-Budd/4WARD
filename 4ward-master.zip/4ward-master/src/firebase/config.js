export const firebaseConfig = {
  apiKey: 'AIzaSyBk5Vk7rlB-RUhTga3aD4Ow2bqo07cuCcY',
  authDomain: 'rn-shop-49cec.firebaseapp.com',
  databaseURL: 'https://rn-shop-49cec-default-rtdb.firebaseio.com',
  projectId: 'rn-shop-49cec',
  storageBucket: 'rn-shop-49cec.appspot.com',
  messagingSenderId: '74735651426',
  appId: '1:74735651426:web:f136b73dc26006db9cdf3b',
};
