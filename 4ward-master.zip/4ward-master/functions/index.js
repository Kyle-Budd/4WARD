/* eslint-disable no-undef */
const functions = require('firebase-functions');
const admin = require('firebase-admin');

var serviceAccount = require('./ward-af760-firebase-adminsdk-mxxn0-a4504a28fd.json');
const {firestore} = require('firebase-admin');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});
const cors = require('cors')({origin: true});

exports.sendNotifications = functions.https.onRequest(
  async (request, response) => {
    const userRef = admin
      .firestore()
      .collection('users')
      .where('id', '!=', request.body.uid);

    let tokens = [];
    try {
      await userRef.get().then(querySnapshot => {
        querySnapshot.forEach(documentSnapshot => {
          const userData = documentSnapshot.data();
          tokens.push(userData.token);
        });
      });
      let title;

      if (request.body.type === 'image') {
        title = 'Image captured';
      } else if (request.body.type === 'video') {
        title = 'Video captured';
      } else if (request.body.type === 'icon') {
        title = `${request.body.icId} from icon report`;
      } else if (request.body.type === 'sos') {
        title = 'Save our souls';
      }

      // await admin.messaging().send({
      //   token:
      //     'dO9ihuP1TM2kQ--fa8Cba-:APA91bGZpl5W-xi9zRhKw7ts9y9sxcMLKj19khi-q5qVj1R4ZfUwP0SgUQcBkESC5dThIW7AKA-GMBMcRud4Ze7Ljcyd8-e-auPSHwCFdZznrn1oHfyG8ywBomA05N_hcaOSsYQWcLVM',
      //   notification: {
      //     title: title,
      //     body: `Location - ${request?.body?.location?.address}`,
      //   },
      //   data: {
      //     location: JSON.stringify(request.body.location),
      //     type: JSON.stringify(request.body.type),
      //   },
      // });

      await Promise.all(
        tokens.map(token =>
          admin.messaging().send({
            token,
            notification: {
              title: title,
              body: `Location - ${request?.body?.location?.address}`,
            },
            data: {
              location: JSON.stringify(request.body.location),
              type: JSON.stringify(request.body.type),
            },
          }),
        ),
      );
      response.status(200).json({
        msg: 'notification sent',
      });
    } catch (error) {
      console.error(error);
      response.status(500).json({msg: 'server error'});
    }
  },
);

exports.filterPosts = functions.https.onRequest(async (req, res) => {
  const {type, icId} = req.body;

  try {
    let posts = [];
    if (icId) {
      await admin
        .firestore()
        .collection('posts')
        .where('icId', '==', icId)
        .orderBy('date', 'desc')
        .limit(100)
        .get()
        .then(querySnapshot => {
          querySnapshot.forEach(documentSnapshot => {
            const postData = documentSnapshot.data();
            posts.push(postData);
          });
        });
    } else if (type) {
      await admin
        .firestore()
        .collection('posts')
        .where('type', '==', type)
        .orderBy('date', 'desc')
        .limit(100)
        .get()
        .then(querySnapshot => {
          querySnapshot.forEach(documentSnapshot => {
            const postData = documentSnapshot.data();
            posts.push(postData);
          });
        });
    }
    return res.status(200).json({msg: 'success', count: posts.length, posts});
  } catch (error) {
    console.error(error);
    return res.status(500).json({msg: 'server error'});
  }
});

exports.getPostDetails = functions.https.onRequest(async (req, res) => {
  const {postId} = req.body;
  if (!postId) {
    return res.status(400).json({msg: 'required field missing'});
  }
  try {
    const post = (
      await admin.firestore().collection('posts').doc(postId).get()
    ).data();
    const postComments = (
      await firestore()
        .collection('comments')
        .where('postId', '==', postId)
        .orderBy('date', 'desc')
        .limit(100)
        .get()
    ).docs;
    const comUsers = await Promise.all(
      postComments.map(com =>
        firestore()
          .collection('users')
          .doc(com.data().userId)
          .get()
          .then(ds => ds.data()),
      ),
    );
    const postUser = await firestore()
      .collection('users')
      .doc(post.userId)
      .get()
      .then(ds => ds.data());

    const comments = postComments.map(com => ({
      ...com.data(),
      user: comUsers.find(cu => cu.id === com.data().userId),
    }));

    return res.status(200).json({
      msg: 'success',
      data: {
        post: {
          ...post,
          user: postUser,
        },
        comments,
      },
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({msg: 'server error'});
  }
});

exports.addComment = functions.https.onRequest(async (req, res) => {
  const {postId, userId, commentId, message} = req.body;
  if (!postId || !userId || !commentId || !message) {
    return res.status(400).json({msg: 'required field missing'});
  }

  try {
    await firestore().collection('comments').doc(commentId).set({
      id: commentId,
      message,
      postId,
      userId,
      date: firestore.FieldValue.serverTimestamp(),
    });

    await admin
      .firestore()
      .collection('posts')
      .doc(postId)
      .update({
        comments: firestore.FieldValue.arrayUnion(commentId),
      });

    const newComment = (
      await firestore().collection('comments').doc(commentId).get()
    ).data();
    const user = await firestore()
      .collection('users')
      .doc(userId)
      .get()
      .then(ds => ds.data());
    return res.status(200).json({msg: 'success', data: {...newComment, user}});
  } catch (error) {
    console.error(error);
    return res.status(500).json({msg: 'server error'});
  }
});

exports.likeUnlikePost = functions.https.onRequest(async (req, res) => {
  const {postId, userId, type} = req.body;
  if (!postId || !userId || !type) {
    return res.status(400).json({msg: 'required field missing'});
  }

  try {
    if (type == 1) {
      await admin
        .firestore()
        .collection('posts')
        .doc(postId)
        .update({
          likes: firestore.FieldValue.arrayUnion(userId),
        });
      await admin
        .firestore()
        .collection('posts')
        .doc(postId)
        .update({
          disLikes: firestore.FieldValue.arrayRemove(userId),
        });
    } else if (type == 2) {
      await admin
        .firestore()
        .collection('posts')
        .doc(postId)
        .update({
          likes: firestore.FieldValue.arrayRemove(userId),
        });
    }
    return res.status(200).json({msg: 'success'});
  } catch (error) {
    console.error(error);
    return res.status(500).json({msg: 'server error'});
  }
});
exports.disLikePost = functions.https.onRequest(async (req, res) => {
  const {postId, userId, type} = req.body;
  if (!postId || !userId || !type) {
    return res.status(400).json({msg: 'required field missing'});
  }

  try {
    if (type == 1) {
      await admin
        .firestore()
        .collection('posts')
        .doc(postId)
        .update({
          disLikes: firestore.FieldValue.arrayUnion(userId),
        });
      await admin
        .firestore()
        .collection('posts')
        .doc(postId)
        .update({
          likes: firestore.FieldValue.arrayRemove(userId),
        });
    } else if (type == 2) {
      await admin
        .firestore()
        .collection('posts')
        .doc(postId)
        .update({
          disLikes: firestore.FieldValue.arrayRemove(userId),
        });
    }
    return res.status(200).json({msg: 'success'});
  } catch (error) {
    console.error(error);
    return res.status(500).json({msg: 'server error'});
  }
});

exports.getAllUsers = functions.https.onRequest(async (req, res) => {
  try {
    const userSnapshots = await admin.firestore().collection('users').get();
    const users = userSnapshots.docs.map(doc => doc.data());
    return res
      .set('Access-Control-Allow-Origin', '*')
      .status(200)
      .json({msg: 'success', users});
  } catch (error) {
    console.error(error);
    return res.status(500).json({msg: 'server error'});
  }
});
exports.getAllPosts = functions.https.onRequest(async (req, res) => {
  try {
    const postSnapshots = await admin
      .firestore()
      .collection('posts')
      .orderBy('date', 'desc')
      .get();

    const posts = postSnapshots.docs.map(doc => doc.data());
    const userProfiles = await Promise.all(
      posts.map(p =>
        firestore()
          .collection('users')
          .doc(p.userId)
          .get()
          .then(up => up.data()),
      ),
    );

    // console.log('---posts---', {
    //   posts: posts[0],
    //   userProfiles: userProfiles[0],
    // });
    // console.log('---new posts---', {
    //   posts: posts.map(p => {
    //     const userP = userProfiles.find(up =>
    //       up ? up.id === p.userId : false,
    //     );
    //     return {post: p, user: userP};
    //   })[0],
    // });
    const postsWithUsers = posts.map(p => {
      const userP = userProfiles.find(up => (up ? up.id === p.userId : false));
      return {post: p, user: userP};
    });

    return res
      .set('Access-Control-Allow-Origin', '*')
      .status(200)
      .json({msg: 'success', posts: postsWithUsers});
  } catch (error) {
    console.error(error);
    return res.status(500).json({msg: 'server error'});
  }
});

exports.deletePost = functions.https.onRequest((req, res) => {
  cors(req, res, async () => {
    // your function body here - use the provided req and res from cors

    const {postId} = req.body;
    if (!postId) {
      return res.status(400).json({msg: 'required field missing'});
    }
    try {
      await admin.firestore().collection('posts').doc(postId).delete();

      return res
        .set('Access-Control-Allow-Origin', '*')
        .status(200)
        .json({msg: 'success'});
    } catch (error) {
      console.error(error);
      return res.status(500).json({msg: 'server error'});
    }
  });
});

exports.editPost = functions.https.onRequest(async (req, res) => {
  cors(req, res, async () => {
    if (!req.body.postId) {
      return res.status(400).json({msg: 'required field missing'});
    }
    try {
      const postRef = firestore().collection('posts');

      await postRef.doc(req.body.postId).update(req.body);
      return res
        .set('Access-Control-Allow-Origin', '*')
        .status(200)
        .json({msg: 'success'});
    } catch (error) {
      console.error(error);
      return res.status(500).json({msg: 'server error'});
    }
  });
});
exports.createAdmin = functions.https.onRequest(async (req, res) => {
  cors(req, res, async () => {
    const {email, password, adminEmail, adminPassword} = req.body;
    if (!email || !password || !adminEmail || !adminPassword) {
      return res.status(400).json({msg: 'required field missing'});
    }

    if (
      adminEmail !== 'kyle@mcholmescorp.com' ||
      adminPassword !== '4WARD2022!'
    ) {
      return res.status(400).json({msg: 'Wrong admin credential!'});
    }

    try {
      const adminRef = firestore().collection('admins');
      const whereAdmin = (await adminRef.where('email', '==', email).get())
        .docs;
      if (whereAdmin.length != 0) {
        return res.status(400).json({msg: 'already exists'});
      } else {
        await adminRef.doc(email).set({
          email,
          password,
        });
      }
      return res.status(200).json({msg: 'success'});
    } catch (error) {
      console.error(error);
      return res.status(500).json({msg: 'server error'});
    }
  });
});
exports.adminLogin = functions.https.onRequest(async (req, res) => {
  cors(req, res, async () => {
    const {email, password} = req.body;
    if (!email || !password) {
      return res.status(400).json({msg: 'required field missing'});
    }
    try {
      const adminRef = firestore().collection('admins');
      const whereAdmin = (
        await adminRef
          .where('email', '==', email)
          .where('password', '==', password)
          .get()
      ).docs;
      if (whereAdmin.length == 0) {
        return res.status(400).json({msg: 'user not found'});
      }
      return res.status(200).json({msg: 'success', admin: whereAdmin});
    } catch (error) {
      console.error(error);
      return res.status(500).json({msg: 'server error'});
    }
  });
});
exports.banUser = functions.https.onRequest(async (req, res) => {
  cors(req, res, async () => {
    const {userId, banStatus} = req.body;
    if (!userId) {
      return res.status(400).json({msg: 'required field missing'});
    }
    try {
      const userRef = firestore().collection('users');
      const whereUser = (await userRef.where('id', '==', userId).get()).docs;
      if (whereUser.length == 0) {
        return res.status(400).json({msg: 'user not found'});
      }
      await userRef.doc(userId).update({
        banStatus,
      });
      return res.status(200).json({msg: 'success'});
    } catch (error) {
      console.error(error);
      return res.status(500).json({msg: 'server error'});
    }
  });
});
exports.deleteUser = functions.https.onRequest(async (req, res) => {
  cors(req, res, async () => {
    const {userId, phone} = req.body;
    if (!userId || !phone) {
      return res.status(400).json({msg: 'required field missing'});
    }
    try {
      const userRef = firestore().collection('users');
      const whereUser = (
        await userRef
          .where('id', '==', userId)
          .where('phone', '==', phone)
          .get()
      ).docs;
      if (whereUser.length == 0) {
        return res.status(400).json({msg: 'user not found'});
      }
      await userRef.doc(userId).delete();

      return res.status(200).json({msg: 'success'});
    } catch (error) {
      console.error(error);
      return res.status(500).json({msg: 'server error'});
    }
  });
});
exports.updateUser = functions.https.onRequest(async (req, res) => {
  cors(req, res, async () => {
    const {userData} = req.body;
    if (!userData) {
      return res.status(400).json({msg: 'required field missing'});
    }
    try {
      const userRef = firestore().collection('users');
      const whereUser = (
        await userRef
          .where('phone', '==', userData.phone)
          .where('id', '==', userData.id)
          .get()
      ).docs;
      if (whereUser.length == 0) {
        return res.status(400).json({msg: 'user not found'});
      }
      await userRef.doc(userData.id).update({
        ...userData,
      });

      return res.status(200).json({msg: 'success'});
    } catch (error) {
      console.error(error);
      return res.status(500).json({msg: 'server error'});
    }
  });
});
exports.updateAdmin = functions.https.onRequest(async (req, res) => {
  cors(req, res, async () => {
    const {adminData} = req.body;
    if (!adminData) {
      return res.status(400).json({msg: 'required field missing'});
    }
    try {
      const adminRef = firestore().collection('admins');
      const whereAdmin = (
        await adminRef.where('email', '==', adminData.email).get()
      ).docs;
      if (whereAdmin.length == 0) {
        return res.status(400).json({msg: 'user not found'});
      }
      await adminRef.doc(adminData.email).update({
        ...adminData,
      });

      return res.status(200).json({msg: 'success'});
    } catch (error) {
      console.error(error);
      return res.status(500).json({msg: 'server error'});
    }
  });
});

exports.deleteAdmin = functions.https.onRequest((req, res) => {
  cors(req, res, async () => {
    const {adminData} = req.body;
    if (!adminData) {
      return res.status(400).json({msg: 'required field missing'});
    }
    try {
      await admin
        .firestore()
        .collection('admins')
        .doc(adminData.email)
        .delete();

      return res.status(200).json({msg: 'success'});
    } catch (error) {
      console.error(error);
      return res.status(500).json({msg: 'server error'});
    }
  });
});

exports.getAllsubAdmins = functions.https.onRequest(async (req, res) => {
  cors(req, res, async () => {
    try {
      const userSnapshots = await admin.firestore().collection('admins').get();
      const users = userSnapshots.docs.map(doc => doc.data());
      return res.status(200).json({msg: 'success', users});
    } catch (error) {
      console.error(error);
      return res.status(500).json({msg: 'server error'});
    }
  });
});

//  admin
//   .messaging()
//   .sendToDevice(tokens, {
//     data: {body: 'Hello'},
//     notification: {title: 'cloud function demo', body: 'Hello'},
//   })
//   .then(response => {
//     console.log('Successfully sent message:', response);
//     return {success: true};
//   })
//   .catch(error => {
//     return {error: error.code};
//   });

// response.send('Hello from Firebase!');

// functions.logger.info('Hello logs!', {structuredData: true});

// await admin
//   .firestore()
//   .collection('posts')
//   .doc(postId)
//   .collection('comments')
//   .doc(commentId)
//   .set({
//     id: commentId,
//     message,
//     postId,
//     userId,
//     date: firestore.FieldValue.serverTimestamp(),
//   });
