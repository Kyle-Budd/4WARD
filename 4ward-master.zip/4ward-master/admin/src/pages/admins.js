import {Box, Container} from '@mui/material';
import axios from 'axios';
import {useQuery} from 'react-query';
import Loader from 'src/components/loader';
import authHoc from 'src/utils/authHoc';
import {SubAdminListResults} from '../components/subAdmin/subAdminList';
import {DashboardLayout} from '../components/dashboard-layout';
import {baseUrl} from '../constant/baseurl';
import React, {useEffect} from 'react';
import {useRouter} from 'next/router';

const fetchAllUsers = async () => {
  const {data} = await axios.get(`${baseUrl}/getAllsubAdmins`);
  return data;
};

const Customers = () => {
  const router = useRouter();

  const {data, isLoading} = useQuery('allAdmins', fetchAllUsers, {
    retry: false,
    refetchOnWindowFocus: false,
  });

  console.log('-----users----', data);

  useEffect(
    () => {
      if (!localStorage.getItem('superAdmin')) {
        window.location.assign('/');
      }
    },
    [],
  );

  if (isLoading) {
    return <Loader />;
  }

  return (
    <DashboardLayout>
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          py: 8,
        }}>
        <Container maxWidth={false}>
          {/* <CustomerListToolbar /> */}
          <Box sx={{mt: 3}}>
            <SubAdminListResults users={data?.users.filter(u => !u.isAdmin)} />
          </Box>
        </Container>
      </Box>
    </DashboardLayout>
  );
};

export default authHoc(Customers);

// Customers.getLayout = (page) => <DashboardLayout>{page}</DashboardLayout>;

// export async function getServerSideProps(context) {
//   try {
//     const { data } = await axios.get(`${baseUrl}/api/admin/getAllUsers`);
//     console.log("---allusers---", data);
//     return {
//       props: { data },
//     };
//   } catch (error) {
//     console.error("----errr---", error?.response?.data);
//     if (error?.response?.data?.error === "Invalid auth key") {
//     }
//     return {
//       redirect: {
//         destination: "/login",
//         permanent: false,
//       },
//     };
//   }
// }
