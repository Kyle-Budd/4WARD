import {Box, Container} from '@mui/material';
import axios from 'axios';
import {useQuery} from 'react-query';
import Loader from 'src/components/loader';
import authHoc from 'src/utils/authHoc';
import {CustomerListResults} from '../components/customer/customer-list-results';
import {DashboardLayout} from '../components/dashboard-layout';
import {baseUrl} from '../constant/baseurl';
import React from 'react';

const fetchAllUsers = async () => {
  const {data} = await axios.get(`${baseUrl}/getAllUsers`);
  return data;
};

const Customers = () => {
  const {data, isLoading} = useQuery('allUsers', fetchAllUsers, {
    retry: false,
    refetchOnWindowFocus: false,
  });

  console.log('-----users----', data);

  if (isLoading) {
    return <Loader />;
  }

  return (
    <DashboardLayout>
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          py: 8,
        }}>
        <Container maxWidth={false}>
          {/* <CustomerListToolbar /> */}
          <Box sx={{mt: 3}}>
            <CustomerListResults users={data?.users} />
          </Box>
        </Container>
      </Box>
    </DashboardLayout>
  );
};

export default authHoc(Customers);

// Customers.getLayout = (page) => <DashboardLayout>{page}</DashboardLayout>;

// export async function getServerSideProps(context) {
//   try {
//     const { data } = await axios.get(`${baseUrl}/api/admin/getAllUsers`);
//     console.log("---allusers---", data);
//     return {
//       props: { data },
//     };
//   } catch (error) {
//     console.error("----errr---", error?.response?.data);
//     if (error?.response?.data?.error === "Invalid auth key") {
//     }
//     return {
//       redirect: {
//         destination: "/login",
//         permanent: false,
//       },
//     };
//   }
// }
