import {CacheProvider} from '@emotion/react';
import {CssBaseline} from '@mui/material';
import {ThemeProvider} from '@mui/material/styles';
import Head from 'next/head';
import {useEffect, useState} from 'react';
import {QueryClient, QueryClientProvider} from 'react-query';
import {AuthContextProvider} from 'src/context/auth';
import {theme} from '../theme';
import {createEmotionCache} from '../utils/create-emotion-cache';

const clientSideEmotionCache = createEmotionCache();

const App = props => {
  const {Component, emotionCache = clientSideEmotionCache, pageProps} = props;

  const getLayout = Component.getLayout ?? (page => page);
  const queryClient = new QueryClient();

  const [token, settoken] = useState(null);

  useEffect(() => {
    const authtoken = localStorage.getItem('admin_token');
    settoken(authtoken);
  }, []);

  return (
    <CacheProvider value={emotionCache}>
      <Head>
        <title>4ward</title>
        <meta name="viewport" content="initial-scale=1, width=device-width" />
      </Head>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <QueryClientProvider client={queryClient}>
          <>{getLayout(<Component {...pageProps} />)}</>
        </QueryClientProvider>
      </ThemeProvider>
    </CacheProvider>
  );
};

export default App;

// admin pass admin123
