export const baseUrl = 'http://localhost:5001/ward-355712/us-central1';
// export const baseUrl = 'https://us-central1-ward-355712.cloudfunctions.net';
