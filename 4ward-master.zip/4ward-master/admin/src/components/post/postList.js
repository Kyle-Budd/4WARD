import {
  Avatar,
  Box,
  Button,
  Card,
  Modal,
  Switch,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TextField,
} from '@mui/material';
import axios from 'axios';
import PropTypes from 'prop-types';
import {useCallback, useState} from 'react';
import PerfectScrollbar from 'react-perfect-scrollbar';
import {useMutation, useQueryClient} from 'react-query';
import {baseUrl} from 'src/constant/baseurl';
import {getInitials} from '../../utils/get-initials';
import DeleteIcon from '@mui/icons-material/Delete';
import ViewIcon from '@mui/icons-material/RemoveRedEyeOutlined';
import LocationIcon from '@mui/icons-material/LocationCity';
import TimeIcon from '@mui/icons-material/LockClock';
import PhoneIcon from '@mui/icons-material/Phone';
import {User as UserIcon} from '../../icons/user';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';

import React from 'react';

export const PostListResults = ({posts, ...rest}) => {
  const queryClient = useQueryClient();

  const [open, setOpen] = useState(false);
  const [editedPost, setEditedPost] = useState(null);
  const [postUser, setPostUser] = useState(null);
  const handleOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
    setEditedPost(null);
    setPostUser(null);
  };

  const {mutate: edPMut, isLoading} = useMutation(
    async variables => {
      const {data} = await axios.put(
        `${baseUrl}/editPost`,

        variables,
      );
      return data;
    },
    {
      onSuccess: (d, v) => {
        queryClient.setQueryData('allPosts', old => {
          return {
            ...old,
            posts: old.posts.map(p => (p.id === v.postId ? editedPost : p)),
          };
        });
        handleClose();
        // queryClient.invalidateQueries('allPosts')
      },
    },
  );
  const {mutate: delMut} = useMutation(
    async variables => {
      const {data} = await axios.put(
        `${baseUrl}/deletePost`,

        variables,
      );
      return data;
    },
    {
      onSuccess: async (d, v) => {
        await queryClient.setQueryData('allPosts', old => {
          return {
            ...old,
            posts: old.posts.filter(p => p.id !== v.postId),
          };
        });
        // queryClient.invalidateQueries('allPosts')
      },
    },
  );

  const handleChange = useCallback(
    event => {
      if (editedPost?.type !== 'sos') {
        setEditedPost(p => ({...p, description: event.target.value}));
      }
    },
    [editedPost],
  );

  const handelDeletePost = useCallback(id => {
    console.log(id);
    delMut({postId: id});
  }, []);

  const handleEditPost = useCallback(
    id => {
      if (editedPost?.type === 'sos') {
        return;
      }
      edPMut({
        postId: editedPost?.id,
        ...editedPost,
      });
    },
    [editedPost],
  );

  const handelSetPost = useCallback(post => {
    console.log(post);

    setEditedPost(post);
    handleOpen();
  }, []);

  return (
    <>
      <Card {...rest}>
        <PerfectScrollbar style={{overflowX: 'auto'}}>
          <Box sx={{minWidth: 1050}}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>ID</TableCell>
                  <TableCell>Type</TableCell>
                  <TableCell>Address</TableCell>
                  <TableCell>Date</TableCell>
                  <TableCell>View</TableCell>
                  <TableCell>Delete</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {posts?.map((p, id) => (
                  <TableRow hover key={id}>
                    <TableCell>{p?.post?.id}</TableCell>
                    <TableCell>{p?.post?.type}</TableCell>
                    <TableCell>
                      {p?.post?.address || p?.post?.location?.address}
                    </TableCell>
                    <TableCell>
                      {new Date(
                        p?.post?.date?._seconds * 1000,
                      ).toLocaleDateString()}{' '}
                      {new Date(
                        p?.post?.date?._seconds * 1000,
                      ).toLocaleTimeString()}
                    </TableCell>

                    <TableCell
                      onClick={() => {setPostUser(p?.user);handelSetPost(p?.post)}}
                      sx={{':hover': {cursor: 'pointer'}}}>
                      <ViewIcon color="error" />
                    </TableCell>
                    <TableCell
                      onClick={() => handelDeletePost(p?.post?.id)}
                      sx={{':hover': {cursor: 'pointer'}}}>
                      <DeleteIcon color="error" />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Box>
        </PerfectScrollbar>
      </Card>

      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description">
        <DialogTitle id="alert-dialog-title">
          {editedPost?.type === 'icon'
            ? `${editedPost?.type} (${editedPost?.iconType})`
            : editedPost?.type}
        </DialogTitle>
        <DialogContent sx={{maxWidth: 500, width: 500}}>
          <Box display={'flex'} justifyContent="center" alignItems={'center'}>
            {editedPost && (
              <img
                alt="map"
                src={editedPost.mapImage}
                width={200}
                height={200}
              />
            )}
            {editedPost && editedPost?.imageUrl && (
              <img
                alt="map"
                src={editedPost?.imageUrl}
                width={200}
                height={200}
              />
            )}
            {editedPost && editedPost?.videoUrl && (
              <video
                alt="map"
                src={editedPost?.videoUrl}
                width={200}
                height={200}
                autoPlay={false}
              />
            )}
          </Box>
            {editedPost?.type !== 'sos' && (
              <TextField
                id="filled-multiline-flexible"
                label="Description"
                multiline
                maxRows={4}
                fullWidth
                sx={{mt: 2}}
                value={editedPost?.description}
                onChange={handleChange}
                variant="filled"
              />
            )}
          <DialogContentText
            id="alert-dialog-description"
            mt={2}
            alignItems="center"
            display={'flex'}
            style={{gridGap: '10px'}}>
            <LocationIcon />{' '}
            {editedPost?.address || editedPost?.location?.address}
          </DialogContentText>
          <DialogContentText
            id="alert-dialog-description"
            mt={2}
            alignItems="center"
            display={'flex'}
            style={{gridGap: '10px'}}>
            <TimeIcon />{' '}
            {new Date(editedPost?.date?._seconds * 1000).toLocaleDateString()}{' '}
            {new Date(editedPost?.date?._seconds * 1000).toLocaleTimeString()}
          </DialogContentText>
         {postUser && <DialogContentText
            id="alert-dialog-description"
            mt={2}
            alignItems="center"
            display={'flex'}
            style={{gridGap: '10px'}}>
           <UserIcon/>
            {postUser?.userName || `User ${postUser?.id.slice(-5)}`}
          </DialogContentText>}
         {postUser && <DialogContentText
            id="alert-dialog-description"
            mt={2}
            alignItems="center"
            display={'flex'}
            style={{gridGap: '10px'}}>
           <PhoneIcon/>
            {postUser?.phone}
          </DialogContentText>}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} disabled={isLoading}>
            Cancel
          </Button>
          <Button onClick={handleEditPost} autoFocus disabled={isLoading}>
            Update
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};
