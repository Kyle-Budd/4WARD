import axios from "axios";
import React, { createContext, useContext, useEffect, useState } from "react";
import { useQuery } from "react-query";

const AuthContext = createContext();

export const AuthContextProvider = ({ children }) => {
  const [isAuth, setisAuth] = useState(null);
  const [authUser, setAuthUser] = useState(null);

  useQuery(
    "loadKey",
    () => {
      const token = localStorage.getItem("admin_token");
      return token;
    },
    {
      onSuccess: (d) => {
        if (d) {
          console.log("data", d);
          setisAuth(d);
          axios.defaults.headers.common.Authorization = `Bearer ${d}`;
        } else setisAuth(null);
      },
    }
  );

  return (
    <AuthContext.Provider
      value={{
        isAuth,
        setisAuth,
        authUser,
        setAuthUser,
      }}
    >
      <>{children}</>
    </AuthContext.Provider>
  );
};

export const AuthState = () => useContext(AuthContext);
