export const baseUrl = 'https://us-central1-ward-355712.cloudfunctions.net';
// export const baseUrl = 'http://192.168.29.154:5000';

// export const baseUrl = '​http://192.168.29.154:5001/ward-355712/us-central1';
