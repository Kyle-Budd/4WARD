export const API_KEY = 'AIzaSyCtjsZQHADLPVsE1X8iZu6iWG9Eopm00OA';
