import auth from '@react-native-firebase/auth';
import firestore from '@react-native-firebase/firestore';
import React, { useCallback, useState, useEffect } from 'react';
import {
  KeyboardAvoidingView,
  ScrollView,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import Customloader from '../components/loader';
import { AuthState } from '../context/authState';
import pagestyles from '../styles/setupprofile.style';
import { useInteractionManager } from '../utils/customHooks';

import Loader from '../components/loader/Loader';
// import Loader from '../components/loader';
import AsyncStorage from '@react-native-async-storage/async-storage';

const EnterOtpScreen = (props) => {
  const { loadScreen } = useInteractionManager();

  const {
    confirm,
    setConfirm,
    phoneNumber,
    countryCode,
    myLocation,
    deviceToken,
    setUserBan,
  } = AuthState();

  const [code, setCode] = useState(null);
  const [loading, setLoading] = useState(false);

  const storeData = async (value) => {
    try {
      await AsyncStorage.setItem('user', JSON.stringify(value));
    } catch (e) {
      // saving error
    }
  }

  useEffect(() => {
    confirm.confirm(code);
    save_user_info();
  }, []);

  const save_user_info = async (value) => {
    let obj = {
      cca2: props?.route?.params?.cca2,
      callingCode: props?.route?.params?.callingCode,
      email: props?.route?.params?.email
    }

    try {
      await AsyncStorage.setItem('numberObj', JSON.stringify(obj));
    } catch (e) {
      // saving error
    }
  }

  const handelConfirmCode = useCallback(async () => {

    try {
      await confirm.confirm(code);

      if (!myLocation) {
        alert('Location not found');
        return;
      }

      auth().onAuthStateChanged(async user => {
        try {
          await AsyncStorage.setItem('user', 'Yes');
        } catch (e) {
          // saving error
        }
        // const userRef = firestore().collection('users');

        // const whereUser = (await userRef.where('id', '==', user?.uid).get()).docs;
        // const userRef = ;
        console.log(user);// uid not found .....   check here
        const whereUser = (await firestore().collection('users').where('id', '==', user?.uid).get()).docs;

        if (whereUser.length == 0) {
          // user not exists
          await firestore().collection('users').doc(user?.uid).set({
            id: user?.uid,
            phone: user?.phoneNumber.slice(1),
            location: myLocation,
            token: deviceToken,
            email: props?.route?.params?.email
          });
        } else {
          //   user exists 9804750147 123456 4ward@yopmail.com
          if (whereUser[0]?._data?.banStatus) {
            alert('Your account is deactivated');
            setUserBan(whereUser[0]?._data?.banStatus);
            return;
          } else {
            console.log('id',user?.uid);
            console.log('phone',user?.phoneNumber.slice(1));
            console.log('location',myLocation);
            console.log('token',deviceToken);
            console.log('email',props?.route?.params?.email);
            setUserBan(false);

            await firestore().collection('users').doc(user?.uid).update({
              
              id: user?.uid,
              phone: user?.phoneNumber.slice(1),
              location: myLocation,
              token: deviceToken,
              email: props?.route?.params?.email
            }).catch(e=>console.log('error',e));
          }
        }
      });
    } catch (error) {
      setLoading(false);
      alert('Please check your OTP.');
      console.error('----error---', error);
    } finally {
      setCode(null);
      // setIsUserExists(false);
    }
  }, [code, myLocation, deviceToken]);

  const handelResendCode = useCallback(async () => {
    try {
      const confirmation = await auth().signInWithPhoneNumber(
        // `+${countryCode}${phoneNumber}`,
        props?.route?.params?.phone
      );
      setConfirm(confirmation);
      alert('Successfully send code');
      // console.log(phoneNumber);
    } catch (error) {
      console.error(error);
      alert('Something went wrong');
    }
  }, [phoneNumber, countryCode]);

  if (loadScreen) {
    return <Customloader />;
  }

  return (
    <>
      <KeyboardAvoidingView
        // behavior="height"
        style={{ flex: 1, backgroundColor: '#000' }}>
        <ScrollView style={pagestyles.scrollView}>
          <View style={pagestyles.contentContainer}>
            <View>
              <Text style={pagestyles.title1}>We just sent a code to</Text>
              <Text style={pagestyles.subTxt}>
                {countryCode}
                {phoneNumber}
              </Text>
            </View>

            <View style={pagestyles.formsetup}>
              <View style={{ paddingBottom: 20 }}>
                <Text style={pagestyles.lableTitle}>*ENTER CODE</Text>
                <TextInput
                  style={{
                    fontSize: 18,
                    textAlign: 'left',
                    backgroundColor: '#7D797A',
                    borderRadius: 10,
                    padding: 13,
                    // textAlign: 'left',
                  }}
                  placeholder=""
                  // underlineColorAndroid="transparent"
                  placeholderTextColor="#fff"
                  color="#fff"
                  value={code}
                  onChangeText={setCode}
                  secureTextEntry={false}
                  keyboardType={'numeric'}
                />
              </View>

              <TouchableOpacity
                style={{ marginBottom: 20 }}
                // onPress={handelConfirmCode}
                onPress={() => {
                  if (code) {
                    setLoading(true);
                    handelConfirmCode();
                  }
                  else {
                    alert('Please enter your CODE.');
                    // console.log(props.route.params.phone);
                  }
                }}

              >
                <View style={pagestyles.btn2}>
                  <Text style={pagestyles.signText}> VERIFY CODE </Text>
                </View>
              </TouchableOpacity>

              <View style={pagestyles.terms}>
                <Text style={[pagestyles.whitClr]}> Haven't receive it? </Text>
                <TouchableOpacity onPress={handelResendCode}>
                  <Text style={pagestyles.redColor}>Resend</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
      {loading ? <Loader /> : null}
    </>
  );
};

export default EnterOtpScreen;

//  userRef
//           .doc(user.uid)
//           .get()
//           .then(async docSnapShot => {
//             console.log('---existing---', docSnapShot);
//             if (!docSnapShot?.exists) {
//               console.log('---user not exist---');

//               userRef
//                 .doc(user.uid)
//                 .set({
//                   id: user.uid,
//                   phone: user.phoneNumber.slice(1),
//                   location: myLocation,
//                   token,
//                 })
//                 .then(() => console.log('---userset---'))
//                 .catch(e => console.log('----user-not-set----', e));
//             } else {
//               console.log('---user exists---');

//               await userRef.doc(user.uid).update({
//                 id: user.uid,
//                 phone: user.phoneNumber.slice(1),
//                 location: myLocation,
//                 token,
//               });
//             }
//           })
//           .catch(e => {
//             console.error('---error---', e);
//           });
