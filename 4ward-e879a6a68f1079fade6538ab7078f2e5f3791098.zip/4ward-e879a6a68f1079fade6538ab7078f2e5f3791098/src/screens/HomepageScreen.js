import firestore from '@react-native-firebase/firestore';
import axios from 'axios';
import * as geofirestore from 'geofirestore';
import {
  Actionsheet,
  Button,
  Icon,
  KeyboardAvoidingView,
  Pressable,
  ScrollView,
  Spinner,
  Text,
  useDisclose,
  View,
  VStack,
} from 'native-base';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Dimensions, SafeAreaView } from 'react-native';
import uuid from 'react-native-uuid';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import GoogleSearch from '../components/GoogleSearch';
import Customloader from '../components/loader';
import MapCmp from '../components/MapCmp';
import { AuthState } from '../context/authState';
import { PostState } from '../context/postState';
import { API_KEY } from '../utils/apiKey';
import { baseUrl } from '../utils/baseUrl';
import { useInteractionManager } from '../utils/customHooks';
import AlertCard from '../components/AlertCard';
const firestoreApp = firestore();
const GeoFirestore = geofirestore.initializeApp(firestoreApp);
import moment from 'moment';
import AsyncStorage from '@react-native-async-storage/async-storage';

let identity;

const HomepageScreen = props => {
  const { params } = props?.route;
  const mapViewRef = useRef(null);
  const { loadScreen } = useInteractionManager();
  const { isOpen, onOpen, onClose } = useDisclose();
  const [postLoading, setPostLoading] = useState(true);
  const [nearbyPosts, setNearbyPosts] = useState([]);

  const { authUser, myLocation, user, setAuthUser } = AuthState();

  const { postCenter, postRadius, imageSrcList, setimageSrcList } = PostState();

  const [center, setcenter] = useState(null);
  const [searchLocation, setSearchLocation] = useState(null);
  // const [identity, setIdentity] = useState();

  useEffect(() => {
    try {
      if (postCenter && postRadius) {
        GeoFirestore.collection('posts')
          .near({
            center: new firestore.GeoPoint(
              postCenter.latitude,
              postCenter.longitude,
            ),
            radius: postRadius,
          })
          // .where('emergencyUsers', 'in', ['917908566088'])
          .limit(10)
          // .orderBy('date', 'desc')
          .onSnapshot(
            async querySnapshot => {
              let postArr = [
                ...querySnapshot.docs.map(d => ({
                  ...d.data(),
                  datetime: moment(d.data().date.seconds * 1000).format('LLL')
                })),
              ];
              let arr = postArr.sort(function (a, b) {
                // Turn your strings into dates, and then subtract them
                // to get a value that is either negative, positive, or zero.
                return new Date(b.datetime) - new Date(a.datetime);
              });

              let array = [];
              //only see the emergency contact users
              for (let i = 0; i < arr.length; i++) {
                if (arr[i].emergencyUsers) {
                  let data = arr[i].emergencyUsers;
                  for (let j = 0; j < data.length; j++) {
                    if ('+' + user?.phone == data[j]) {
                      array.push(arr[i]);
                    }
                  }
                }
              }

              // setNearbyPosts(arr);
              setNearbyPosts(array);
              setPostLoading(false);
            },
            err => {
              alert('Something went wrong');
              console.log(`Encountered error: ${err}`);
              setPostLoading(false);
            },
          );
      }
    } catch (error) {
      console.log(error);
      // alert('faild to fetch posts');
    }
  }, [postCenter, postRadius]);

  useEffect(() => {
    if (myLocation) {
      setcenter({
        latitude: myLocation?.location?.latitude,
        longitude: myLocation?.location?.longitude,
      });
    }

    if (params?.coords) {
      setcenter({
        latitude: params?.coords?.lat,
        longitude: params?.coords?.lon,
      });
    }
    // getData();
  }, [myLocation, params, user]);

  useEffect(() => {
    const focusListener = props.navigation.addListener('focus', () => {
      getData();
    });

    return focusListener;
  }, [props.navigation, user]);

  const getData = async () => {
    // try {
    //   const value = await AsyncStorage.getItem('numberObj')
    //   if (value !== null) {
    //     // value previously stored
    //     let data = JSON.parse(value);
    //     if (user?.email == '') {
    //       try {
    //         await firestore()
    //           .doc(`users/${user?.id}`)
    //           .update({
    //             email: data?.email
    //           });
    //         // setPostRadius(radius);
    //         // toast.show({
    //         //   description: 'Profile updated',
    //         // });
    //       } catch (error) {
    //         console.error(error);
    //         console.log('profile update failed');
    //       }
    //     }
    //   }
    // } catch (e) {
    //   // error reading value
    // }

    try {
      const value = await AsyncStorage.getItem('show_identity');
      if (value !== null) {
        // value previously stored
        // setIdentity(value == 'true' ? true : false);
        let identity_status = value == 'true' ? true : false;
        identity = identity_status;
      }
      else {
        identity = false;
      }
    } catch (e) {
      // error reading value
    }
  }

  const handelSendSos = useCallback(async () => {

    list = [];
    list.push('+' + user?.phone);
    let _list = await firestore()
      .collection('emergencyContacts')
      // Filter results
      .where('id', '==', user?.id)
      .get()
      .then(querySnapshot => {
        querySnapshot.forEach((user) => {
          list.push('+' + user.data().code + user.data().mobile);
        });
        return list;
      });

    if (!myLocation) {
      alert('No location found');
      return;
    }

    const id = uuid.v4();

    const postData = {
      id,
      userId: authUser?.uid,
      type: 'sos',
      emergencyUsers: _list,
      address: myLocation?.address,
      // identity: user?.identity,
      identity: identity,
      coordinates: new firestore.GeoPoint(
        myLocation?.location?.latitude,
        myLocation?.location?.longitude,
      ),
      mapImage: `https://maps.googleapis.com/maps/api/staticmap?zoom=15&size=400x400&format=PNG&markers=${myLocation?.location?.latitude},${myLocation?.location?.longitude}&key=${API_KEY}`,
      // location: myLocation,
      date: firestore.FieldValue.serverTimestamp(),
    };

    await GeoFirestore.collection('posts').doc(id).set(postData);

    // await firestore().collection('posts').doc(id).set(postData);

    await axios.post(`${baseUrl}/sendNotifications`, {
      uid: authUser?.uid,
      type: 'sos',
      location: myLocation,
    }).then(res => console.log(res)).catch(err => console.log(err))
    onClose();
    props?.navigation.navigate('Story');
  }, [authUser, myLocation, user]);

  const handelnavigate = useCallback(type => {
    setimageSrcList([]);
    onClose();
    if (type === 'image') {
      props?.navigation.navigate('Camera', { type });
    } else if (type === 'video') {
      props?.navigation.navigate('Camera', { type });
    } else if (type === 'IconReport') {
      props?.navigation.navigate('IconReport');
    }
  }, []);

  const handelAnimate = useCallback(() => {
    mapViewRef?.current?.animateCamera(
      {
        pitch: 1,
        heading: 1,
        altitude: 10,
        zoom: 15,
        center: {
          latitude: myLocation?.location?.latitude,
          longitude: myLocation?.location?.longitude,
        },
      },
      { duration: 500 },
    );
  }, [myLocation, mapViewRef]);

  if (loadScreen || !myLocation) {
    return <Customloader />;
  }

  return (
    <KeyboardAvoidingView behavior="height" bg="#fff" flex={1}>
      <SafeAreaView style={{ flex: 1, backgroundColor: '#fff' }}>
        <View style={{ flex: 1, backgroundColor: '#fff' }}>
          {/* <View h="24" bg="error.50" w="full" pt={10} px="4" zIndex={100}>
        </View> */}
          <GoogleSearch
            setSearchLocation={setSearchLocation}
            handelAnimate={handelAnimate}
          />
          {myLocation && center && (
            <MapCmp
              center={center}
              searchLocation={searchLocation}
              setSearchLocation={setSearchLocation}
              mapViewRef={mapViewRef}
              handelAnimate={handelAnimate}
            />
          )}

          <View my={'2'} mx={'4'}>
            <Button onPress={onOpen} bg="error.500">
              <Text fontSize={'lg'} fontWeight="bold" color={'#fff'}>
                Report an incident
              </Text>
            </Button>
          </View>

          {postLoading ? (
            <View
              style={{
                height: Dimensions.get('window').height * 0.3,
                flex: 1,
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <Spinner size={'lg'} color="#900" />
            </View>
          ) : (
            <>
              {nearbyPosts?.length > 0 && (
                <View
                  style={{
                    height: Dimensions.get('window').height * 0.3,
                  }}>
                  <ScrollView>
                    <View>
                      {nearbyPosts?.map((p, i) => (
                        <AlertCard key={i} {...p} setcenter={setcenter} />
                      ))}
                    </View>
                    {/* <View>
                {posts &&
                  posts?.length > 0 &&
                  posts
                    ?.filter(item => !item?.addMob)
                    ?.map((p, i) => (
                      <AlertCard key={i} {...p} setcenter={setcenter} />
                    ))}
              </View> */}
                  </ScrollView>
                </View>
              )}
            </>
          )}
          <Actionsheet isOpen={isOpen} onClose={onClose} hideDragIndicator>
            <Actionsheet.Content>
              <Pressable
                w="full"
                justifyContent={'center'}
                alignItems="center"
                p="1"
                onPress={onClose}>
                <MaterialCommunityIcons name="chevron-down" size={30} />
              </Pressable>
              <Actionsheet.Item
                onPress={() => handelnavigate('image')}
                bg={'gray.200'}
                my={'1'}
                justifyContent="center"
                startIcon={
                  <Icon
                    as={MaterialCommunityIcons}
                    color="error.500"
                    mr="1"
                    mt="3"
                    size="6"
                    name="camera"
                  />
                }>
                <VStack>
                  <Text fontSize={'lg'} fontWeight="bold">
                    IMAGE REPORT
                  </Text>
                  <Text fontSize={'sm'} fontWeight="medium">
                    For quick snap shot or live record
                  </Text>
                </VStack>
              </Actionsheet.Item>
              <Actionsheet.Item
                onPress={() => handelnavigate('IconReport')}
                bg={'gray.200'}
                my={'1'}
                justifyContent="center"
                startIcon={
                  <Icon
                    as={MaterialCommunityIcons}
                    color="error.500"
                    mr="1"
                    mt={'3'}
                    size="6"
                    name="plus-thick"
                  />
                }>
                <VStack>
                  <Text fontSize={'lg'} fontWeight="bold">
                    ICON REPORT
                  </Text>
                  <Text fontSize={'sm'} fontWeight="medium">
                    For quick one tap report
                  </Text>
                </VStack>
              </Actionsheet.Item>
              <Actionsheet.Item
                onPress={handelSendSos}
                bg={'gray.200'}
                my={'1'}
                justifyContent="center"
                startIcon={
                  <Icon
                    as={MaterialCommunityIcons}
                    color="error.500"
                    mr="1"
                    mt="3"
                    size="6"
                    name="alert-circle"
                  />
                }>
                <VStack>
                  <Text fontSize={'lg'} fontWeight="bold">
                    SOS
                  </Text>
                  <Text fontSize={'sm'} fontWeight="medium">
                    For quick emergency report
                  </Text>
                </VStack>
              </Actionsheet.Item>
            </Actionsheet.Content>
          </Actionsheet>
        </View>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};

export default HomepageScreen;

// : (
//               <View my={'5'} justifyContent="center" alignItems={'center'}>
//                 <Text fontSize={'md'} fontWeight="bold">
//                   You have no feeds in range
//                 </Text>
//               </View>
//             )

{
  /* <BtnSection handelSendSos={handelSendSos} onOpen={onOpen} /> */
}

// <Actionsheet.Item
//             onPress={() => handelnavigate('video')}
//             bg={'gray.200'}
//             my={'1'}
//             justifyContent="center"
//             startIcon={
//               <Icon
//                 as={MaterialCommunityIcons}
//                 color="error.500"
//                 mr="1"
//                 size="6"
//                 name="record"
//               />
//             }>
//             <Text fontSize={'lg'}>REPORT LIVE</Text>
//           </Actionsheet.Item>

{
  /* <Text
              style={[
                pagestyles.title,
                {marginBottom: 20, textAlign: 'center'},
              ]}>
              ALERTS
            </Text> */
}

{
  /* {myLocation && (
          <View
            style={[
              pagestyles.headerSec,
              {position: 'absolute', top: 5, left: 10, right: 10},
            ]}>
            {user?.profilePic ? (
              <Image
                source={{
                  uri: user?.profilePic,
                }}
                style={[
                  pagestyles.user,
                  {position: 'relative', top: 5, borderRadius: 50},
                ]}
              />
            ) : (
              <Image
                source={require('../assets/images/user1.png')}
                style={[pagestyles.user, {position: 'relative', top: 5}]}
              />
            )}
            <View style={pagestyles.SearchSec}>
              <View style={pagestyles.SectionStyle}>
                <View style={{width: 19}}>
                  <Image
                    source={require('../assets/images/search2.png')}
                    style={pagestyles.ImageStyle}
                  />
                </View>
                <TextInput
                  style={{flex: 1, fontSize: 14, borderRadius: 15}}
                  placeholder="Centerville, MD"
                  underlineColorAndroid="transparent"
                  placeholderTextColor="#fff"
                  color="#fff"
                  // secureTextEntry={true}
                />
              </View>
            </View>
          </View>
        )} */
}

{
  /* <ImageBackground
                          source={require('../assets/images/map2.png')}
                          resizeMode={'cover'}
                          style={pagestyles.mapBg}>
                          <View style={pagestyles.container}>
                              <View style={pagestyles.headerSec}>
                                  <Image
                                      source={require('../assets/images/user1.png')}
                                      style={[pagestyles.user, { position: 'relative', top: 5 }]}
                                  />
                                  <View style={pagestyles.SearchSec}>
                                      <View style={pagestyles.SectionStyle}>
                                          <View style={{ width: 19 }}>
                                              <Image
                                                  source={require('../assets/images/search2.png')}
                                                  style={pagestyles.ImageStyle}
                                              />
                                          </View>
                                          <TextInput
                                              style={{ flex: 1, fontSize: 14, borderRadius: 15 }}
                                              placeholder="Centerville, MD"
                                              underlineColorAndroid="transparent"
                                              placeholderTextColor="#fff"
                                              color="#fff"
                                          // secureTextEntry={true}
                                          />
                                      </View>
                                  </View>
                              </View>
  
                              <View style={pagestyles.locatnWrap}>
                                  <View style={pagestyles.locatnCircl}>
                                      <Image
                                          source={require('../assets/images/user1.png')}
                                          style={pagestyles.user}
                                      />
                                  </View>
                              </View>
                          </View>
  
                       
                      </ImageBackground> */
}