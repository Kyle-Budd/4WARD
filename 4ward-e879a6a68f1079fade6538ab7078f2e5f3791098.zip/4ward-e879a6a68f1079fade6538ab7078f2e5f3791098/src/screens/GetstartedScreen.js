import React, { useCallback, useState, useEffect } from 'react';
import {
  View,
  Button,
  Text,
  Image,
  ImageSourcePropType,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  KeyboardAvoidingView,
  TextInput,
  ScrollView,
  ImageBackground,
} from 'react-native';
import styles, { ThemeColors } from '../styles/main.style';
import pagestyles from '../styles/getstated.style';
import { AuthState } from '../context/authState';

import firestore from '@react-native-firebase/firestore';

const GetstartedScreen = ({ navigation }) => {
  const { authUser, setAuthUser } = AuthState();

  const handelGetStart = useCallback(() => {
    if (authUser) {
      console.log(authUser);
      navigation.navigate('Homepage');
    } else {
      navigation.navigate('Auth', { screen: 'Login' });
    }
  }, [authUser]);
  // useEffect(() => {
  //   checkExistingInfo()
  // }, []);

  // const checkExistingInfo = useCallback(async () => {
  //   const confirmation = await firestore()
  //   .collection("users")
  //   .where('phone', '==', `+919804750147`)
  //   .get()

  //   // const confirmation = await firestore()
  //   // .collection("users")
  //   // .get();
  //   console.log('firebase firebase firebase firebase....................................');
  // });


  return (
    <>
      <SafeAreaView style={{ flex: 1, backgroundColor: '#fff' }}>
        {/* <ScrollView style={pagestyles.scrollView}> */}

        <View style={pagestyles.getstatedWrap}>
          <View>
            <Image
              source={require('../assets/images/logo.png')}
              style={{ width: 135, height: 174 }}
            />
          </View>

          <View>
            <View>
              <Text style={pagestyles.TitleOne}>Seeing 4WARD</Text>
            </View>

            <View>
              <Text style={pagestyles.subTxt}>
                {' '}
                4WARD uses geo-location technology to accurately pin-point
                incidents to keep you safe and to report suspicious or dangerous
                activities.
              </Text>
            </View>
          </View>

          <TouchableOpacity
            style={{ position: 'relative' }}
            onPress={handelGetStart}>
            <ImageBackground
              source={require('../assets/images/btn1.png')}
              resizeMode={'contain'}
              style={pagestyles.btn1}>
              <Text style={pagestyles.getTxt}>GET STARTED</Text>
            </ImageBackground>
          </TouchableOpacity>

          <View style={pagestyles.lockSec}>
            <View style={pagestyles.lockWrap}>
              <Image
                source={require('../assets/images/lock.png')}
                style={pagestyles.lockImg}
              />
              <Text style={{ color: '#000' }}>
                We hate spammers and hope they get kicked in the gut. Your
                information is a 100% protected by Ninjas.
              </Text>
            </View>

            <View>
              <Text style={pagestyles.redTxt}>
                See how 4WARD's innovative technology uses geolocation.
              </Text>
            </View>
          </View>
        </View>

        {/* </ScrollView> */}
      </SafeAreaView>
    </>
  );
};

export default GetstartedScreen;
