import {useIsFocused} from '@react-navigation/native';
import {Box, HStack, Image, Pressable, Text} from 'native-base';
import React, {useCallback, useRef, useState} from 'react';
import {Dimensions, SafeAreaView, StyleSheet} from 'react-native';
import McIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import {Camera, useCameraDevices} from 'react-native-vision-camera';
import Customloader from '../components/loader';
import {AuthState} from '../context/authState';
import {PostState} from '../context/postState';
import {
  getReturnValues,
  useAskMediaPermission,
  useCountdown,
} from '../utils/customHooks';

const TakeVideoScreen = ({navigation}) => {
  const devices = useCameraDevices('wide-angle-camera');
  const device = devices.back;
  const camera = useRef(null);
  const isFocused = useIsFocused();
  const {user} = AuthState();
  const {videoSrc, setvideoSrc} = PostState();
  const [isRecord, setisRecord] = useState(false);
  const [vedioDetails, setVedioDetails] = useState(null);
  const [minutes, seconds] = useCountdown(isRecord);

  useAskMediaPermission();

  const handelrecordVideo = useCallback(async () => {
    console.log('----runn1111----');
    try {
      // if (isCameraPermission) {
      await camera.current.startRecording({
        onRecordingFinished: video => {
          console.log('----video---', video);
          setvideoSrc(video?.path);
          setVedioDetails({
            duration: {
              mins: getReturnValues(parseInt(video?.duration))[0],
              secs: getReturnValues(parseInt(video?.duration))[1] + 1,
            },
            size: (video?.size / 1000).toFixed(2),
          });
        },
        onRecordingError: error => {
          console.error(error);
          alert('can not record a video!');
          navigation.navigate('MainTab', {screen: 'Homepage'});
        },
      });
      console.log('----runn----');
      setisRecord(true);
      // }
    } catch (error) {
      console.error('---err---', error);
      alert('can not record a video!');
      navigation.navigate('MainTab', {screen: 'Homepage'});
    }
  }, [camera]);

  const handelStopRecord = useCallback(async () => {
    await camera.current.stopRecording();
    setisRecord(false);
  }, []);

  const handelNavigate = useCallback(() => {
    if (!videoSrc) {
      alert('please record a video');
      return;
    }
    navigation.navigate('SnapShot', {type: 'video'});
  }, [videoSrc]);

  const handelNavigateCamera = useCallback(() => {
    navigation.navigate('TakeSnap');
  }, []);

  if (device == null) return <Customloader />;

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#000'}}>
      <HStack
        w="full"
        justifyContent={'space-between'}
        alignItems="center"
        p={'5'}>
        {user ? (
          <Image
            alt="my-img"
            source={{
              uri: user?.profilePic,
            }}
            style={[styles.user]}
          />
        ) : (
          <Image
            alt="my-img"
            source={require('../assets/images/user1.png')}
            style={[styles.user]}
          />
        )}
        <Text color="#fff" fontSize={22}>
          Record a video
        </Text>
        <McIcon
          name="close"
          color={'#fff'}
          size={30}
          onPress={() => navigation.navigate('MainTab', {screen: 'Homepage'})}
        />
      </HStack>

      <Camera
        video={true}
        audio={true}
        ref={camera}
        style={styles.camera}
        device={device}
        isActive={isFocused}
        onError={() => console.log('can not get video')}
      />

      {!vedioDetails && (
        <HStack justifyContent={'center'} alignItems="center" w={'full'} mt="2">
          <Text color={'#fff'} fontWeight="semibold" fontSize="lg">
            {minutes} : {seconds ? seconds + 1 : 0}
          </Text>
        </HStack>
      )}

      {!isRecord && vedioDetails && (
        <HStack
          space={'4'}
          justifyContent={'center'}
          alignItems="center"
          w={'full'}
          my="2">
          <Text color={'#fff'} fontWeight="semibold" fontSize="md">
            duration:{' '}
            {vedioDetails?.duration?.mins > 0
              ? vedioDetails?.duration?.mins
              : 0}{' '}
            : {vedioDetails?.duration?.secs}
          </Text>
          <Text color={'#fff'} fontWeight="semibold" fontSize="md">
            size: {vedioDetails?.size} mb
          </Text>
        </HStack>
      )}

      <HStack
        space={'10'}
        justifyContent={'center'}
        alignItems="center"
        w={'full'}
        p="2"
        flex={1}>
        {isRecord ? (
          <McIcon name="record-rec" size={40} color={'#900'} />
        ) : (
          <McIcon name="record" size={40} color={'#900'} />
        )}
        {/* <Pressable
          bg={'#fff'}
          w={'10'}
          h={'10'}
          rounded={'full'}
          justifyContent="center"
          alignItems={'center'}
          onPress={handelNavigateCamera}>
          <McIcon name="camera" size={20} />
        </Pressable> */}
        {!isRecord ? (
          <Pressable
            bg={'#fff'}
            w={'16'}
            h={'16'}
            rounded={'full'}
            justifyContent="center"
            alignItems={'center'}
            onPress={handelrecordVideo}>
            <McIcon name="video" size={30} />
          </Pressable>
        ) : (
          <Pressable
            bg={'#fff'}
            w={'16'}
            h={'16'}
            rounded={'full'}
            justifyContent="center"
            alignItems={'center'}
            onPress={handelStopRecord}>
            <Box bg={'#900'} w={'12'} h={'12'} rounded={'full'} />
          </Pressable>
        )}
        <Pressable
          onPress={handelNavigate}
          bg={'#900'}
          w={'12'}
          h={'12'}
          rounded={'full'}
          justifyContent="center"
          alignItems={'center'}>
          <McIcon name="arrow-right" size={30} color={'#fff'} />
        </Pressable>
      </HStack>
    </SafeAreaView>
  );
};

export default TakeVideoScreen;

const styles = StyleSheet.create({
  camera: {
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height * 0.7,
  },
  user: {
    width: 48,
    height: 48,
    borderRadius: 50,
  },
});

// {"duration": 7.6680600000000005, "path": "file:///data/user/0/com.fourward/cache/VisionCamera-20220726_1110346740730373098821731.mp4", "size": 16399.784}
