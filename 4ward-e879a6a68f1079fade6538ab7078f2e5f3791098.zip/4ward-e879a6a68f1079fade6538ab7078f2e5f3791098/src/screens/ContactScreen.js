import { HStack, Text, View, Pressable } from 'native-base';
import React, { useEffect, useState } from 'react';
import { PermissionsAndroid, SafeAreaView, ScrollView, Platform } from 'react-native';
import Contacts from 'react-native-contacts';
import Customloader from '../components/loader';
import { AuthState } from '../context/authState';
import pagestyles from '../styles/contact.style';
import { useInteractionManager } from '../utils/customHooks';
import Loader from './../components/loader/Loader'
import EmergencyContacts from './EmergencyContacts';

import { useNavigation } from '@react-navigation/native';

const ContactScreen = ({ }) => {

  const navigation = useNavigation();

  const { loadScreen } = useInteractionManager();

  // const { contacts, loadContacts } = AuthState();
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(true);
  // const navigation = useNavigation();

  console.log('---contacts---', contacts);

  // PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.READ_CONTACTS)
  //   .then(async () => {
  //     loadContacts();
  //   })
  //   .catch(() => {
  //     alert('Please allow contacts permission');
  //   });

  // useEffect(() => {
  //   Contacts.checkPermission().then(permission => {
  //     // Contacts.PERMISSION_AUTHORIZED || Contacts.PERMISSION_UNDEFINED || Contacts.PERMISSION_DENIED
  //     if (permission === 'undefined') {
  //       Contacts.requestPermission().then(permission => {
  //         // alert('Permission not found');
  //         console.log('contsct permission undefined');
  //       });
  //     }
  //     if (permission === 'authorized') {
  //       //   alert('Permission allowed');
  //       console.log('contsct permission allowed');
  //       loadContacts();
  //     }
  //     if (permission === 'denied') {
  //       alert('Please allow contact permission');
  //     }
  //   });
  // }, []);

  useEffect(() => {
    fetch_contact_info();
  }, []);


  const fetch_contact_info = () => {

    if (Platform.OS === "android") {
      PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.READ_CONTACTS, {
        title: "Contacts",
        message: " This app would like to see your contacts",
      }).then(() => {
        getcontact();
      });
    } else if (Platform.OS === "ios") {
      getcontact();
    }
  }

  const getcontact = (token) => {

    Contacts.getAll().then((contacts) => {
      contacts.sort((a, b) => {
        if (b.displayName > a.displayName) {
          return -1;
        } else {
          return 1;
        }
      });
      setContacts(contacts);
      setLoading(false);
    });
  };



  if (loadScreen) {
    return <Customloader />;
  }

  const emergencyContacts = () => {
    navigation.navigate("EmergencyContacts")
  };

  return (
    <>
      <SafeAreaView style={{ flex: 1, backgroundColor: '#fff' }}>
        <HStack
          style={[pagestyles.headerSec]}
          space="4"
          alignItems={'center'}>
          {/* <Pressable onPress={() => navigation.goBack()}>
                <MCIcon name="keyboard-backspace" size={25} color="#000" />
              </Pressable> */}
          <Text fontWeight={'bold'} fontSize="lg" color={'#000'}>
            My Contacts
          </Text>
          <Pressable style={{
            position: 'absolute',
            top: 10,
            right: 10
          }}
            onPress={emergencyContacts}
          >
            <Text fontWeight={'bold'} fontSize='xs' color={'#000'} style={{
              position: 'absolute', top: 5, right: 0, textDecorationLine: "underline",
              textDecorationStyle: "solid",
              textDecorationColor: "#000"
            }}>
              Emergency contacts
            </Text>
          </Pressable>

          {/* <Image
                source={require('../assets/images/user1.png')}
                style={pagestyles.user}
              /> */}
        </HStack>
        <ScrollView style={pagestyles.scrollView}>
          <View style={pagestyles.container}>

            {contacts &&
              contacts.length > 0 &&
              contacts.map((c, i) => (
                <>
                  {c?.phoneNumbers[0] ? <View
                    key={i}
                    style={[
                      pagestyles.contactList,
                      { justifyContent: 'space-between' },
                    ]}>
                    <View style={pagestyles.leftTxt} flex={3}>
                      <Text style={pagestyles.titleSec}>{Platform.OS === "android" ? c?.displayName : c?.givenName + ' ' + c?.familyName}</Text>
                      <Text style={pagestyles.subList}>
                        {c?.phoneNumbers[0]?.number}
                        {/* {JSON.stringify(c.phoneNumbers)} */}
                      </Text>
                    </View>

                    {/* <View style={pagestyles.btnSec} flex={1}>
                    <TouchableOpacity>
                      <Text style={pagestyles.inviteSec}>INVITE</Text>
                    </TouchableOpacity>
                  </View> */}
                  </View> : null}
                </>
              ))}
          </View>
        </ScrollView>
        {loading ? <Loader></Loader> : null}
      </SafeAreaView>
    </>
  );
};

export default ContactScreen;
