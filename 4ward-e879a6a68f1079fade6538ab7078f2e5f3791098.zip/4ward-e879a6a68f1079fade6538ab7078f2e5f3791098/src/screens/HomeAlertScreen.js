import React, { useState } from 'react';
import {
    View,
    Button,
    Text,
    Image,
    ImageSourcePropType,
    StyleSheet,
    SafeAreaView,
    TouchableOpacity,
    KeyboardAvoidingView,
    TextInput,
    ScrollView,
    ImageBackground,
    Switch
} from "react-native";
// import { createStackNavigator } from '@react-navigation/stack';
// import LinearGradient from 'react-native-linear-gradient';
import styles, { ThemeColors } from '../styles/main.style';
import pagestyles from '../styles/homepage.style';

// const Stack = createStackNavigator();

const HomeAlertScreen = ({ }) => {

    const [isEnabled, setIsEnabled] = useState(false);
    const toggleSwitch = () => setIsEnabled(previousState => !previousState);

    return (
        <>
            <SafeAreaView style={{ flex: 1, backgroundColor: '#000', }}>
                <ScrollView style={pagestyles.scrollView}>
                    <ImageBackground source={require('../assets/images/map2.png')} resizeMode={'cover'}
                        style={pagestyles.mapBg}>
                        <View style={pagestyles.container}>

                            <View style={pagestyles.headerSec}>
                                <Image source={require('../assets/images/user1.png')} style={[pagestyles.user, { position: 'relative', top: 5 }]} />
                                <View style={pagestyles.SearchSec}>
                                    <View style={pagestyles.SectionStyle}>
                                        <View style={{ width: 19, }}>
                                            <Image source={require('../assets/images/search2.png')}
                                                style={pagestyles.ImageStyle} />
                                        </View>
                                        <TextInput
                                            style={{ flex: 1, fontSize: 14, borderRadius: 15 }}
                                            placeholder="Centerville, MD"
                                            underlineColorAndroid="transparent"
                                            placeholderTextColor="#fff"
                                            color="#fff"
                                        // secureTextEntry={true}
                                        />

                                    </View>
                                </View>
                            </View>

                            <View style={pagestyles.locatnWrap}>

                                <Image source={require('../assets/images/path2.png')} style={pagestyles.path2} />

                            </View>
                        </View>

                        <View style={pagestyles.innerContainer}>

                            <View style={pagestyles.btnSec}>
                                <TouchableOpacity style={pagestyles.btn}>
                                    <Image source={require('../assets/images/circl1.png')} style={pagestyles.icn} />
                                    <Text style={pagestyles.btnTxt}>
                                        REPORT LIVE
                                    </Text>
                                </TouchableOpacity>

                                <TouchableOpacity style={pagestyles.btn}>
                                    <Image source={require('../assets/images/camera.png')} style={pagestyles.icn} />
                                    <Text style={pagestyles.btnTxt}>
                                        SNAP SHOT
                                    </Text>
                                </TouchableOpacity>

                                <TouchableOpacity style={pagestyles.btn}>
                                    <Image source={require('../assets/images/plus.png')} style={pagestyles.icn} />
                                    <Text style={pagestyles.btnTxt}>
                                        ICON REPORT
                                    </Text>
                                </TouchableOpacity>

                                <TouchableOpacity style={pagestyles.btn}>
                                    <Image source={require('../assets/images/siren.png')} style={pagestyles.icn} resizeMode={'contain'} />
                                    <Text style={pagestyles.btnTxt}>
                                        SOS
                                    </Text>
                                </TouchableOpacity>
                            </View>

                            <Text style={pagestyles.title}>ALERTS</Text>

                            <View style={pagestyles.ulList}>

                                <View style={pagestyles.liList}>
                                    <View style={pagestyles.forwardSec}>
                                        <Text style={pagestyles.listTitle}>Inclement Weather - Road Closure</Text>
                                        <TouchableOpacity>
                                            <Image source={require('../assets/images/arrow2.png')} style={pagestyles.arw2} resizeMode={'contain'} />
                                        </TouchableOpacity>
                                    </View>
                                    <View style={pagestyles.forwardSec}>
                                        <Text style={pagestyles.subTxt}>123 Seasema street Lane</Text>
                                        <Text style={pagestyles.subTxt}>.2 Kilometers Away</Text>
                                    </View>
                                </View>


                                <View style={pagestyles.liList}>
                                    <View style={pagestyles.forwardSec}>
                                        <Text style={pagestyles.listTitle}>Fatal Stabbing - Uptown Shopping</Text>
                                        <TouchableOpacity>
                                            <Image source={require('../assets/images/arrow2.png')} style={pagestyles.arw2} resizeMode={'contain'} />
                                        </TouchableOpacity>
                                    </View>
                                    <View style={pagestyles.forwardSec}>
                                        <Text style={pagestyles.subTxt}>543 Main Street</Text>
                                        <Text style={pagestyles.subTxt}>2 Kilometers Away</Text>
                                    </View>
                                </View>

                                <View style={pagestyles.liList}>
                                    <View style={pagestyles.forwardSec}>
                                        <Text style={pagestyles.listTitle}>Inclement Weather - Road Closure</Text>
                                        <TouchableOpacity>
                                            <Image source={require('../assets/images/arrow2.png')} style={pagestyles.arw2} resizeMode={'contain'} />
                                        </TouchableOpacity>
                                    </View>
                                    <View style={pagestyles.forwardSec}>
                                        <Text style={pagestyles.subTxt}>123 Seasema street Lane</Text>
                                        <Text style={pagestyles.subTxt}>.2 Kilometers Away</Text>
                                    </View>
                                </View>


                                <View style={pagestyles.liList}>
                                    <View style={pagestyles.forwardSec}>
                                        <Text style={pagestyles.listTitle}>Fatal Stabbing - Uptown Shopping</Text>
                                        <TouchableOpacity>
                                            <Image source={require('../assets/images/arrow2.png')} style={pagestyles.arw2} resizeMode={'contain'} />
                                        </TouchableOpacity>
                                    </View>
                                    <View style={pagestyles.forwardSec}>
                                        <Text style={pagestyles.subTxt}>543 Main Street</Text>
                                        <Text style={pagestyles.subTxt}>2 Kilometers Away</Text>
                                    </View>
                                </View>



                            </View>
                        </View>



                    </ImageBackground>

                </ScrollView>

            </SafeAreaView>

        </>
    );
};



export default HomeAlertScreen;