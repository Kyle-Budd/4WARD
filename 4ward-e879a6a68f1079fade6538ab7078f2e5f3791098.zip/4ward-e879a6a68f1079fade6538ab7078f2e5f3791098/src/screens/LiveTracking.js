import React, { useState, useRef, useEffect } from 'react';
import { View, StyleSheet, Dimensions, Image, TouchableOpacity } from 'react-native';
import MapView, {
    PROVIDER_GOOGLE,
    Marker,
    AnimatedRegion,
} from 'react-native-maps'; // remove PROVIDER_GOOGLE import if not using Google Maps
import MapViewDirections from 'react-native-maps-directions';

const origin = { latitude: 24.2959, longitude: 87.8388 };
const destination = { latitude: 24.1745, longitude: 87.7793 };
// const GOOGLE_MAPS_APIKEY = 'AIzaSyDnkNIvZQTVl1KLTlGcSi1_KG6ne0DNfVw';
import { GOOGLE_MAPS_APIKEY } from '../helper/constants/googleMapKey';
const screen = Dimensions.get('window');
const ASPECT_RATIO = screen.width / screen.height;
const LATITUDE_DELTA = 0.005;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;

import imagePath from '../helper/constants/imagePath';
import {
    locationPermission,
    getCurrentLocation,
} from '../helper/helperFunction/helperFunction';

const styles = StyleSheet.create({
    container: {
        ...StyleSheet.absoluteFillObject,
        height: '100%',
        width: '100%',
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    map: {
        ...StyleSheet.absoluteFillObject,
    },
});

const LiveTracking = (props) => {

    const mapRef = useRef();
    const markerRef = useRef();

    const [state, setState] = useState({
        curLoc: {
            latitude: null,
            longitude: null,
        },
        destinationCords: {},
        isLoading: false,
        coordinate: new AnimatedRegion({
            latitude: null,
            longitude: null,
            latitudeDelta: LATITUDE_DELTA,
            longitudeDelta: LONGITUDE_DELTA,
        }),
        time: 0,
        distance: 0,
        heading: 0,
    });

    const {
        curLoc,
        time,
        distance,
        destinationCords,
        isLoading,
        coordinate,
        heading,
    } = state;
    const updateState = data => setState(state => ({ ...state, ...data }));

    const [modalView, setModalView] = useState(false);
    const [modalMsg, setModalMsg] = useState();
    const [loader, setLoader] = useState(false);

    const [orderDetails, setOrderDetails] = useState();
    const [destinationAddress, setDestinationAddress] = useState({
        latitude: null,
        longitude: null
    });

    useEffect(() => {

        console.log(props?.route?.params?.latitude);

        getLiveLocation();
        const interval = setInterval(() => {
            getLiveLocation();
        }, 6000);
        return () => clearInterval(interval);
    }, []);

    function goback(data) {
        props.navigation.goBack();
    }

    function reloadingMap(data) {
        console.log("reloading map")
    }

    const getLiveLocation = async () => {
        const locPermissionDenied = await locationPermission();
        if (locPermissionDenied) {
            const { latitude, longitude, heading } = await getCurrentLocation();
            console.log('get live location after 4 second', heading);
            console.log('latitude=>', latitude);
            console.log('longitude=>', longitude);
            animate(latitude, longitude);
            updateState({
                heading: heading,
                curLoc: { latitude, longitude },
                coordinate: new AnimatedRegion({
                    latitude: latitude,
                    longitude: longitude,
                    latitudeDelta: LATITUDE_DELTA,
                    longitudeDelta: LONGITUDE_DELTA,
                }),
            });

            // fetchValue();
        }
        // navigation.navigate('chooseLocation', { getCordinates: fetchValue })
    };

    const animate = (latitude, longitude) => {
        const newCoordinate = { latitude, longitude };
        if (Platform.OS == 'android') {
            if (markerRef.current) {
                markerRef.current.animateMarkerToCoordinate(newCoordinate, 7000);
            }
        } else {
            coordinate.timing(newCoordinate).start();
        }
    };

    function modalResponce(data) {
        setModalView(false);
    }

    function getOrigin() {
        return origin;
    }

    return (
        <View style={{ flex: 1 }}>
            {state.curLoc.latitude ? (
                <MapView
                    ref={mapRef}
                    provider={PROVIDER_GOOGLE} // remove if not using Google Maps
                    style={styles.map}
                    region={{
                        latitude: state.curLoc.latitude,
                        longitude: state.curLoc.longitude,
                        // latitude: origin.latitude,
                        // longitude: origin.longitude,
                        latitudeDelta: LATITUDE_DELTA,
                        longitudeDelta: LONGITUDE_DELTA,
                    }}
                >
                    {/* <Marker coordinate={state.curLoc} 
        image={imagePath.icCurLoc}/> */}
                    {state.curLoc.latitude ? (
                        <Marker.Animated ref={markerRef} coordinate={state.curLoc}>
                            <Image
                                source={imagePath.icBike}
                                style={{
                                    width: 40,
                                    height: 40,
                                    transform: [{ rotate: `${heading}deg` }],
                                }}
                                resizeMode="contain"
                            />
                        </Marker.Animated>
                    ) : null}
                    <Marker coordinate={{ latitude: props?.route?.params?.latitude, longitude: props?.route?.params?.longitude }} >
                        <Image
                            source={imagePath.icCurLoc}
                            style={{
                                width: 40,
                                height: 40
                            }}
                            resizeMode="contain"
                        />
                    </Marker>

                    {state.curLoc.latitude ? (
                        <MapViewDirections
                            origin={state.curLoc}
                            // destination={origin}
                            // origin={{latitude:orderDetails.restaurant.latitude,longitude:orderDetails.restaurant.longitude}}
                            destination={{ latitude: props?.route?.params?.latitude, longitude: props?.route?.params?.longitude }}
                            apikey={GOOGLE_MAPS_APIKEY}
                            strokeWidth={5}
                            strokeColor="red"
                            onReady={result => {
                                console.log(`Distance: ${result.distance} km`);
                                console.log(`Duration: ${result.duration} min.`);

                                mapRef.current.fitToCoordinates(result.coordinates, {
                                    edgePadding: {
                                        // right: 30,
                                        // bottom: 300,
                                        // left: 30,
                                        // top: 100,
                                    },
                                });
                            }}
                        />
                    ) : null}
                </MapView>
            ) : null
            }
            <TouchableOpacity style={{ width: 50, height: 50 }}
                activeOpacity={0.8}
                onPress={() => props.navigation.goBack()}
            >
                <Image
                    alt="sos-image"
                    source={require('../assets/img/back_arrow.png')}
                    style={{
                        width: 30,
                        height: 30,
                        flex: 1,
                        resizeMode: 'contain',
                    }}
                />
            </TouchableOpacity>

        </View >
    );
};

export default LiveTracking;
