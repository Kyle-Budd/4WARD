import firestore from '@react-native-firebase/firestore';
import axios from 'axios';
import {
  Input,
  TextArea,
  View,
  Text,
  KeyboardAvoidingView,
  Box,
  HStack,
  Switch,
} from 'native-base';
import React, { useCallback, useState } from 'react';
import {
  Image,
  Keyboard,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import uuid from 'react-native-uuid';
import CustomHeader from '../components/CustomHeader';
import Customloader from '../components/loader';
import { AuthState } from '../context/authState';
import pagestyles from '../styles/iconreport.style';
import { baseUrl } from '../utils/baseUrl';
import { useInteractionManager } from '../utils/customHooks';
// import {PostState} from '../context/postState';
// import storage from '@react-native-firebase/storage';
import * as geofirestore from 'geofirestore';
import { API_KEY } from '../utils/apiKey';
import { useRef } from 'react';
import { useEffect } from 'react';

const firestoreApp = firestore();
const GeoFirestore = geofirestore.initializeApp(firestoreApp);

const IconReportScreen = ({ navigation }) => {
  const { loadScreen } = useInteractionManager();
  const scrollRef = useRef(null);
  const { authUser, myLocation } = AuthState();
  // const {posts, setPosts} = PostState();

  const [iconTypes] = useState([
    { icId: 'AC', name: 'Accident', img: require('../assets/images/ac.png') },
    { icId: 'GS', name: 'Gun Shots', img: require('../assets/images/gs.png') },
    { icId: 'RR', name: 'Robbery', img: require('../assets/images/rr.png') },
    { icId: 'FR', name: 'Fire', img: require('../assets/images/fr.png') },
    { icId: 'BD', name: 'Bad Road', img: require('../assets/images/bd.png') },
    { icId: 'KD', name: 'Kidnap', img: require('../assets/images/kd.png') },
    { icId: 'RB', name: 'Road Block', img: require('../assets/images/rb.png') },
    { icId: 'OT', name: 'Other', img: require('../assets/images/ot.png') },
  ]);

  const [selectedIconType, setselectedIconType] = useState(null);
  const [loading, setloading] = useState(false);
  const [desc, setdesc] = useState('');
  const [identity, setIdentity] = useState(false);

  const handelSelectIcon = useCallback(ic => {
    setselectedIconType(ic);
  }, []);

  const handelUploadPost = useCallback(async () => {
    if (!myLocation) {
      alert('No location found');
      return;
    }

    if (!authUser || !selectedIconType) {
      alert('Please select a icon');
      return;
    }
    //description optional
    // if (!desc) {
    //   alert('Please add content');
    //   return;
    // }
    setloading(true);
    // const reference = storage().ref(selectedIconType.img.split('/')[-1]);
    const id = uuid.v4();
    const postData = {
      id,
      userId: authUser?.uid,
      type: 'icon',
      description: desc,
      iconType: selectedIconType.name,
      icId: selectedIconType.icId,
      address: myLocation?.address,
      identity,
      coordinates: new firestore.GeoPoint(
        myLocation?.location?.latitude,
        myLocation?.location?.longitude,
      ),
      mapImage: `https://maps.googleapis.com/maps/api/staticmap?zoom=15&size=400x400&format=PNG&markers=${myLocation?.location?.latitude},${myLocation?.location?.longitude}&key=${API_KEY}`,
      // location: myLocation,
      date: firestore.FieldValue.serverTimestamp(),
    };
    try {
      await GeoFirestore.collection('posts').doc(id).set(postData);
      // await firestore().collection('posts').doc(id).set(postData);
      // await axios.post(`${baseUrl}/sendNotifications`, {
      //   type: 'icon',
      //   uid: authUser?.uid,
      //   iconType: selectedIconType.name,
      //   location: myLocation,
      // });
      navigation.navigate('MainTab', { screen: 'Story' });
    } catch (error) {
      console.error(error);
      // alert('Something went wrong');
    } finally {
      setloading(false);
      Keyboard.dismiss();
    }
  }, [selectedIconType, myLocation, identity, desc, authUser]);

  if (loadScreen) {
    return <Customloader />;
  }

  return (
    <>
      <KeyboardAvoidingView
        behavior="height"
        style={{ flex: 1, backgroundColor: '#fff' }}>
        <SafeAreaView style={{ flex: 1, backgroundColor: '#fff' }}>
          <CustomHeader title="Icon Report" />
          <ScrollView ref={scrollRef}>
            <View style={pagestyles.container}>
              <View>
                <HStack space={'2'}>
                  <Text style={pagestyles.comnTitle}>LOCATION</Text>
                  <Image
                    source={require('../assets/images/location.png')}
                    style={pagestyles.ImageStyle}
                  />
                </HStack>
                <View style={pagestyles.SearchSec}>
                  <Text style={pagestyles.comnTitle} mb={'4'} numberOfLines={4}>
                    {myLocation?.address}
                  </Text>
                  {/* <View style={pagestyles.SectionStyle}>
                 

                  <Input
                    flex={1}
                    placeholder={myLocation?.address}
                    placeholderTextColor={'#fff'}
                    color={'#999'}
                    borderColor={'#7D797A'}
                    value={myLocation?.address}
                    fontSize={'lg'}
                  />

                  <View style={{width: 19}}>
                    <Image
                      source={require('../assets/images/location.png')}
                      style={pagestyles.ImageStyle}
                    />
                  </View>
                </View> */}
                </View>
              </View>
              <HStack mr="1/2" space={'2'} my="4">
                <Text fontSize={'xl'} color={'#000'}>
                  Identity
                </Text>
                <Switch
                  colorScheme={'error'}
                  size="sm"
                  value={identity}
                  onValueChange={setIdentity}
                />
                {identity ? (
                  <Text fontWeight={'bold'} fontSize={'xl'} color={'green.500'}>
                    ON
                  </Text>
                ) : (
                  <Text fontWeight={'bold'} fontSize={'xl'} color={'error.500'}>
                    OFF
                  </Text>
                )}
              </HStack>
              <View style={pagestyles.quickPostSec}>
                <Text style={pagestyles.comnTitle}>QUICK POST FROM BELOW</Text>

                <View style={pagestyles.icnList}>
                  {iconTypes &&
                    iconTypes.map((ic, idx) => (
                      <View
                        style={[
                          pagestyles.listBx,
                          ic.name === selectedIconType?.name &&
                          pagestyles.active,
                        ]}
                        key={idx}>
                        <TouchableOpacity onPress={() => handelSelectIcon(ic)}>
                          <Image
                            source={ic.img}
                            style={pagestyles.icn}
                            resizeMode={'contain'}
                          />
                        </TouchableOpacity>
                        <Text style={pagestyles.icnTxt}>{ic.name}</Text>
                      </View>
                    ))}
                </View>
              </View>

              <View mt={'5'}>
                <Text style={pagestyles.comnTitle}> WRITE DESCRIPTION </Text>
                <View my={'5'}>
                  <TextArea
                    h={200}
                    fontSize={'md'}
                    placeholder="Description"
                    w="full"
                    color={'#000'}
                    value={desc}
                    onChangeText={setdesc}
                    onFocus={() => scrollRef.current.scrollToEnd()}
                  />
                </View>
              </View>
            </View>
          </ScrollView>
          <TouchableOpacity onPress={handelUploadPost} disabled={loading}>
            <View style={pagestyles.btn1}>
              {loading ? (
                <Customloader />
              ) : (
                <Text style={pagestyles.signText}> POST </Text>
              )}
            </View>
          </TouchableOpacity>
        </SafeAreaView>
      </KeyboardAvoidingView>
    </>
  );
};

export default IconReportScreen;

{
  /* {selectedIconType && <Text style={pagestyles.icnTxt}>{selectedIconType.name}</Text>} */
}

{
  /* <View style={pagestyles.headerSec}>
              <Image
                source={require('../assets/images/user1.png')}
                style={pagestyles.user}
              />
              <Text style={pagestyles.midleTitle}>Icon Report</Text>
            </View> */
}

{
  /* <View style={pagestyles.switch}>
              <Text style={pagestyles.comnTitle}>IDENTITY</Text>
              <Switch
                trackColor={{false: '#2A2727', true: '#fff'}}
                thumbColor={isEnabled ? '#F60404' : '#F60404'}
                ios_backgroundColor="#2A2727"
                onValueChange={toggleSwitch}
                value={isEnabled}
              />
            </View> */
}
