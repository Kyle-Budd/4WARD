import { HStack, Text, View, Pressable } from 'native-base';
import React, { useEffect, useState } from 'react';
import { PermissionsAndroid, SafeAreaView, ScrollView, Platform } from 'react-native';
import Contacts from 'react-native-contacts';
import Customloader from '../components/loader';
import { AuthState } from '../context/authState';
import pagestyles from '../styles/contact.style';
import { useInteractionManager } from '../utils/customHooks';
import Loader from './../components/loader/Loader'

import MaterialIcons from 'react-native-vector-icons/MaterialIcons';

import { useNavigation } from '@react-navigation/native';
import firestore from '@react-native-firebase/firestore';

let list = [];

const EmergencyContacts = (props) => {

  const navigation = useNavigation();

  const { loadScreen } = useInteractionManager();

  const { authUser, myLocation, user, setAuthUser } = AuthState();
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(false);
  // const navigation = useNavigation();


  // useEffect(() => {
  //   getcontact();
  // }, [user]);

  useEffect(() => {
    const focusListener = props.navigation.addListener('focus', () => {
      getcontact();
    });

    return focusListener;
  }, [props.navigation]);



  const getcontact = async () => {
    setContacts([]);
    list = [];
    firestore()
      .collection('emergencyContacts')
      // Filter results
      .where('id', '==', user?.id)
      .get()
      .then(querySnapshot => {
        querySnapshot.forEach((user) => {
          console.log(user.data());
          list.push(user.data());
        });
        setContacts(list);
      });
  };

  if (loadScreen) {
    return <Customloader />;
  }

  const selectEmergencyContacts = () => {
    navigation.navigate("SelectEmergencyContacts", { list: contacts })
  };

  return (
    <>
      <SafeAreaView style={{ flex: 1, backgroundColor: '#fff' }}>
        <HStack
          style={pagestyles.headerSec}
          space="4"
          alignItems={'center'}>
          {/* <Pressable onPress={() => navigation.goBack()}>
                <MCIcon name="keyboard-backspace" size={25} color="#000" />
              </Pressable> */}
          <Pressable style={{
          }}
            onPress={() => navigation.goBack()}
          >
            <MaterialIcons name="arrow-back" size={30} />
          </Pressable>
          <Text fontWeight={'bold'} fontSize="lg" color={'#000'}>
            Emergency contacts
          </Text>
          <Pressable style={{
            position: 'absolute',
            top: 10,
            right: 10
          }}
            onPress={selectEmergencyContacts}
          >
            <MaterialIcons name="add" size={30} />
          </Pressable>
        </HStack>
        <ScrollView style={pagestyles.scrollView}>
          <View style={pagestyles.container}>
            {contacts &&
              contacts.length > 0 &&
              contacts.map((c, i) => (
                <>
                  <View
                    key={i}
                    style={[
                      pagestyles.contactList,
                      { justifyContent: 'space-between' },
                    ]}>
                    <View style={pagestyles.leftTxt} flex={3}>
                      <Text style={pagestyles.titleSec}>{c?.name}</Text>
                      <Text style={pagestyles.subList}>
                        {'+' + c?.code + ' ' + c?.mobile}
                        {/* {JSON.stringify(c.phoneNumbers)} */}
                      </Text>
                    </View>

                    {/* <View style={pagestyles.btnSec} flex={1}>
                    <TouchableOpacity>
                      <Text style={pagestyles.inviteSec}>INVITE</Text>
                    </TouchableOpacity>
                  </View> */}
                  </View>
                </>
              ))}
          </View>
        </ScrollView>
        {loading ? <Loader></Loader> : null}
      </SafeAreaView>
    </>
  );
};

export default EmergencyContacts;