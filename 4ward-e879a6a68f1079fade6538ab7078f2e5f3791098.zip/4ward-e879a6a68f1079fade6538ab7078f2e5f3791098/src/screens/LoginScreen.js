/* eslint-disable react/no-children-prop */
import auth from '@react-native-firebase/auth';
import { Input, InputGroup, InputLeftAddon, Stack, Text, Spinner } from 'native-base';
import React, { useCallback, useState, useEffect } from 'react';
import {
  ImageBackground,
  KeyboardAvoidingView,
  TouchableOpacity,
  View,
} from 'react-native';
import CountryPicker from 'react-native-country-picker-modal';
import Customloader from '../components/loader';
import { AuthState } from '../context/authState';
import pagestyles from '../styles/login.style';
import { useInteractionManager } from '../utils/customHooks';

import NetInfo from "@react-native-community/netinfo";
import firestore from '@react-native-firebase/firestore';
let userInfo;

const LoginScreen = ({ navigation }) => {
  const { loadScreen } = useInteractionManager();

  const {
    setConfirm,
    phoneNumber,
    setphoneNumber,
    countryCode,
    setCountryCode,
    myLocation,
  } = AuthState();
  const [show, setShow] = useState(false);

  const [withCallingCode] = useState(true);

  const [numberObj, setNumberObj] = useState();
  const [email, setEmail] = useState("");
  const [loader, setLoader] = useState(false);

  // useEffect(() => {
  //   (async () => {
  //     const users = await firestore().collection('Users').get();
  //     console.log(users);
  //   })();
  // }, []);

  useEffect(() => {
    setCountryCode(234);
    setNumberObj({ "callingCode": ["234"], "cca2": "NG", "currency": ["NGN"], "flag": "flag-ng", "name": "Nigeria", "region": "Africa", "subregion": "Western Africa" });

  }, []);

  const handelSendCode = useCallback(async () => {
    NetInfo.fetch().then(state => {
      if (state.isConnected) {
        // sendCode();
        checkExistingInfo();
      }
      else {
        alert('Please check your internet connection.');
        return;
      }
    });
  }, [phoneNumber, countryCode, email]);

  const checkExistingInfo = useCallback(async () => {
    let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w\w+)+$/;
    if (!phoneNumber) {
      alert('Please enter your phone no.');
      return;
    }
    else if (!email) {
      alert('Enter email address');
      return;
    }
    else if (reg.test(email) === false) {
      alert('Invalid email address');
      return;
    }
    else {
      userInfo = '';

      const confirmation = await firestore()
        .collection("users")
        .where('phone', '==', `${countryCode}${phoneNumber}`)
        // .where('email', '==',  'test@updated.com')
        .get()
        .then((querySnapshot) =>
          querySnapshot.forEach((doc) =>
            userInfo = doc.data()
          )
        );
      console.log(userInfo)
      if (userInfo) {
        if (userInfo.email == email) {
          setLoader(true);
          sendCode();
        }
        else {
          alert('Your email address do not match.');
        }
      }
      else {
        setLoader(true);
        sendCode();
      }
    }

  });

  const sendCode = useCallback(async () => {
    try {
      let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w\w+)+$/;

      if (!phoneNumber) {
        alert('Please enter your phone no.');
        return;
      }
      else if (!email) {
        alert('Enter email address');
        return;
      }
      else if (reg.test(email) === false) {
        alert('Invalid email address');
        return;
      }
      else {
        const confirmation = await auth().signInWithPhoneNumber(
          `+${countryCode}${phoneNumber}`,true
        );
        // .then(res => console.log(res)).catch(err => console.log(err));
        setConfirm(confirmation);
        setphoneNumber('');
        setCountryCode('');
        setLoader(false);
        navigation.navigate('EnterOtp', { phone: `+${countryCode}${phoneNumber}`, cca2: numberObj.cca2, callingCode: numberObj.callingCode[0], email: email });
      }
    } catch (error) {
      console.log('Err ======> ' + JSON.stringify(error));
      alert('Phone validation failed, select valid phone number'+ JSON.stringify(error));

    }
  });

  const onSelect = useCallback(country => {
    const code = country?.callingCode[0];
    if (code) {
      console.log(country);
      setCountryCode(code);
      setNumberObj(country);
    }
  }, []);

  if (loadScreen) {
    return <Customloader />;
  }

  return (
    <>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{
          flex: 1,
          backgroundColor: '#000',
        }}>
        {/* <ScrollView style={pagestyles.scrollView}> */}

        <ImageBackground
          source={require('../assets/images/loginbg.jpg')}
          resizeMode={'cover'}
          style={pagestyles.loginBg}>

          {myLocation && (
            <View style={pagestyles.mb3}>
              <Text style={pagestyles.mapTitle1}>{myLocation?.address}</Text>
              <Text style={pagestyles.mapsubtxt1}>
                {' '}
                Enter your phone number.
              </Text>
              <Text style={pagestyles.mapsubtxt1}>sign up or login.</Text>
            </View>
          )}

          <CountryPicker
            withFilter
            {...{
              withCallingCode,
              onSelect,
            }}
            visible={show}
          />
          <View>
            <Text style={pagestyles.cmnTitle}>*PHONE NUMBER</Text>
            <Stack alignItems="center">
              <InputGroup w={'100%'}>
                <InputLeftAddon
                  children={
                    <TouchableOpacity onPress={() => setShow(p => !p)}>
                      {countryCode?.length > 0 ? (
                        <Text>+{countryCode}</Text>
                      ) : (
                        <Text color={'#000'}>+234</Text>
                      )}
                    </TouchableOpacity>
                  }
                />
                <Input
                  flex={1}
                  placeholder=""
                  color={'#fff'}
                  value={phoneNumber}
                  fontSize={'lg'}
                  onChangeText={setphoneNumber}
                  secureTextEntry={false}
                  keyboardType={'phone-pad'}
                />
              </InputGroup>
            </Stack>

            <Text style={[pagestyles.cmnTitle, { marginTop: 10 }]}>*EMAIL</Text>
            <Stack alignItems="center">
              <InputGroup w={'100%'}>
                <Input
                  flex={1}
                  placeholder=""
                  color={'#fff'}
                  value={email}
                  fontSize={'lg'}
                  // onChangeText={setEmail}
                  onChangeText={text => setEmail(text)}
                  secureTextEntry={false}
                  keyboardType={'default'}
                />
              </InputGroup>
            </Stack>

            <TouchableOpacity onPress={handelSendCode}>
              <View
                style={{
                  backgroundColor: '#F60404',
                  height: 48,
                  borderRadius: 10,
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginTop: 15,
                }}>
                <Text style={pagestyles.signText}> SEND CODE </Text>
              </View>
            </TouchableOpacity>
            {/* <TouchableOpacity >
              <View style={{ backgroundColor: '#F60404', height: 48, borderRadius: 10, justifyContent: 'center', alignItems: 'center', marginTop: 15, }}>
                <Text style={pagestyles.signText}> SIGN IN  </Text>
              </View>
            </TouchableOpacity> */}

            <Text style={pagestyles.mapsubtxt2}>
              By continuing, you agree to our{' '}
            </Text>

            <View style={pagestyles.terms}>
              <TouchableOpacity>
                <Text style={pagestyles.redColor}>Terms of Use</Text>
              </TouchableOpacity>
              <Text style={pagestyles.whitClr}> and </Text>
              <TouchableOpacity>
                <Text style={pagestyles.redColor}>Privacy Policy</Text>
              </TouchableOpacity>
            </View>
          </View>
        </ImageBackground>

        {/* </ScrollView> */}
      </KeyboardAvoidingView>

      {loader ? <View style={{ position: 'absolute', width: '100%', height: '100%', backgroundColor: '#00000090', justifyContent: 'center' }}>
        <Spinner color={'#900'} size={'lg'} />
      </View> : null}
    </>
  );
};

export default LoginScreen;

{
  /* <TextInput
              style={{
                // flex: 1,
                fontSize: 18,
                backgroundColor: '#7D797A',
                borderRadius: 10,
                padding: 13,
                textAlign: 'left',
                // paddingHorizontal: 10,
                // height: 20,
              }}
              placeholder=""
              // underlineColorAndroid="transparent"
              placeholderTextColor="#fff"
              color="#fff"
              value={phoneNumber}
              onChangeText={setphoneNumber}
              secureTextEntry={false}
              keyboardType={'default'}
            /> */
}
