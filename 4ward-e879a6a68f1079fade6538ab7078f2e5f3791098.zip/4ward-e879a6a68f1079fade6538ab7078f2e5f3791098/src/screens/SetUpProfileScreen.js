import React, { useState } from 'react';
import {
    View,
    Button,
    Text,
    Image,
    ImageSourcePropType,
    StyleSheet,
    SafeAreaView,
    TouchableOpacity,
    KeyboardAvoidingView,
    TextInput,
    ScrollView,
    ImageBackground
} from "react-native";

// import { createStackNavigator } from '@react-navigation/stack';
// import LinearGradient from 'react-native-linear-gradient';
import styles, { ThemeColors } from '../styles/main.style';
import pagestyles from '../styles/setupprofile.style';

// const Stack = createStackNavigator();

const SetUpProfileScreen = ({ }) => {
    return (
        <>
            <SafeAreaView style={{ flex: 1, backgroundColor: '#000', }}>
                <ScrollView style={pagestyles.scrollView}>

                    <View style={pagestyles.contentContainer}>
                        <View>
                            <Text style={pagestyles.title1}>Set up your profile</Text>
                            <Text style={pagestyles.subTxt}>Create your 4ward Login</Text>
                        </View>

                        <View style={pagestyles.formsetup}>
                            <View style={{paddingBottom:20}}>
                                <Text style={pagestyles.lableTitle}>*USERNAME</Text>
                                <TextInput
                                    style={{ fontSize: 18, textAlign: 'left', backgroundColor: '#7D797A', borderRadius: 10 }}
                                    placeholder=""
                                    // underlineColorAndroid="transparent"
                                    placeholderTextColor="#fff"
                                    color="#fff"
                                    // value={text}
                                    secureTextEntry={false}
                                />
                            </View>
                            <View style={{paddingBottom:20}}>
                                <Text style={pagestyles.lableTitle}>*EMAIL</Text>
                                <TextInput
                                    style={{ fontSize: 18, textAlign: 'left', backgroundColor: '#7D797A', borderRadius: 10 }}
                                    placeholder=""
                                    // underlineColorAndroid="transparent"
                                    placeholderTextColor="#fff"
                                    color="#fff"
                                    // value={text}
                                    secureTextEntry={false}
                                />
                            </View>
                            <TouchableOpacity >
                                <View style={{ backgroundColor: '#F60404', height: 48, borderRadius: 10, justifyContent: 'center', alignItems: 'center', marginTop: 15, }}>
                                    <Text style={pagestyles.signText}> Next  </Text>
                                </View>
                            </TouchableOpacity>


                        </View>
                    </View>


                </ScrollView>
            </SafeAreaView>

        </>
    );
};



export default SetUpProfileScreen;