import { HStack, Text, View, Pressable } from 'native-base';
import React, { useEffect, useState } from 'react';
import { PermissionsAndroid, SafeAreaView, ScrollView, Platform, TouchableOpacity } from 'react-native';
import Contacts from 'react-native-contacts';
import Customloader from '../components/loader';
import { AuthState } from '../context/authState';
import pagestyles from '../styles/contact.style';
import { useInteractionManager } from '../utils/customHooks';
import Loader from './../components/loader/Loader'

import MaterialIcons from 'react-native-vector-icons/MaterialIcons';

import { useNavigation } from '@react-navigation/native';

import AsyncStorage from '@react-native-async-storage/async-storage';
import auth from '@react-native-firebase/auth';
import { AsYouType } from 'libphonenumber-js';
import { setEnabled } from 'react-native/Libraries/Performance/Systrace';

import firestore from '@react-native-firebase/firestore';

let selectedList = [];

const SelectEmergencyContacts = (props) => {

    const navigation = useNavigation();

    const { loadScreen } = useInteractionManager();

    const { authUser, myLocation, user, setAuthUser } = AuthState();
    const [contacts, setContacts] = useState([]);
    const [loading, setLoading] = useState(true);

    const [userInfo, setUserInfo] = useState();

    useEffect(() => {
        fetch_contact_info();
    }, []);


    const fetch_contact_info = async () => {

        try {
            const value = await AsyncStorage.getItem('numberObj')
            if (value !== null) {
                // value previously stored
                setUserInfo(JSON.parse(value));
                let data = JSON.parse(value)
                console.log('Json : '+data.cca2);
                console.log('Json2 : '+data.callingCode);
            }
        } catch (e) {
            // error reading value
        }

        if (Platform.OS === "android") {
            PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.READ_CONTACTS, {
                title: "Contacts",
                message: " This app would like to see your contacts",
            }).then(() => {
                getcontact();
            });
        } else if (Platform.OS === "ios") {
            getcontact();
        }
    }

    const getcontact = async (token) => {

        Contacts.getAll().then((contacts) => {
            contacts.sort((a, b) => {
                if (b.displayName > a.displayName) {
                    return -1;
                } else {
                    return 1;
                }
            });

            for (let i = 0; i < contacts.length; i++) {
                console.log(contacts[i]?.phoneNumbers[0]?.number)
                if (contacts[i]?.phoneNumbers[0]?.number) {
                    let status = chk_selectable(contacts[i]?.phoneNumbers[0]?.number);
                    contacts[i].clickable = status;
                }
            }


            setContacts(contacts);
            setLoading(false);
        });
    };

    if (loadScreen) {
        return <Customloader />;
    }

    const clickableContact = (c, index) => {
        setLoading(true);

        let array = [];
        for (let i = 0; i < contacts.length; i++) {
            if (i == index) {
                contacts[i].clickable = !contacts[i].clickable;
                array.push(contacts[i]);
                if (contacts[i].clickable) {
                    saveEmergrncyContact(c)
                }
                else {
                    deleteEmergrncyContact(c);
                }
            }
            else {
                array.push(contacts[i])
            }
        }

        setContacts([]);
        setContacts(array);

        selectedList = [];

        for (let i = 0; i < array.length; i++) {
            if (array[i].clickable) {
                let obj =
                {
                    name: Platform.OS === "android" ? c?.displayName : c?.givenName + ' ' + c?.familyName,
                    phone: array[i].phoneNumbers[0]?.number
                }
                selectedList.push(obj);
            }
        }
    };

    const saveEmergrncyContact = async (obj) => {

        // for (let i = 0; i < selectedList.length; i++) {
        //     console.log(selectedList[i]);
        let res = getCountryCode(obj?.phoneNumbers[0]?.number);

        let countryCode = res.countryCode;

        let withoutCountryCode = res.withoutCountryCode;
        let contact_no = withoutCountryCode.replace(/^\+[0-9]{1,3}(\s|\-)/, "");
        let formatted_contact_no = contact_no.replace(/ /g, '');
        let formatted_country_code = countryCode.replace('+', '');

        let _contact_no_ = formatted_contact_no.replace(/[^a-zA-Z0-9]/g, '');

        try {
            firestore()
                .collection('emergencyContacts')
                .add({
                    id: user?.id,
                    name: Platform.OS === "android" ? obj?.displayName : obj?.givenName + ' ' + obj?.familyName,
                    mobile: _contact_no_,
                    code: formatted_country_code,
                })
                .then(() => {
                    console.log('User added!');
                    setLoading(false);
                });

        } catch (error) {
            console.error(error);
            console.log('Failed');
        }
        // if (i == selectedList.length - 1) {
        //     navigation.goBack();
        // }
        // }
    };

    const deleteEmergrncyContact = async (obj) => {

        let res = getCountryCode(obj?.phoneNumbers[0]?.number);

        let countryCode = res.countryCode;

        let withoutCountryCode = res.withoutCountryCode;
        let contact_no = withoutCountryCode.replace(/^\+[0-9]{1,3}(\s|\-)/, "");
        let formatted_contact_no = contact_no.replace(/ /g, '');
        let formatted_country_code = countryCode.replace('+', '');

        let _contact_no_ = formatted_contact_no.replace(/[^a-zA-Z0-9]/g, '');

        firestore()
            .collection('emergencyContacts')
            .where('id', '==', user?.id)
            .where('code', '==', formatted_country_code)
            .where('mobile', '==', _contact_no_)
            .get()
            .then(querySnapshot => {
                querySnapshot.forEach((user) => {
                    delete_doc(user.id)
                });
            });
    };

    const delete_doc = async (id) => {
        firestore()
            .collection('emergencyContacts')
            .doc(id)
            .delete()
            .then(() => {
                console.log('User deleted!');
                setLoading(false);
            });

    };

    const getCountryCode = (input) => {
        // Set default country code to US if no real country code is specified

        const defaultCountryCode = input.substr(0, 1) !== '+' ? userInfo?.cca2 : null;
        // let formatted = new libphonenumber.asYouType( defaultCountryCode ).input( input );
        let formatted = new AsYouType(defaultCountryCode).input(input);
        let countryCode = '';
        let withoutCountryCode = formatted;

        if (defaultCountryCode === userInfo?.cca2) {
            countryCode = '+' + userInfo?.callingCode;
            formatted = '+ ' + userInfo?.callingCode + formatted;
        }
        else {
            const parts = formatted.split(' ');
            countryCode = parts.length > 1 ? parts.shift() : '';
            withoutCountryCode = parts.join(' ');
        }

        return {
            formatted,
            withoutCountryCode,
            countryCode,
        }
    }

    get_number = (no) => {
        let res = getCountryCode(no);

        let countryCode = res.countryCode;

        let withoutCountryCode = res.withoutCountryCode;
        let contact_no = withoutCountryCode.replace(/^\+[0-9]{1,3}(\s|\-)/, "");
        let formatted_contact_no = contact_no.replace(/ /g, '');
        let formatted_country_code = countryCode.replace('+', '');

        let _contact_no_ = formatted_contact_no.replace(/[^a-zA-Z0-9]/g, '');

        return '+' + formatted_country_code + ' ' + _contact_no_;
    };

    chk_selectable = (no) => {
        let res = getCountryCode(no);

        let countryCode = res.countryCode;

        let withoutCountryCode = res.withoutCountryCode;
        let contact_no = withoutCountryCode.replace(/^\+[0-9]{1,3}(\s|\-)/, "");
        let formatted_contact_no = contact_no.replace(/ /g, '');
        let formatted_country_code = countryCode.replace('+', '');

        let _contact_no_ = formatted_contact_no.replace(/[^a-zA-Z0-9]/g, '');

        let list = props?.route?.params?.list;

        for (let j = 0; j < list.length; j++) {
            if (formatted_country_code + _contact_no_ == list[j].code + list[j].mobile) {
                return true;
            }
        }
        return false;
    };

    return (
        <>
            <SafeAreaView style={{ flex: 1, backgroundColor: '#fff' }}>
                <HStack
                    style={pagestyles.headerSec}
                    space="4"
                    alignItems={'center'}>
                    {/* <Pressable onPress={() => navigation.goBack()}>
                <MCIcon name="keyboard-backspace" size={25} color="#000" />
              </Pressable> */}
                    <Pressable style={{
                    }}
                        onPress={() => navigation.goBack()}
                    >
                        <MaterialIcons name="arrow-back" size={30} />
                    </Pressable>
                    <Text fontWeight={'bold'} fontSize="lg" color={'#000'}>
                        Contacts
                    </Text>
                    {/* <TouchableOpacity
                        activeOpacity={0.8}
                        style={{
                            position: 'absolute',
                            top: 16,
                            right: 10
                        }}
                        // onPress={saveEmergrncyContact}
                        onPress={() => saveEmergrncyContact()}
                    >
                        <Text fontWeight='medium' fontSize='xs' color={'#000'}>
                            Save
                        </Text>
                    </TouchableOpacity> */}
                </HStack>
                <ScrollView style={pagestyles.scrollView}>
                    <View style={pagestyles.container}>
                        {contacts &&
                            contacts.length > 0 &&
                            contacts.map((c, i) => (
                                <View
                                    key={i}
                                >
                                    {c?.phoneNumbers[0] ? <TouchableOpacity
                                        activeOpacity={0.8}
                                        onPress={() => clickableContact(c, i)}
                                        style={[
                                            pagestyles.contactList,
                                            { justifyContent: 'space-between' },
                                        ]}>
                                        <TouchableOpacity
                                            activeOpacity={0.8}
                                            onPress={() => clickableContact(c, i)}
                                            style={pagestyles.leftTxt} flex={3}>
                                            <Text style={pagestyles.titleSec}>{Platform.OS === "android" ? c?.displayName : c?.givenName + ' ' + c?.familyName}</Text>
                                            <Text style={pagestyles.subList}>
                                                {get_number(c?.phoneNumbers[0]?.number)}
                                                {/* {JSON.stringify(c.phoneNumbers)} */}
                                            </Text>
                                        </TouchableOpacity>

                                        <MaterialIcons name={c?.clickable ? 'check' : ''} size={30} style={{
                                            position: 'absolute',
                                            top: 10,
                                            right: 0
                                        }} />
                                    </TouchableOpacity> : null}
                                </View>
                            ))}
                    </View>
                </ScrollView>
                {loading ? <Loader></Loader> : null}
            </SafeAreaView>
        </>
    );
};

export default SelectEmergencyContacts;