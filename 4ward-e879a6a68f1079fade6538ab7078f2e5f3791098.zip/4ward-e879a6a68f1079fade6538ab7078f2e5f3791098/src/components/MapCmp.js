import { Box, Image, Modal, Pressable, Spinner, Text, View } from 'native-base';
import React, { useCallback, useMemo, useState } from 'react';
import { Dimensions, StyleSheet } from 'react-native';
import MapView, { Circle, Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import MapViewDirections from 'react-native-maps-directions';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import { AuthState } from '../context/authState';
import { PostState } from '../context/postState';
import { API_KEY } from '../utils/apiKey';
import MapMarker from './MapMarker';
// import Geolocation from 'react-native-geolocation-service';

import { useNavigation } from '@react-navigation/native';

const MapCmp = ({
  center,
  searchLocation,
  mapViewRef,
  handelAnimate,
  setSearchLocation
}) => {

  const navigation = useNavigation();

  const { myLocation, user } = AuthState();
  const { posts, filterPosts, isFilter } = PostState();
  const [isLoading, setisLoading] = useState(false);
  const filteredPosts = useMemo(
    () =>
      isFilter
        ? filterPosts && filterPosts?.length > 0 && filterPosts
        : posts &&
        posts?.length > 0 &&
        posts
          ?.filter(item => !item?.addMob)
          ?.filter(po => po?.location !== null),
    [posts, isFilter, filterPosts],
  );

  const handelClearLocation = useCallback(() => {
    setSearchLocation(null);
  }, []);

  const handelLiveTracking = useCallback(() => {
    navigation.navigate("LiveTracking", { latitude: searchLocation?.location?.lat, longitude: searchLocation?.location?.lng })
  }, [searchLocation]);

  // console.log('------------', filteredPosts);

  return (
    <View position={'relative'} style={styles.map}>
      <MapView
        ref={mapViewRef}
        provider={PROVIDER_GOOGLE}
        style={styles.map}
        // userInterfaceStyle="dark"
        // customMapStyle={mapStyle}
        followsUserLocation
        // showsMyLocationButton={true}
        showsUserLocation={true}
        // zoomControlEnabled={true}

        mapPadding={{
          top: 0,
          right: 0,
          bottom: 0,
          left: 0
        }}

        camera={{
          pitch: 1,
          heading: 1,
          altitude: 10,
          zoom: 15,
          center,
        }}>
        {myLocation && (
          <Marker
            coordinate={{
              latitude: myLocation?.location?.latitude,
              longitude: myLocation?.location?.longitude,
            }}>
            <MaterialCommunityIcons
              name="map-marker-account"
              size={45}
              color={'#f66'}
            />
          </Marker>
        )}
        {filteredPosts &&
          filteredPosts.map((p, i) => <MapMarker key={i} post={p} />)}
        {filteredPosts &&
          filteredPosts.map((p, i) => (
            <Circle
              key={i}
              center={{
                latitude: p?.coordinates
                  ? parseFloat(p?.coordinates?._latitude)
                  : p?.center
                    ? parseFloat(p?.center?._latitude)
                    : p?.location?.location?.latitude,
                longitude: p?.coordinates
                  ? parseFloat(p?.coordinates?._longitude)
                  : p?.center
                    ? parseFloat(p?.center?._longitude)
                    : p?.location?.location?.longitude,
              }}
              radius={300}
              zIndex={0}
              fillColor={'rgba(245, 40, 145, 0.1)'}
              strokeColor={'rgba(245, 40, 145, 0.1)'}
            />
          ))}
        {searchLocation && (
          <Marker
            // draggable
            coordinate={{
              latitude: searchLocation?.location?.lat,
              longitude: searchLocation?.location?.lng,
            }}>
            <MaterialCommunityIcons
              name="google-maps"
              size={45}
              color={'#900'}
            />
          </Marker>
        )}
        {searchLocation && (
          <MapViewDirections
            apikey={API_KEY}
            mode="DRIVING"
            precision={'high'}
            timePrecision={'now'}
            optimizeWaypoints={true}
            strokeWidth={5}
            strokeColor={'#900'}
            onStart={() => setisLoading(true)}
            onReady={results => {
              // console.log('resultssss', results);
              setisLoading(false);
            }}
            onError={() => setisLoading(false)}
            origin={{
              latitude: myLocation?.location?.latitude,
              longitude: myLocation?.location?.longitude,
            }}
            destination={{
              latitude: searchLocation?.location?.lat,
              longitude: searchLocation?.location?.lng,
            }}
          />
        )}
      </MapView>
      <Box
        position={'absolute'}
        bottom="0"
        left={'0'}
        w="20"
        h={'10'}
        bg="#00000000"
        justifyContent="center"
        alignItems={'center'}
      // borderRadius="lg"
      >
        <Image
          alt="sos-image"
          source={require(`../assets/images/4waed_logo.png`)}
          style={{
            // width: 50,
            height: 30,
            flex: 1,
            resizeMode: 'contain',
          }}
        />
      </Box>
      <Pressable
        onPress={handelAnimate}
        position={'absolute'}
        bottom="1"
        right={'1'}
        w="10"
        h={'10'}
        justifyContent="center"
        alignItems={'center'}
        borderRadius="full"
        borderColor={'error.100'}
        borderWidth={2}
        bg="#fff">
        <MaterialIcons name="my-location" color={'#900'} size={30} />
      </Pressable>
      {searchLocation && (
        <Pressable
          onPress={handelClearLocation}
          position={'absolute'}
          bottom="12"
          right={'1'}
          w="10"
          h={'10'}
          justifyContent="center"
          alignItems={'center'}
          borderRadius="full"
          borderColor={'error.100'}
          borderWidth={2}
          bg="#fff">
          <MaterialIcons name="close" color={'#900'} size={30} />
        </Pressable>
      )}

      {searchLocation && (
        <Pressable
          onPress={handelLiveTracking}
          position={'absolute'}
          bottom={24}
          right={'1'}
          w="10"
          h={'10'}
          justifyContent="center"
          alignItems={'center'}
          borderRadius="full"
          borderColor={'error.100'}
          borderWidth={2}
          bg="#fff">
          <MaterialIcons name="directions" color={'#900'} size={30} />
        </Pressable>
      )}

      <Modal
        isOpen={isLoading}
        onClose={() => {
          setisLoading(false);
        }}
        size={'xs'}>
        <Modal.Content maxH="212">
          <Modal.Header backgroundColor={'#fff'}>
            <Text
              style={{
                fontSize: 18,
                color: '#000',
                fontWeight: '700',
                textAlign: 'center',
              }}>
              Fetching routes...
            </Text>
            <Spinner size={'lg'} color={'#900'} mt={'4'} />
          </Modal.Header>
        </Modal.Content>
      </Modal>
    </View>
  );
};

export default MapCmp;

const styles = StyleSheet.create({
  map: {
    // width: Dimensions.get('window').width,
    // height: Dimensions.get('window').height * 5,
    flex: 1,
  },
  locatnCircl: {
    width: 139,
    height: 139,
    backgroundColor: 'rgba(246, 4, 4, 0.3)',
    borderRadius: 100,
    justifyContent: 'center',
    alignItems: 'center',
  },
  locatnWrap: {
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 60,
    marginBottom: 50,
  },
  user: {
    width: 48,
    height: 48,
    marginRight: 10,
    position: 'relative',
  },
});

// Geolocation.watchPosition(
//   async position => {
//     if (position) {
//       const {data} = await axios.get(
//         `https://maps.googleapis.com/maps/api/geocode/json?latlng=${position.coords.latitude},${position.coords.longitude}&key=${API_KEY}`,
//       );
//       setMyLocation({
//         address: data?.results[0].formatted_address,
//         location: {
//           latitude: position.coords.latitude,
//           longitude: position.coords.longitude,
//         },
//       });
//     }
//   },
//   error => {
//     // See error code charts below.
//     console.log(error.code, error.message);
//     alert('Can not get device location');
//   },
//   {enableHighAccuracy: true, timeout: 15000, maximumAge: 10000},
// );

// <View style={styles.locatnWrap}>
//         <View style={styles.locatnCircl}>
//           {user?.profilePic ? (
//             <Image
//               alt="my-img"
//               source={{
//                 uri: user?.profilePic,
//               }}
//               style={[
//                 styles.user,
//                 {position: 'relative', top: 5, borderRadius: 50},
//               ]}
//             />
//           ) : (
//             <Image
//               source={require('../assets/images/user1.png')}
//               style={[styles.user, {position: 'relative', top: 5}]}
//             />
//           )}
//         </View>
//       </View>

// latitude: 5.4816568
// longitude: 5.8047245

// {isFilter ? (
//         <>
//           {filterPosts &&
//             filterPosts?.length > 0 &&
//             filterPosts.map((p, i) => <MapMarker key={i} post={p} />)}
//         </>
//       ) : (
//         <>
//           {posts &&
//             posts?.length > 0 &&
//             posts
//               ?.filter(item => !item?.addMob)
//               ?.filter(po => po?.location !== null)
//               .map((p, i) => <MapMarker key={i} post={p} />)}
//         </>
//       )}
