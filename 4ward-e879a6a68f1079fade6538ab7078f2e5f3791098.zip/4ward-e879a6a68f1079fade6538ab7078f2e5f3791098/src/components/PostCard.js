import { useNavigation } from '@react-navigation/native';
import { HStack, Image, Pressable, Text, View } from 'native-base';
import React, { useCallback } from 'react';
import { Dimensions, StyleSheet, Platform } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import pagestyles from '../styles/story.style';
import PostCaurosel from './PostCaurosel';
import PostDesc from './PostDesc';
import PostActivity from '../components/PostActivity';
import { useMemo } from 'react';
import { AuthState } from '../context/authState';
import { BannerAd, TestIds, BannerAdSize } from 'react-native-google-mobile-ads';

const { width, height } = Dimensions.get('screen');
// const adUnitId = __DEV__
//   ? TestIds.BANNER
//   : // : 'ca-app-pub-1162359436302937~7760055737';
//     'ca-app-pub-1162359436302937~5026667913';

const ITEM_WIDTH = width;
const ITEM_HEIGHT = height * 0.33;

const PostCard = props => {
  const { authUser } = AuthState();

  const navigation = useNavigation();

  const isLiked = useMemo(
    () => props?.likes?.includes(authUser.uid),
    [props, authUser.uid],
  );

  const handelNavigateShare = useCallback(() => {
    navigation.navigate('Share', {
      data: { imageUrl: props?.imageUrl, videoUrl: props?.videoUrl },
    });
  }, [props]);

  const handelNavigateToMap = useCallback(() => {
    if (props?.location) {
      navigation.navigate('Homepage', {
        coords: {
          lat: props?.location?.location?.latitude,
          lon: props?.location?.location?.longitude,
        },
      });
    } else if (props?.center) {
      navigation.navigate('Homepage', {
        coords: {
          lat: parseFloat(props?.center?._latitude),
          lon: parseFloat(props?.center?._longitude),
        },
      });
    }
  }, [props]);

  const handelNavigateDetails = useCallback(() => {
    navigation.navigate('PostDetails', { postId: props?.id });
  }, []);

  return (
    <>
      {props?.addMob ? (
        <View style={pagestyles.storyBx} shadow="4">
          <BannerAd
            // unitId={TestIds.BANNER}
            unitId={Platform.OS === 'android' ? 'ca-app-pub-1162359436302937/7047914990' : 'ca-app-pub-1162359436302937/1046409584'}
            // unitId={adUnitId}
            size={BannerAdSize.FULL_BANNER}
            requestOptions={{
              requestNonPersonalizedAdsOnly: true,
            }}
          />
          {/* <Image
            alt="map-image"
            source={require(`../assets/images/addmob.png`)}
            style={{
              width: ITEM_WIDTH,
              // width: ITEM_WIDTH - 60,
              height: height * 0.25,
              resizeMode: 'cover',
            }}
          /> */}
        </View>
      ) : (
        <View style={pagestyles.storyBx} shadow="4">
          <HStack justifyContent="space-between" px={'4'} pt="4">
            <Text
              style={[pagestyles.cmnTitle, { fontSize: 20 }]}
              fontWeight={'bold'}>
              {props?.type === 'icon'
                ? props?.iconType
                : props?.type === 'image'
                  ? 'Snap shot'
                  : props?.type === 'video'
                    ? 'Live record'
                    : props?.type === 'sos' && 'Save our souls'}
            </Text>
          </HStack>

          <PostCaurosel
            post={props}
            handelNavigateToMap={handelNavigateToMap}
            index={props?.index}
            viewableItemId={props?.viewableItemId}
          />

          <View style={[pagestyles.headingSec, { paddingHorizontal: 15 }]}>
            <View style={pagestyles.storyTxtBx}>
              {props?.description && (
                <PostDesc description={props?.description} />
              )}
              <Pressable
                flexDirection={'row'}
                borderRadius="md"
                bg="gray.200"
                mb="3"
                px="2"
                borderColor={'gray.400'}
                borderWidth={2}
                // pt={'2'}
                alignItems="center"
                justifyContent={'space-between'}
                onPress={handelNavigateDetails}>
                <Text color={'gray.500'}>View more</Text>
                <Icon name="chevron-right" size={30} color="#aaa" />
              </Pressable>
              {props?.location && (
                <Pressable onPress={handelNavigateToMap}>
                  <HStack space={'2'} justifyContent="center">
                    <Icon name="location-on" size={20} color="#aaa" />
                    <Text style={pagestyles.cmnTxt}>
                      {props?.location?.address}
                    </Text>
                  </HStack>
                </Pressable>
              )}
              {props?.address && (
                <Pressable onPress={handelNavigateToMap}>
                  <HStack space={'2'} justifyContent="center">
                    <Icon name="location-on" size={20} color="#aaa" />
                    <Text style={pagestyles.cmnTxt}>{props?.address}</Text>
                  </HStack>
                </Pressable>
              )}
              {props?.isFilter ? (
                <>
                  <HStack space={'2'}>
                    <Icon name="access-time" size={20} color="#aaa" />
                    <HStack space={'2'}>
                      <Text style={pagestyles.cmnTitle}>
                        {new Date(
                          props?.date?._seconds * 1000,
                        ).toLocaleDateString()}
                      </Text>
                      <Text style={pagestyles.cmnTitle}>
                        {new Date(
                          props?.date?._seconds * 1000,
                        ).toLocaleTimeString()}
                      </Text>
                    </HStack>
                  </HStack>
                </>
              ) : (
                <>
                  {props?.date && (
                    <HStack space={'2'}>
                      <Icon name="access-time" size={20} color="#aaa" />
                      <HStack space={'2'}>
                        <Text style={pagestyles.cmnTitle}>
                          {new Date(
                            props?.date?._seconds * 1000,
                          ).toLocaleDateString()}
                          {/* {props?.date?.toDate().toLocaleDateString()} */}
                        </Text>
                        <Text style={pagestyles.cmnTitle}>
                          {new Date(
                            props?.date?._seconds * 1000,
                          ).toLocaleTimeString()}
                          {/* {props?.date?.toDate().toLocaleTimeString()} */}
                        </Text>
                      </HStack>
                    </HStack>
                  )}
                </>
              )}
            </View>
          </View>

          <PostActivity
            handelNavigateShare={handelNavigateShare}
            handelLikeUnlike={handelNavigateDetails}
            handelDisLike={handelNavigateDetails}
            isLiked={false}
            likes={props?.likes?.length || 0}
            disLikes={props?.disLikes?.length || 0}
            comments={props?.comments?.length || 0}
            showShare={false}
          />
        </View>
      )}
    </>
  );
};

export default PostCard;

const styles = StyleSheet.create({});

// const iconImg = useMemo(
//   () => props?.icId && props?.icId?.toLowerCase(),
//   [props?.icId],
// );

// const handelNavigate = useCallback(() => {
//   if (props?.type === 'image') {
//     navigation.navigate('Media', {type: props?.type, path: props?.imageUrl});
//   } else if (props?.type === 'video') {
//     navigation.navigate('Media', {type: props?.type, path: props?.videoUrl});
//   }
// }, [props?.videoUrl, props?.imageUrl, props?.type]);

// const handelPicNavigate = useCallback(() => {
//   if (props?.user?.profilePic) {
//     navigation.navigate('Media', {
//       type: 'image',
//       path: props?.user?.profilePic,
//     });
//   }
// }, [props?.user?.profilePic]);

// ======use

// {props?.type === 'image' && (
//       <Pressable
//         w="full"
//         style={[pagestyles.vdoSec]}
//         onPress={handelNavigate}>
//         <Image
//           alt="snap"
//           style={{
//             width: '100%',
//             flex: 1,
//             resizeMode: 'cover',
//             marginBottom: 15,
//             paddingTop: 10,
//             paddingBottom: 10,
//           }}
//           source={{uri: props?.imageUrl}}
//         />
//       </Pressable>
//     )}
//     {props?.type === 'video' && (
//       <Pressable w="full" style={pagestyles.vdoSec} onPress={handelNavigate}>
//         <Video
//           alt="snap"
//           resizeMode="cover"
//           fullscreen={true}
//           paused={true}
//           style={{
//             width: '100%',
//             marginBottom: 15,
//             paddingTop: 10,
//             paddingBottom: 10,
//             flex: 1,
//           }}
//           source={{uri: props?.videoUrl}}
//         />
//         <Icon
//           name="play-arrow"
//           color={'#fff'}
//           size={45}
//           style={{position: 'absolute', top: '35%', left: '45%'}}
//         />
//       </Pressable>
//     )}

//     {props?.type === 'icon' && (
//       <View style={pagestyles.vdoSec}>
//         <Image
//           alt="poster-image"
//           source={
//             iconImg === 'rr'
//               ? require(`../assets/images/rr.png`)
//               : iconImg === 'kd'
//               ? require(`../assets/images/kd.png`)
//               : iconImg === 'bd'
//               ? require(`../assets/images/bd.png`)
//               : iconImg === 'rb'
//               ? require(`../assets/images/rb.png`)
//               : iconImg === 'ot'
//               ? require(`../assets/images/ot.png`)
//               : iconImg === 'gs'
//               ? require(`../assets/images/gs.png`)
//               : iconImg === 'fr'
//               ? require(`../assets/images/fr.png`)
//               : iconImg === 'ac' && require(`../assets/images/ac.png`)
//           }
//           style={{
//             width: '100%',
//             flex: 1,
//             resizeMode: 'contain',
//             marginBottom: 15,
//             paddingTop: 10,
//             paddingBottom: 10,
//           }}
//         />
//       </View>
//     )}
//     {props?.type === 'sos' && (
//       <View style={pagestyles.vdoSec}>
//         <Image
//           alt="sos-image"
//           source={require('../assets/images/siren.png')}
//           // source={{
//           //   uri: 'https://maps.googleapis.com/maps/api/staticmap?CA&zoom=18&size=400x400&format=PNG&markers=22.9295,88.4249&key=AIzaSyCtjsZQHADLPVsE1X8iZu6iWG9Eopm00OA',
//           // }}
//           style={{
//             width: '100%',
//             flex: 1,
//             resizeMode: 'contain',
//             marginBottom: 15,
//             paddingTop: 10,
//             paddingBottom: 10,
//           }}
//         />
//       </View>
//     )}

// =======use

// =======user image

{
  /* {props?.user?.profilePic ? (
          <Pressable onPress={handelPicNavigate}>
            <Image
              alt="user"
              source={{uri: props?.user?.profilePic}}
              style={pagestyles.storyIcn}
              rounded="full"
            />
          </Pressable>
        ) : (
          <Box
            rounded={'full'}
            backgroundColor="#555"
            style={pagestyles.storyIcn}
          />
        )} */
}
// =======user image

{
  /* <View style={pagestyles.numList}>
          <Image
            alt="aaa"
            source={require('../assets/images/smlogo.png')}
            style={pagestyles.emoji}
            resizeMode={'contain'}
          />
        </View> */
}

{
  /* <Image
            alt="aaa"
            source={require('../assets/images/arrow.png')}
            style={pagestyles.emoji}
            resizeMode={'contain'}
          /> */
}

{
  /* <Image
            alt="aaa"
            source={require('../assets/images/emoji1.png')}
            style={pagestyles.emoji}
            resizeMode={'contain'}
          />
          <Image
            alt="aaa"
            source={require('../assets/images/emoji2.png')}
            style={pagestyles.emoji}
            resizeMode={'contain'}
          /> */
}

{
  /* <Image
            alt="aaa"
            source={require('../assets/images/comment.png')}
            style={pagestyles.emoji}
            resizeMode={'contain'}
          /> */
}

//  <Image
//             alt="user"
//             source={require('../assets/images/user2.png')}
//             style={pagestyles.storyIcn}
//           />

{
  /* <Text style={pagestyles.cmnTxt}>
            Car fire started early morning in Abuja blocking a major Rd.
          </Text> */
}

{
  /* <View style={pagestyles.btnSec}>
            <TouchableOpacity>
              <Text style={pagestyles.btnTxt}>SHARE WITH CONTACTS</Text>
            </TouchableOpacity>

            <TouchableOpacity>
              <Text style={pagestyles.btnTxt}>VIEW STORY</Text>
            </TouchableOpacity>
          </View> */
}
