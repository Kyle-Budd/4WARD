import { StyleSheet } from 'react-native';
import React, { useCallback, useMemo, useState } from 'react';
import { Pressable, Text, View } from 'native-base';

const PostDesc = props => {
  const [show, setshow] = useState(
    props?.description?.length > 100 ? true : false,
  );
  // const show = useMemo(
  //   () => props?.description?.length > 100,
  //   [props?.description?.length],
  // );

  const handelToggleShow = useCallback(() => {
    setshow(s => !s);
  }, []);

  return (
    <View mb={'2'}>
      {show ? (
        <Text color={'#646464'}>
          {props?.description.slice(0, 100)}...
          <Pressable onPress={handelToggleShow}>
            <Text color={'#900'}>show more</Text>
          </Pressable>
        </Text>
      ) : (
        <Text color={'#646464'}>
          {props?.description}{' '}
          {props?.description?.length > 100 && (
            <Pressable onPress={handelToggleShow}>
              <Text color={'#900'}> show less</Text>
            </Pressable>
          )}
        </Text>
      )}
    </View>
  );
};

export default PostDesc;

const styles = StyleSheet.create({});

//  Lorem ipsum dolor sit amet consectetur adipisicing
//         elit. Autem odit magni laborum molestias optio id non nulla similique
//         corrupti necessitatibus itaque sint deserunt temporibus tenetur error,
//         neque, dignissimos, harum atque modi ex quidem officia consequatur
//         mollitia suscipit. Quod dolor, veniam aspernatur eaque, debitis commodi
//         quas blanditiis saepe consequuntur fugit omnis.{' '}
