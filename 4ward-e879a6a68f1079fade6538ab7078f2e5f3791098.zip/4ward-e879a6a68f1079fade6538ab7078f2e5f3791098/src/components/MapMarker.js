import {useNavigation} from '@react-navigation/native';
import {Image} from 'native-base';
import React, {useMemo} from 'react';
import {Marker} from 'react-native-maps';

const MapMarker = ({post: p}) => {
  const navigation = useNavigation();
  const iconImg = useMemo(() => p?.icId && p?.icId?.toLowerCase(), [p?.icId]);

  // console.log('----posttype----', p.type, iconImg);

  return (
    <Marker
      onPress={() => navigation.navigate('PostDetails', {postId: p?.id})}
      coordinate={{
        latitude: p?.coordinates
          ? parseFloat(p?.coordinates?._latitude)
          : p?.center
          ? parseFloat(p?.center?._latitude)
          : p?.location?.location?.latitude,
        longitude: p?.coordinates
          ? parseFloat(p?.coordinates?._longitude)
          : p?.center
          ? parseFloat(p?.center?._longitude)
          : p?.location?.location?.longitude,
      }}>
      {p?.type === 'sos' ? (
        <Image
          alt="sos-image"
          // source={require('../assets/images/siren.png')}
          source={{
            uri: 'https://firebasestorage.googleapis.com/v0/b/ward-af760.appspot.com/o/icons%2Fsiren.png?alt=media&token=13722dba-8a1b-46e9-866d-e688f156f51e',
          }}
          style={{
            width: 25,
            height: 25,
            resizeMode: 'contain',
          }}
        />
      ) : p?.type === 'icon' ? (
        <Image
          alt="sos-image"
          source={{
            uri:
              iconImg === 'rr'
                ? 'https://firebasestorage.googleapis.com/v0/b/ward-af760.appspot.com/o/icons%2Frr.png?alt=media&token=a6591996-f723-4573-bfc3-987b49dfe581'
                : iconImg === 'kd'
                ? 'https://firebasestorage.googleapis.com/v0/b/ward-af760.appspot.com/o/icons%2Fkd.png?alt=media&token=bc3f9c4b-cda2-4f7b-be44-d680dea7fe7e'
                : iconImg === 'bd'
                ? 'https://firebasestorage.googleapis.com/v0/b/ward-af760.appspot.com/o/icons%2Fbd.png?alt=media&token=b37d21ba-3b9b-4e1c-b802-859e6b7bf995'
                : iconImg === 'rb'
                ? 'https://firebasestorage.googleapis.com/v0/b/ward-af760.appspot.com/o/icons%2Frb.png?alt=media&token=1c72c25b-4945-436a-8aed-fc21a95d0c9d'
                : iconImg === 'ot'
                ? 'https://firebasestorage.googleapis.com/v0/b/ward-af760.appspot.com/o/icons%2Fot.png?alt=media&token=32bfaf30-73e5-4965-af3e-ac4b619fd0ea'
                : iconImg === 'gs'
                ? 'https://firebasestorage.googleapis.com/v0/b/ward-af760.appspot.com/o/icons%2Fgs.png?alt=media&token=8eac2d12-9db7-43c7-8cab-64cfdaf4864d'
                : iconImg === 'fr'
                ? 'https://firebasestorage.googleapis.com/v0/b/ward-af760.appspot.com/o/icons%2Ffr.png?alt=media&token=65147a5a-3682-4aae-89a7-fb5b1a47314f'
                : iconImg === 'ac' &&
                  'https://firebasestorage.googleapis.com/v0/b/ward-af760.appspot.com/o/icons%2Fac.png?alt=media&token=9959f51c-0740-428f-83cc-e4ad74f01867',
          }}
          style={{
            width: 25,
            height: 25,
            resizeMode: 'contain',
          }}
        />
      ) : (
        (p?.type === 'image' || p?.type === 'video') && (
          <Image
            alt="media"
            // source={require(`../assets/images/4waed_logo.png`)}
            source={{
              uri: 'https://firebasestorage.googleapis.com/v0/b/ward-af760.appspot.com/o/icons%2F4waed_logo.png?alt=media&token=35b261bc-f2e5-4742-8bfd-64a295cc07f9',
            }}
            style={{
              width: 25,
              height: 25,
              resizeMode: 'contain',
            }}
          />
        )
      )}
    </Marker>
  );
};

export default MapMarker;

// source={
// iconImg === 'rr'
//   ? require(`../assets/images/rr.png`)
//   : iconImg === 'kd'
//   ? require(`../assets/images/kd.png`)
//   : iconImg === 'bd'
//   ? require(`../assets/images/bd.png`)
//   : iconImg === 'rb'
//   ? require(`../assets/images/rb.png`)
//   : iconImg === 'ot'
//   ? require(`../assets/images/ot.png`)
//   : iconImg === 'gs'
//   ? require(`../assets/images/gs.png`)
//   : iconImg === 'fr'
//   ? require(`../assets/images/fr.png`)
//   : iconImg === 'ac' && require(`../assets/images/ac.png`)
// }
