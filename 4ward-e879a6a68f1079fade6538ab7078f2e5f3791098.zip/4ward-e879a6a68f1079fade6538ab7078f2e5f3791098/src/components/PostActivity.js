// import { Pressable, Text, View } from 'native-base';
// import React, { useState, useEffect } from 'react';
// import pagestyles from '../styles/story.style';
// import EvilIcons from 'react-native-vector-icons/EvilIcons';
// import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
// import Ionicons from 'react-native-vector-icons/Ionicons';

// var likestatus=false;
// var disLikeStatus=false;
// var likesCount=0;
// var dislikesCount=0;

// function PostActivity({
//   handelNavigateShare,
//   handelLikeUnlike,
//   handelDisLike,
//   likes,
//   disLikes,
//   comments,
//   isLiked,
//   isDisLiked,
//   showShare,
// }) {
//   const [like, setLike] = useState();
//   const [dislike, setDislike] = useState();

//   const [likeCount, setLikeCount] = useState();
//   const [dislikeCount, setDislikeCount] = useState();

//   useEffect(() => {
//     // setLike(isLiked);
//     // setDislike(isDisLiked);
//     // setLikeCount(likes);
//     // setDislikeCount(disLikes);
//     likestatus=isLiked;
//     disLikeStatus=isDisLiked;
//     likesCount=likes;
//     dislikesCount=disLikes;
//   });

//   return (
//     <View
//       style={[
//         {
//           flexDirection: 'row',
//           justifyContent: showShare ? 'space-between' : 'space-around',
//           paddingHorizontal: 15,
//           paddingBottom: 15,
//         },
//       ]}>
//       <Pressable style={pagestyles.numList}
//         onPress={() => {
//           // setLike(true);
//           // setLikeCount(likeCount+1);
//           // setDislike(false);
//           // setDislikeCount(dislikeCount-1);
//           likestatus=!likestatus;

//           handelLikeUnlike();
//         }}

//       // onPress={handelLikeUnlike}
//       >
//         {likestatus?<MaterialCommunityIcons
//           name='heart'
//           size={25}
//           color={'#900'}
//         />:<MaterialCommunityIcons
//         name='heart-outline'
//         size={25}
//         color={'#900'}
//       />}
        
//         <Text style={pagestyles.numbr} ml="1">
//           {likesCount}
//         </Text>
//       </Pressable>
//       <Pressable style={pagestyles.numList}
//         onPress={() => {
//           // setDislike(true);
//           // setDislikeCount(dislikeCount+1);

//           // setLike(false);
//           // setLikeCount(likeCount-1);

//           handelDisLike()
//         }}
//       // onPress={handelDisLike}
//       >
//         <MaterialCommunityIcons
//           name={!disLikeStatus ? 'heart-off-outline' : 'heart-off'}
//           size={25}
//           color={'#900'}
//         />
//         <Text style={pagestyles.numbr} ml="1">
//           {dislikesCount}
//         </Text>
//       </Pressable>
//       <Pressable style={pagestyles.numList}>
//         <EvilIcons name="comment" size={30} color="#900" />
//         <Text style={pagestyles.numbr} ml="1">
//           {comments}
//         </Text>
//       </Pressable>
//       {showShare && (
//         <Pressable style={pagestyles.numList} onPress={handelNavigateShare}>
//           <EvilIcons name="share-google" size={30} color="#900" />
//           <Text style={pagestyles.numbr} ml="1">
//             Share
//           </Text>
//         </Pressable>
//       )}
//     </View>
//   );
// }

// export default PostActivity;

import {Pressable, Text, View} from 'native-base';
import React from 'react';
import pagestyles from '../styles/story.style';
import EvilIcons from 'react-native-vector-icons/EvilIcons';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Ionicons from 'react-native-vector-icons/Ionicons';

function PostActivity({
  handelNavigateShare,
  handelLikeUnlike,
  handelDisLike,
  likes,
  disLikes,
  comments,
  isLiked,
  isDisLiked,
  showShare,
}) {
  return (
    <View
      style={[
        {
          flexDirection: 'row',
          justifyContent: showShare ? 'space-between' : 'space-around',
          paddingHorizontal: 15,
          paddingBottom: 15,
        },
      ]}>
      <Pressable style={pagestyles.numList} onPress={handelLikeUnlike}>
        <MaterialCommunityIcons
          name={isLiked ? 'heart' : 'heart-outline'}
          size={25}
          color={'#900'}
        />
        <Text style={pagestyles.numbr} ml="1">
          {likes}
        </Text>
      </Pressable>
      <Pressable style={pagestyles.numList} onPress={handelDisLike}>
        <MaterialCommunityIcons
          name={!isDisLiked ? 'heart-off-outline' : 'heart-off'}
          size={25}
          color={'#900'}
        />
        <Text style={pagestyles.numbr} ml="1">
          {disLikes}
        </Text>
      </Pressable>
      <Pressable style={pagestyles.numList}>
        <EvilIcons name="comment" size={30} color="#900" />
        <Text style={pagestyles.numbr} ml="1">
          {comments}
        </Text>
      </Pressable>
      {showShare && (
        <Pressable style={pagestyles.numList} onPress={handelNavigateShare}>
          <EvilIcons name="share-google" size={30} color="#900" />
          <Text style={pagestyles.numbr} ml="1">
            Share
          </Text>
        </Pressable>
      )}
    </View>
  );
}

export default PostActivity;

