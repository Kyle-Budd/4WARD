import {useNavigation} from '@react-navigation/native';
import {HStack, Pressable} from 'native-base';
import React, {useCallback, useMemo} from 'react';
import {StyleSheet, Text, View} from 'react-native';
import {AuthState} from '../context/authState';
import pagestyles from '../styles/homepage.style';

//This function takes in latitude and longitude of two location and returns the distance between them as the crow flies (in km)
function calcCrow(lat1, lon1, lat2, lon2) {
  var R = 6371; // km
  var dLat = toRad(lat2 - lat1);
  var dLon = toRad(lon2 - lon1);
  var lat1 = toRad(lat1);
  var lat2 = toRad(lat2);

  var a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2);
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  var d = R * c;
  return d;
}

// Converts numeric degrees to radians
function toRad(Value) {
  return (Value * Math.PI) / 180;
}

const AlertCard = props => {
  const navigation = useNavigation();
  const {user} = AuthState();

  const distance = useMemo(() => {
    const userLat = user?.location?.location?.latitude;
    const userLon = user?.location?.location?.longitude;
    const postLat = props?.coordinates
      ? parseFloat(props?.coordinates?._latitude)
      : props?.center
      ? parseFloat(props?.center?._latitude)
      : props?.location?.location?.latitude;
    const postLon = props?.coordinates
      ? parseFloat(props?.coordinates?._longitude)
      : props?.center
      ? parseFloat(props?.center?._longitude)
      : props?.location?.location?.longitude;

    return calcCrow(userLat, userLon, postLat, postLon);
  }, [user, props]);

  const handelSetLocation = useCallback(() => {
    if (props?.location) {
      props.setcenter({
        latitude: props?.location?.location?.latitude,
        longitude: props?.location?.location?.longitude,
      });
    }

    if (props?.center) {
      props.setcenter({
        latitude: parseFloat(props?.center?._latitude),
        longitude: parseFloat(props?.center?._longitude),
      });
    }
  }, [props?.location, props?.center]);

  const handelNavigateDetails = useCallback(() => {
    navigation.navigate('PostDetails', {postId: props?.id});
  }, []);

  return (
    <Pressable
      style={pagestyles.liList}
      p="2"
      mx={'1'}
      shadow={'4'}
      rounded={'sm'}
      bg="#eee"
      onPress={handelNavigateDetails}>
      <View style={pagestyles.forwardSec}>
        {props?.type === 'icon' ? (
          <Text style={[pagestyles.listTitle]}>{props?.iconType}</Text>
        ) : props?.type === 'image' ? (
          <Text style={[pagestyles.listTitle]}>Snap shot</Text>
        ) : props?.type === 'video' ? (
          <Text style={[pagestyles.listTitle]}>Live record</Text>
        ) : (
          props?.type === 'sos' && (
            <Text style={[pagestyles.listTitle]}>SOS</Text>
          )
        )}
      </View>
      <HStack space={'5'} style={pagestyles.forwardSec}>
        {props?.location && (
          <Text style={[pagestyles.subTxt, {flex: 2}]} numberOfLines={2}>
            {props?.location?.address}
          </Text>
        )}
        {props?.address && (
          <Text style={[pagestyles.subTxt, {flex: 2}]} numberOfLines={2}>
            {props?.address}
          </Text>
        )}

        {props?.location && (
          <Text style={[pagestyles.subTxt, {flex: 1}]}>
            {distance.toFixed(2)}
            <Text> KM Away</Text>
          </Text>
        )}
        {props?.center && (
          <Text style={[pagestyles.subTxt, {flex: 1}]}>
            {distance.toFixed(2)}
            <Text> KM Away</Text>
          </Text>
        )}
        {props?.coordinates && (
          <Text style={[pagestyles.subTxt, {flex: 1}]}>
            {distance.toFixed(2)}
            <Text> KM Away</Text>
          </Text>
        )}
      </HStack>
    </Pressable>
  );
};

export default AlertCard;

const styles = StyleSheet.create({});

//  <TouchableOpacity>
//         <Image
//           alt="arrow"
//           source={require('../assets/images/arrow2.png')}
//           style={pagestyles.arw2}
//           resizeMode={'contain'}
//         />
//       </TouchableOpacity>
