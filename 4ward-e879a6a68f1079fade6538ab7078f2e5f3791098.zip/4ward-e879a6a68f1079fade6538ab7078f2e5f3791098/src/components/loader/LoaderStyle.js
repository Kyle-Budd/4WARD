import { StyleSheet, PixelRatio, Dimensions } from 'react-native';
import { ThemeColors } from './main.style';
let ScreenHeight = Dimensions.get('window').height;
let ScreenWidth = Dimensions.get('window').width;

export default StyleSheet.create({
    container: {
        backgroundColor: '#00000025',
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        justifyContent: 'center',
        alignItems: 'center',
    }
});
