import React from 'react';
// import { View, ActivityIndicator } from 'react-native';
import { Spinner, View } from 'native-base';
import styles from './LoaderStyle';

export default function Loader() {
    return (
        <View style={styles.container}>
            <Spinner color={'#900'} size={'lg'} />
        </View>
    );
}
