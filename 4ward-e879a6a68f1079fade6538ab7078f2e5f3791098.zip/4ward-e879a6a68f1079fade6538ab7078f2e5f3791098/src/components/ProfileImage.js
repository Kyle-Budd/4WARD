import firestore from '@react-native-firebase/firestore';
import storage from '@react-native-firebase/storage';
import {useNavigation} from '@react-navigation/native';
import {Image, Pressable, Spinner, useToast} from 'native-base';
import React, {useCallback, useState} from 'react';
import {StyleSheet} from 'react-native';
import {launchImageLibrary} from 'react-native-image-picker';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {AuthState} from '../context/authState';

const ProfileImage = () => {
  const {authUser, user} = AuthState();
  const toast = useToast();
  const navigation = useNavigation();
  const [loading, setloading] = useState(false);

  const handelUploadPic = useCallback(async () => {
    try {
      setloading(true);
      const result = await launchImageLibrary();
      console.log(result);
      if (!result?.didCancel) {
        const reference = storage().ref(
          `images/${result?.assets[0]?.fileName}`,
        );
        const pathToFile = result?.assets[0]?.uri;
        console.log('-----path---', pathToFile);
        await reference.putFile(pathToFile);
        const url = await storage()
          .ref(`images/${result?.assets[0]?.fileName}`)
          .getDownloadURL();
        await firestore().doc(`users/${authUser.uid}`).update({
          profilePic: url,
        });
        toast.show({
          description: 'Profile pic updated',
        });
      }
    } catch (error) {
      console.error(error);
      alert('image upload faild');
    } finally {
      setloading(false);
    }
  }, []);

  const handelNavigation = useCallback(() => {
    if (user?.profilePic) {
      navigation.navigate('Media', {type: 'image', path: user?.profilePic});
    }
  }, [user?.profilePic]);

  return (
    <Pressable
      onPress={handelNavigation}
      height={100}
      width={100}
      rounded={'full'}
      borderWidth={3}
      borderColor={'#900'}
      position="relative"
      p={1}>
      {user?.profilePic ? (
        <Image
          alt="my_img"
          source={{
            uri: user?.profilePic,
          }}
          height={'full'}
          width={'full'}
          rounded={'full'}
          resizeMethod={'scale'}
        />
      ) : (
        <Image
          alt="my_img"
          source={require('../assets/images/user1.png')}
          height={'full'}
          width={'full'}
          rounded={'full'}
          resizeMethod={'scale'}
        />
      )}
      {!loading ? (
        <Icon
          onPress={handelUploadPic}
          name="pencil-circle"
          size={35}
          color={'#000'}
          style={{
            position: 'absolute',
            bottom: -8,
            right: -5,
          }}
        />
      ) : (
        <Spinner
          size={'sm'}
          color={'#900'}
          style={{
            position: 'absolute',
            bottom: -8,
            right: -5,
          }}
        />
      )}
    </Pressable>
  );
};

export default ProfileImage;

const styles = StyleSheet.create({});
