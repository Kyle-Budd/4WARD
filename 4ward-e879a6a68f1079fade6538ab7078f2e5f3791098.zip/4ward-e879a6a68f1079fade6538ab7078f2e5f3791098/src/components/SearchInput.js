/* eslint-disable react/prop-types */
import {View} from 'native-base';
import React from 'react';
import {GooglePlacesAutocomplete} from 'react-native-google-places-autocomplete';
import {API_KEY} from '../utils/apiKey';

function SearchInput({}) {
  const inputRef = React.useRef();

  return (
    <View
      style={
        {
          // zIndex: 100,
          // justifyContent: "center",
          // alignItems: "center",
          // flex: 1,
          // position: "absolute",
          // top: 0,
          // left: 0,
          // right: 0,
          // marginBottom: 5,
          // paddingHorizontal: 5,
          // shadowOffset: { width: 10, height: 10 },
          // shadowOpacity: 0.5,
        }
      }>
      <GooglePlacesAutocomplete
        styles={{
          container: {borderRadius: 50, zIndex: 100, width: '100%'},
          textInputContainer: {
            borderRadius: 50,
            zIndex: 100,
            width: '100%',
          },
          listView: {zIndex: 100},
          textInput: {
            paddingStart: 20,
            borderRadius: 50,
            zIndex: 100,
            marginTop: 5,
            borderWidth: 2,
          },
        }}
        // textInputProps={{
        //   autoFocus: isFocusInput,
        //   onFocus: () => console.log("hii"),
        // }}
        enablePoweredByContainer={false}
        placeholder="Find a safe route"
        nearbyPlacesAPI="GooglePlacesSearch"
        onPress={(data, details = null) => {
          console.log(details);
        }}
        query={{
          key: API_KEY,
          language: 'en',
          // components: "country:us",
        }}
        ref={inputRef}
        debounce={500}
        fetchDetails={true}
        GooglePlacesDetailsQuery={{fields: 'geometry'}}
      />
    </View>
  );
}

export default SearchInput;
