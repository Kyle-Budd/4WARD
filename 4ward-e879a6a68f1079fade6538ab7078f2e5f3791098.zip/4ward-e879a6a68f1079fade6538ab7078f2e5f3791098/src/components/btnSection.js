// import {useNavigation} from '@react-navigation/native';
// import {Actionsheet, Button, Icon, Text, useDisclose, View} from 'native-base';
// import React, {useCallback} from 'react';
// import {StyleSheet} from 'react-native';
// import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
// import pagestyles from '../styles/homepage.style';

// const BtnSection = ({handelSendSos}) => {
//   const navigation = useNavigation();

//   const {isOpen, onOpen, onClose} = useDisclose();

//   const handelnavigate = useCallback(screenName => {
//     onClose();
//     navigation.navigate(screenName);
//   }, []);

//   return (
//     <View my={'2'} mx={'4'}>
//       <Button onPress={onOpen} bg="error.500">
//         <Text fontSize={'lg'} fontWeight="bold" color={'#fff'}>
//           Add Report
//         </Text>
//       </Button>

//       <Actionsheet isOpen={isOpen} onClose={onClose}>
//         <Actionsheet.Content>
//           <Actionsheet.Item
//             onPress={() => handelnavigate('TakeVideo')}
//             bg={'gray.200'}
//             my={'1'}
//             justifyContent="center"
//             startIcon={
//               <Icon
//                 as={MaterialCommunityIcons}
//                 color="error.500"
//                 mr="1"
//                 size="6"
//                 name="record"
//               />
//             }>
//             <Text fontSize={'lg'}>REPORT LIVE</Text>
//           </Actionsheet.Item>
//           <Actionsheet.Item
//             onPress={() => handelnavigate('TakeSnap')}
//             bg={'gray.200'}
//             my={'1'}
//             justifyContent="center"
//             startIcon={
//               <Icon
//                 as={MaterialCommunityIcons}
//                 color="error.500"
//                 mr="1"
//                 size="6"
//                 name="camera"
//               />
//             }>
//             <Text fontSize={'lg'}>SNAP SHOT</Text>
//           </Actionsheet.Item>
//           <Actionsheet.Item
//             onPress={() => handelnavigate('IconReport')}
//             bg={'gray.200'}
//             my={'1'}
//             justifyContent="center"
//             startIcon={
//               <Icon
//                 as={MaterialCommunityIcons}
//                 color="error.500"
//                 mr="1"
//                 size="6"
//                 name="plus-thick"
//               />
//             }>
//             <Text fontSize={'lg'}>ICON REPORT</Text>
//           </Actionsheet.Item>
//           <Actionsheet.Item
//             onPress={handelSendSos}
//             bg={'gray.200'}
//             my={'1'}
//             justifyContent="center"
//             startIcon={
//               <Icon
//                 as={MaterialCommunityIcons}
//                 color="error.500"
//                 mr="1"
//                 size="6"
//                 name="alert-circle"
//               />
//             }>
//             <Text fontSize={'lg'}>SOS</Text>
//           </Actionsheet.Item>
//         </Actionsheet.Content>
//       </Actionsheet>
//     </View>
//   );
// };

// export default BtnSection;

// const styles = StyleSheet.create({});

// //  <TouchableOpacity
// //               style={pagestyles.btn}
// //               onPress={() => navigation.navigate('TakeVideo')}>
// // <Image
// //   source={require('../assets/images/circl1.png')}
// //   style={pagestyles.icn}
// // />
// //             <Text style={pagestyles.btnTxt}>REPORT LIVE</Text>
// //             </TouchableOpacity>

// //  <TouchableOpacity
// //               style={pagestyles.btn}
// //               onPress={() => navigation.navigate('TakeSnap')}>
// //               <Image
// //                 source={require('../assets/images/camera.png')}
// //                 style={pagestyles.icn}
// //               />
// //               <Text style={pagestyles.btnTxt}>SNAP SHOT</Text>
// //             </TouchableOpacity>

// // <TouchableOpacity
// //             style={pagestyles.btn}
// //             onPress={() => navigation.navigate('IconReport')}>
// //             <Image
// //               source={require('../assets/images/plus.png')}
// //               style={pagestyles.icn}
// //             />
// //             <Text style={pagestyles.btnTxt}>ICON REPORT</Text>
// //           </TouchableOpacity>

// //  <TouchableOpacity style={pagestyles.btn} onPress={handelSendSos}>
// //               <Image
// //                 source={require('../assets/images/siren.png')}
// //                 style={pagestyles.icn}
// //                 resizeMode={'contain'}
// //               />
// //               <Text style={pagestyles.btnTxt}>SOS</Text>
// //             </TouchableOpacity>
