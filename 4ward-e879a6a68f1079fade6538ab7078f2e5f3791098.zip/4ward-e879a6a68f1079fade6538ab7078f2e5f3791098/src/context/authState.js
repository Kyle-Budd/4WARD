import React, { createContext, useContext, useState, useEffect } from 'react';
import firestore from '@react-native-firebase/firestore';
import Contacts from 'react-native-contacts';

const AuthContext = createContext();

export const AuthContextProvider = ({ children }) => {
  const [isUserExists, setIsUserExists] = useState(false);
  const [userBan, setUserBan] = useState(false);
  const [authUser, setAuthUser] = useState(null);
  const [myLocation, setMyLocation] = useState(null);
  const [confirm, setConfirm] = useState(null);
  const [phoneNumber, setphoneNumber] = useState('');
  const [countryCode, setCountryCode] = useState(234);
  const [user, setuser] = useState(null);
  const [deviceToken, setDeviceToken] = useState(null);
  const [contacts, setContacts] = useState([]);

  useEffect(() => {
    let subs = () => { };
    if (authUser) {
      subs = firestore()
        .collection('users')
        .doc(authUser?.uid)
        .onSnapshot(docSnapshot => {
          setuser({ ...docSnapshot?.data(), id: docSnapshot?.id });
          if (docSnapshot?.data()?.banStatus) {
            setUserBan(true);
          }
        });
    }

    return () => subs();
  }, [authUser]);

  useEffect(() => {
    if (myLocation && user) {
      (async () => {
        try {
          await firestore().collection('users').doc(user?.id).update({
            location: myLocation,
          });
        } catch (error) {
          console.error('---error---', error);
        }
      })();
    }
  }, [myLocation, user]);

  const loadContacts = () => {
    Contacts.getAll()
      .then(contacts => {
        contacts.sort(
          (a, b) => a.givenName.toLowerCase() > b.givenName.toLowerCase(),
        );
        setContacts(contacts);
      })
      .catch(e => {
        // alert('Permission to access contacts was denied');
        console.warn('Permission to access contacts was denied');
      });
  };

  return (
    <AuthContext.Provider
      value={{
        confirm,
        setConfirm,
        phoneNumber,
        setphoneNumber,
        authUser,
        user,
        setuser,
        setAuthUser,
        countryCode,
        setCountryCode,
        myLocation,
        setMyLocation,
        isUserExists,
        setIsUserExists,
        deviceToken,
        setDeviceToken,
        contacts,
        setContacts,
        loadContacts,
        userBan,
        setUserBan,
      }}>
      {children}
    </AuthContext.Provider>
  );
};

export const AuthState = () => useContext(AuthContext);
