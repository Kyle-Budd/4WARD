import firestore from '@react-native-firebase/firestore';
// import * as geofirestore from 'geofirestore';
import {Alert, Text} from 'native-base';
import React, {createContext, useContext, useEffect, useState} from 'react';
import uuid from 'react-native-uuid';

const PostContext = createContext();
const firestoreApp = firestore();
// const GeoFirestore = geofirestore.initializeApp(firestoreApp);

export const PostContextProvider = ({children}) => {
  const [posts, setPosts] = useState([]);
  const [imageSrc, setimageSrc] = useState(null);
  const [videoSrc, setvideoSrc] = useState(null);
  const [postLoading, setPostLoading] = useState(true);
  const [postCenter, setPostCenter] = useState(null);
  const [postRadius, setPostRadius] = useState(null);

  const [filterPosts, setfilterPosts] = useState([]);
  const [isFilter, setisFilter] = useState(false);

  const [imageSrcList, setimageSrcList] = useState([]);

  // console.log('-----post data----', posts && posts.filter(p => p?.addMob));

  // console.log('---postCenter---', postCenter);

  useEffect(() => {
    let unsubscribe;
    try {
      unsubscribe = firestoreApp
        .collection('posts')
        .orderBy('date', 'desc')
        .limit(50)
        .onSnapshot(
          async querySnapshot => {
            let postArr = [
              ...querySnapshot.docs.map(d => ({
                ...d.data(),
                // cid: uuid.v4(),
                // user: userProfiles?.find(u => u.id === d.data().userId)?.data(),
              })),
            ];

            const numberOfAdds = postArr.length > 3 ? postArr.length / 3 : 1;

            for (let i = 1; i <= numberOfAdds; i++) {
              postArr.splice(i == 1 ? 3 : i * 4, 0, {
                addMob: true,
                id: uuid.v4(),
              });
            }
            setPosts(postArr);
            setPostLoading(false);
          },
          err => {
            alert('Something went wrong');
            console.log(`Encountered error: ${err}`);
            setPostLoading(false);
          },
        );
    } catch (error) {
      console.error(error);
      alert('faild to fetch posts');
    }

    return () => unsubscribe();
  }, []);

  // console.log('-----posts----', posts);
  // console.log('-----postRadius----', postRadius);

  // if (postLoading) {
  //   return <Customloader color={'#900'} />;
  // }

  return (
    <PostContext.Provider
      value={{
        posts,
        setPosts,
        postLoading,
        imageSrc,
        setimageSrc,
        imageSrcList,
        setimageSrcList,
        videoSrc,
        postCenter,
        postRadius,
        setvideoSrc,
        setPostCenter,
        setPostRadius,
        filterPosts,
        setfilterPosts,
        isFilter,
        setisFilter,
      }}>
      {postLoading && (
        <Alert
          borderRadius={'none'}
          w="100%"
          status={'error'}
          backgroundColor={'#900'}>
          <Text textAlign={'center'} color="#fff">
            loading content...
          </Text>
        </Alert>
      )}
      {children}
    </PostContext.Provider>
  );
};

export const PostState = () => useContext(PostContext);

// setLastDocument(
//   querySnapshot.docs[querySnapshot.docs.length - 1],
// );
// console.log('Total posts: ', querySnapshot.size);

// const userProfiles = await Promise.all(
//   querySnapshot.docs.map(documentSnapshot =>
//     firestore()
//       .collection('users')
//       .doc(documentSnapshot.data().userId)
//       .get(),
//   ),
// );