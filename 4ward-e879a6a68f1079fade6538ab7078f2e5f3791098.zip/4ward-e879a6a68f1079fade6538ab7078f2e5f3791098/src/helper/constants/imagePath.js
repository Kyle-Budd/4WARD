export default {
    icCurLoc: require('../../assets/img/Oval.png'),
    icGreenMarker: require("../../assets/img/greenMarker.png"),
    greenIndicator: require("../../assets/img/greenIndicator.png"),
    icBike: require("../../assets/img/bike.png"),
}