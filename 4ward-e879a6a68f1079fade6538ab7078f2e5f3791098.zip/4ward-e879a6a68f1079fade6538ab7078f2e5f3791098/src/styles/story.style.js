import {Dimensions, StyleSheet} from 'react-native';
let ScreenHeight = Dimensions.get('window').height;
let ScreenWidth = Dimensions.get('window').width;

export default StyleSheet.create({
  container: {
    padding: 15,
  },
  storyBx: {
    backgroundColor: '#eee',
    // padding: 15,
    // borderRadius: 10,
    marginBottom: 20,
  },
  headingSec: {
    flexDirection: 'row',
    marginBottom: 10,
    marginTop: 10,
  },
  storyIcn: {
    width: 58,
    height: 58,
    marginRight: 20,
  },
  storyTxtBx: {
    flex: 1,
  },
  cmnTitle: {
    fontSize: 14,
    color: '#000',
    marginBottom: 10,
  },
  cmnTxt: {
    flex: 1,
    flexWrap: 'wrap',
    color: '#000',
    marginBottom: 10,
  },
  btnSec: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  btnTxt: {
    fontSize: 10,
    color: '#F60404',
    borderWidth: 1,
    borderRadius: 5,
    borderColor: '#F60404',
    padding: 10,
    textTransform: 'uppercase',
  },
  vdoImg: {
    width: '100%',
    flex: 1,
    resizeMode: 'cover',
    marginBottom: 15,
    paddingTop: 10,
    paddingBottom: 10,
  },
  vdoSec: {
    height: 300,
    width: 100,
    flex: 1,
    overflow: 'hidden',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  numbrSec: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    // paddingTop: 10,
  },
  emoji: {
    width: 17,
    height: 14,
    marginRight: 5,
  },
  numList: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  numbr: {
    fontSize: 15,
    color: '#646464',
  },
});
