import {StyleSheet, PixelRatio, Dimensions} from 'react-native';
import {ThemeColors} from '../styles/main.style';
let ScreenHeight = Dimensions.get('window').height;
let ScreenWidth = Dimensions.get('window').width;

export default StyleSheet.create({
  contentContainer: {
    flex: 1,
    backgroundColor: '#000',
    height: '100%',
    padding: 30,
  },
  title1: {
    color: '#fff',
    fontSize: 20,
    paddingTop: 50,
    paddingBottom: 10,
  },
  subTxt: {
    color: ' #646464',
    fontSize: 18,
  },
  lableTitle: {
    fontSize: 16,
    color: '#fff',
    marginBottom: 5,
  },
  formsetup: {
    paddingTop: 50,
  },
  signText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    textTransform: 'uppercase',
  },
  terms: {
    flexDirection: 'row',
    justifyContent: 'center',
    color: '#fff',
  },
  redColor: {
    color: '#F60404',
    fontSize: 16,
  },
  whitClr: {
    color: '#fff',
    fontSize: 16,
  },
  mapsubtxt2: {
    justifyContent: 'center',
    textAlign: 'center',
    color: '#fff',
    marginTop: 15,
    fontSize: 16,
    paddingBottom: 5,
  },
  btn2: {
    backgroundColor: '#F60404',
    height: 48,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 15,
  },
});
