import {StyleSheet, PixelRatio, Dimensions} from 'react-native';
let ScreenHeight = Dimensions.get('window').height;
let ScreenWidth = Dimensions.get('window').width;

export const ThemeColors = {
  primaryColor: '#1F41A0',
  secondaryColor: '#F05813',
  darkgreyColor: '#303030',
  lightgreyColor: '#7B7B7B',
  offwhiteColor: '#F2F2F2',
  whiteColor: '#ffffff',
  blackColor: '#000000',
  redColor: '#e21313',
  greenColor: '#0AC725',
  blueColor: '#1DBCF3',
  orangeColor: '#FF9900',
};

export default StyleSheet.create({
  Flex1: {
    flex: 1,
  },
  GreyBg: {
    backgroundColor: "#F5F6FA",
  },
  Heading: {
    fontSize: 16,
    color: ThemeColors.blackColor,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  cardViewStyle: {
    backgroundColor: ThemeColors.whiteColor,
    shadowColor: '#000000',
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
    shadowOffset: {height: 2, width: 0},
    padding: 15,
    borderRadius: 15,
    margin: 5,
    marginTop: 10,
  },
  buttonPrimary: {
    backgroundColor: ThemeColors.primaryColor,
    height: 50,
    borderRadius: 30,
    justifyContent: 'center',
    paddingLeft: 15,
    paddingRight: 15,
  },
  buttonDisable: {
    backgroundColor: ThemeColors.lightgreyColor,
    height: 50,
    borderRadius: 30,
    justifyContent: 'center',
    paddingLeft: 15,
    paddingRight: 15,
  },
  buttonPrimaryText: {
    color: ThemeColors.whiteColor,
    textAlign: 'center',
    fontSize: 14,
  },
  buttonSuccess: {
    backgroundColor: ThemeColors.greenColor,
    height: 50,
    borderRadius: 30,
    justifyContent: 'center',
    paddingLeft: 15,
    paddingRight: 15,
  },
  buttonSecondary: {
    backgroundColor: ThemeColors.blueColor,
    height: 50,
    borderRadius: 30,
    justifyContent: 'center',
    paddingLeft: 15,
    paddingRight: 15,
  },
  buttonOutline: {
    borderWidth: 2,
    borderColor: ThemeColors.primaryColor,
    height: 50,
    borderRadius: 30,
    justifyContent: 'center',
    paddingLeft: 15,
    paddingRight: 15,
    flexDirection: 'row',
    alignItems: 'center',
  },
  buttonOutlineText: {
    color: ThemeColors.primaryColor,
    textAlign: 'center',
    fontSize: 14,
    fontWeight: 'bold',
  },
  formControl: {
    height: 60,
    color: ThemeColors.blackColor,
    marginBottom: 15,
    backgroundColor: ThemeColors.whiteColor,
    paddingLeft: 15,
    paddingRight: 15,
    fontSize: 14,
    borderWidth: 1,
    borderColor: "#B7B7B7",
    borderRadius: 10,
  },
  FormControltextArea: {
    borderColor: "#B7B7B7",
    borderRadius: 2,
    borderWidth: 1,
    marginBottom: 15,
    backgroundColor: ThemeColors.whiteColor,
    paddingLeft: 15,
    paddingRight: 15,
    color: ThemeColors.blackColor,
    fontSize: 14,
  },
  Row: {
    flexDirection: 'row',
  },
  Contain: {
    resizeMode: 'contain',
  },
  Imgfluid: {
    width: '100%',
    height: '100%',
  },
  TextCenter: {
    alignItems: 'center',
  },
  TextWhite: {
    color: ThemeColors.whiteColor,
  },
  TextBlack: {
    color: ThemeColors.blackColor,
  },
  TextGreen: {
    color: ThemeColors.greenColor,
  },
  TextMuted: {
    color: ThemeColors.darkgreyColor,
  },
  TextPrimary: {
    color: ThemeColors.primaryColor,
  },
  TextSecondary: {
    color: ThemeColors.secondaryColor,
  },
  AlignCenter: {
    alignItems: 'center',
  },
  JustifyCenter: {
    justifyContent: 'center',
  },
  SpaceBetween: {
    justifyContent: 'space-between',
  },
  WidthHalf: {
    width: '48%',
    marginHorizontal: '1%',
  },
  WidthFull: {
    width: '100%',
  },
  Size14: {
    fontSize: 14,
  },
  Size16: {
    fontSize: 16,
  },
  mt_30: {
    marginTop: 30,
  },
  mt_15: {
    marginTop: 15,
  },
  mt_10: {
    marginTop: 10,
  },
  mt_5: {
    marginTop: 5,
  },
  my_30: {
    marginVertical: 30,
  },
  my_15: {
    marginVertical: 15,
  },
  my_10: {
    marginVertical: 10,
  },
  my_5: {
    marginVertical: 5,
  },
  mb_30: {
    marginBottom: 30,
  },
  mb_20: {
    marginBottom: 20,
  },
  mb_15: {
    marginBottom: 15,
  },
  mb_10: {
    marginBottom: 10,
  },
  mainBtn:{
    justifyContent: 'center', 
    marginTop: 10,
     height: 68,
     alignItems: 'center',
     fontWeight: 'bold', 
     borderTopLeftRadius: 15,
     borderTopRightRadius: 15,
    borderBottomRightRadius:15, 
}
  
});
