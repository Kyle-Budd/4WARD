import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import TabBar from '../components/TabBar';
import ContactScreen from '../screens/ContactScreen';
import HomepageScreen from '../screens/HomepageScreen';
import ProfileScreen from '../screens/ProfileScreen';
import StoryScreen from '../screens/StoryScreen';

const Tab = createBottomTabNavigator();

import Icon from 'react-native-vector-icons/MaterialIcons';
import MCIcon from 'react-native-vector-icons/MaterialCommunityIcons';

const MainTab = () => {
  return (
    <Tab.Navigator
      screenOptions={{ headerShown: false }}
      initialRouteName="Home"
    // tabBar={props => <TabBar {...props} />}
    >
      <Tab.Screen name="Homepage" component={HomepageScreen}
        options={{
          tabBarLabel: () => { return null },
          tabBarIcon: ({ focused }) =>
            !focused ? (
              <Icon name="home-filled" size={25} color="#900" />
            ) : (
              <View>
                <Icon name="home-filled" size={35} color="#900" />
                <View style={{ backgroundColor: '#900', height: 3 }}></View>
              </View>
            ),
        }}
      />
      <Tab.Screen name="Story" component={StoryScreen}
        options={{
          tabBarLabel: () => { return null },
          tabBarIcon: ({ focused }) =>
            !focused ? (
              <Icon name="rss-feed" size={25} color="#900" />
            ) : (
              <View>
                <Icon name="rss-feed" size={35} color="#900" />
                <View style={{ backgroundColor: '#900', height: 3 }}></View>
              </View>

            ),
        }}
      />
      <Tab.Screen name="Profilepage" component={ProfileScreen}
        options={{
          tabBarLabel: () => { return null },
          tabBarIcon: ({ focused }) =>
            !focused ? (
              <MCIcon name="account" size={25} color="#900" />
            ) : (
              <View>
                <MCIcon name="account" size={35} color="#900" />
                <View style={{ backgroundColor: '#900', height: 3 }}></View>
              </View>
            ),
        }}
      />
      <Tab.Screen name="Contact" component={ContactScreen}
        options={{
          tabBarLabel: () => { return null },
          tabBarIcon: ({ focused }) =>
            !focused ? (
              <MCIcon name="contacts" size={25} color="#900" />
            ) : (
              <View>
                <MCIcon name="contacts" size={35} color="#900" />
                <View style={{ backgroundColor: '#900', height: 3 , marginTop:2}}></View>
              </View>
            ),
        }}
      />
    </Tab.Navigator>
  );
};

export default MainTab;

const styles = StyleSheet.create({});
