import auth from '@react-native-firebase/auth';
import messaging from '@react-native-firebase/messaging';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import axios from 'axios';
import React, { useCallback, useEffect, useState } from 'react';
import { PermissionsAndroid, Platform, SafeAreaView } from 'react-native';
import Geolocation from 'react-native-geolocation-service';
import Customloader from '../components/loader';
import { AuthState } from '../context/authState';
import { PostState } from '../context/postState';
import CameraScreen from '../screens/CameraScreen';
import GetstartedScreen from '../screens/GetstartedScreen';
import HomeAlertScreen from '../screens/HomeAlertScreen';
import IconReportScreen from '../screens/IconReportScreen';
import { MediaPage } from '../screens/MediaScreen';
import PostDetailsScreen from '../screens/PostDetailsScreen';
import SharePage from '../screens/SharePage';
import SnapShotScreen from '../screens/SnapShotScreen';
import { API_KEY } from '../utils/apiKey';
import AuthStack from './authStack';
import MainTab from './MainTab';
import LiveTracking from '../screens/LiveTracking';
import EmergencyContacts from '../screens/EmergencyContacts';

import SelectEmergencyContacts from '../screens/SelectEmergencyContacts';

import AsyncStorage from '@react-native-async-storage/async-storage';

function RootNavigation() {
  const Stack = createNativeStackNavigator();
  
  const {
    authUser,
    setAuthUser,
    setMyLocation,
    setDeviceToken,
    user,
    loadContacts,
    userBan,
    setuser
  } = AuthState();
  const { setPostCenter, setPostRadius } = PostState();
  const [initializing, setInitializing] = useState(true);
  const [loading, setloading] = useState(false);
  useEffect(() => {
    if (user) {
      setPostRadius(user?.radius || 500);
    }
  }, [user]);

  const handelSetLocation = useCallback(() => {
    Geolocation.watchPosition(
      async position => {
        if (position) {
          const { data } = await axios.get(
            `https://maps.googleapis.com/maps/api/geocode/json?latlng=${position.coords.latitude},${position.coords.longitude}&key=${API_KEY}`,
          );
          setMyLocation({
            address: data?.results[0].formatted_address,
            location: {
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
            },
          });
          setPostCenter({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          });
        }
      },
      error => {
        // See error code charts below.
        console.log(error.code, error.message);
        alert('Can not get device location');
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 },
    );
  }, []);

  useEffect(() => {
    (async () => {
      setloading(true);
      if (Platform.OS === 'android') {
        PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.READ_CONTACTS)
          .then(async () => {
            const granted = await PermissionsAndroid.request(
              PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
            );
            if (granted === PermissionsAndroid.RESULTS.GRANTED) {
              handelSetLocation();
              loadContacts();
            } else {
              alert('Please allow permission');
            }
          })
          .catch(() => {
            alert('Please allow contacts permission');
          });
      } else {
        Geolocation.requestAuthorization('whenInUse')
          .then(() => {
            handelSetLocation();
          })
          .catch(() => {
            alert('Please allow permission');
          });
      }
    })();
    setloading(false);
  }, []);

  useEffect(() => {
    let token;
    (async () => {
      if (Platform.OS === 'ios') {
        const authStatus = await messaging().requestPermission();
        const enabled =
          authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
          authStatus === messaging.AuthorizationStatus.PROVISIONAL;

        if (enabled) {
          console.log('Authorization status:', authStatus);
          token = await messaging().getToken();
          setDeviceToken(token);
        }
      } else if (Platform.OS === 'android') {
        token = await messaging().getToken();
        setDeviceToken(token);
      }
    })();
  }, []);

  var debounceTimeout;
const DebounceDueTime = 200;

  function onAuthStateChanged(user) {
    
    //alert(JSON.stringify(user))
    // setAuthUser(user);
    // if (initializing) setInitializing(false);
    //getData(user);

    ////////
    if (debounceTimeout)
        clearTimeout(debounceTimeout);

    debounceTimeout = setTimeout(() =>
    {
        debounceTimeout = null;

        handleAuthStateChanged(user);
    }, DebounceDueTime);
    ///////
  }
  function handleAuthStateChanged(user)
{
    // ... process event
    getData(user);

}

  useEffect(() => {
    const subscriber = auth().onAuthStateChanged(onAuthStateChanged);
    return subscriber;
  }, []);


  const getData = async (user) => {
    try {
      const value = await AsyncStorage.getItem('user');
      if (value) {

        // value previously stored
        //alert(JSON.stringify(user))

        setAuthUser(user);
        if (initializing) setInitializing(false);
      }
      else {
        if (user) {
          auth().signOut();
          setAuthUser(null);
          setuser(null);
          if (initializing) setInitializing(false);
        }
        else {
          
          setAuthUser(null);
          if (initializing) setInitializing(false);
        }
      }
    } catch (e) {
      // error reading value
    }
  }

  return (
    <SafeAreaView style={{ flex: 1 }}>
      {initializing || loading ? (
        <Customloader />
      ) : (
        <NavigationContainer>
          <Stack.Navigator
            screenOptions={{
              headerShown: false,
              animation: 'slide_from_right',
            }}>
            {authUser && !userBan ? (
              <>
                <Stack.Screen name="MainTab" component={MainTab} />

                <Stack.Screen name="IconReport" component={IconReportScreen} />
                <Stack.Screen name="Camera" component={CameraScreen} />
                <Stack.Screen name="SnapShot" component={SnapShotScreen} />
                <Stack.Screen
                  name="PostDetails"
                  component={PostDetailsScreen}
                />

                <Stack.Screen name="HomeAlert" component={HomeAlertScreen} />
                <Stack.Screen
                  name="Media"
                  component={MediaPage}
                  options={{
                    animation: 'none',
                    presentation: 'transparentModal',
                  }}
                />
                <Stack.Screen
                  name="Share"
                  component={SharePage}
                  options={{
                    animation: 'none',
                    presentation: 'transparentModal',
                  }}
                />
                <Stack.Screen name="LiveTracking" component={LiveTracking} />
                <Stack.Screen name="EmergencyContacts" component={EmergencyContacts} />
                <Stack.Screen name="SelectEmergencyContacts" component={SelectEmergencyContacts} />

              </>
            ) : (
              <>
                <Stack.Screen name="Getstarted" component={GetstartedScreen} />

                <Stack.Screen name="Auth" component={AuthStack} />
              </>
            )}
          </Stack.Navigator>
        </NavigationContainer>
      )}
    </SafeAreaView>
  );
}

export default RootNavigation;

{
  /* <Stack.Screen
                  name="SetUpProfile"
                  component={SetUpProfileScreen}
                /> */
}
{
  /* <Stack.Screen
                  name="AllowNotification"
                  component={AllowNotificationScreen}
                /> */
}
{
  /* <Stack.Screen
                  name="SelectEmergencyContact"
                  component={SelectEmergencyContactScreen}
                /> */
}
{
  /* <Stack.Screen name="Contact" component={ContactScreen} /> */
}

{
  /* <Stack.Screen name="TakeSnap" component={TakeSnapScreen} />
                <Stack.Screen name="TakeVideo" component={TakeVideoScreen} /> */
}
