import DeleteIcon from '@mui/icons-material/Delete';
import ViewIcon from '@mui/icons-material/RemoveRedEyeOutlined';
import {
	Box,
	Button,
	Card, Table,
	TableBody,
	TableCell,
	TableHead,
	TableRow,
	TextField
} from '@mui/material';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import axios from 'axios';
import { useCallback, useState } from 'react';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { useMutation, useQueryClient } from 'react-query';
import { baseUrl } from 'src/constant/baseurl';


export const SubAdminListResults = ({users, ...rest}) => {
  const queryClient = useQueryClient();

  const [open, setOpen] = useState(false);
  const [editedUser, setEditedUser] = useState(null);
  const handleOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
    setEditedUser(null);
  };

  const {mutate: delMut, isLoading} = useMutation(async variables => {
    const {data} = await axios.post(
      `${baseUrl}/deleteAdmin`,

      variables,
    );
    return data;
  });
  const {mutate: updateMut, isLoading: uLoading} = useMutation(
    async variables => {
      const {data} = await axios.post(
        `${baseUrl}/updateAdmin`,

        variables,
      );
      return data;
    },
  );


  const handelDeleteUser = useCallback((adminData) => {
    delMut(
      {adminData},
      {
        onSuccess: (d, v) => {
          queryClient.setQueryData('allAdmins', old => {
            return {
              ...old,
              users: old.users.filter(u => u.email !== v.adminData.email),
            };
          });
        },
      },
    );
  }, []);

  const handelSetUser = useCallback(user => {
    setEditedUser(user);
    handleOpen();
  }, []);

  const handleEditUser = useCallback(() => {
    updateMut(
      {adminData: editedUser},
      {
        onSuccess: (d, v) => {
          queryClient.setQueryData('allAdmins', old => {
            return {
              ...old,
              users: old.users.map(u =>
                u.email === v.adminData.email ? editedUser : u,
              ),
            };
          });
          handleClose();
        },
      },
    );
  }, [editedUser]);
  const handleChange = useCallback(event => {
    setEditedUser(p => ({...p, [event.target.name]: event.target.value || ''}));
  }, []);

  return (
    <>
      <Card {...rest}>
        <PerfectScrollbar style={{overflowX: 'auto'}}>
          <Box sx={{minWidth: 1050}}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Email</TableCell>
                  <TableCell>Password</TableCell>
                  <TableCell>View</TableCell>
                  <TableCell>Delete</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {users?.map((customer, id) => (
                  <TableRow hover key={id}>
                    <TableCell>{customer?.email || 'N/A'}</TableCell>
                    <TableCell>{customer?.password || 'N/A'}</TableCell>

                    <TableCell
                      onClick={() => handelSetUser(customer)}
                      sx={{':hover': {cursor: 'pointer'}}}>
                      <ViewIcon color="error" />
                    </TableCell>
                    <TableCell
                      sx={{':hover': {cursor: 'pointer'}}}
                      onClick={() =>
                        handelDeleteUser(customer)
                      }>
                      <DeleteIcon color="error" />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Box>
        </PerfectScrollbar>
      </Card>

      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description">
     
        <DialogContent sx={{maxWidth: 500, width: 500}}>
         
          <TextField
            id="filled-multiline-flexible"
            label="Email"
            name="email"
            fullWidth
            sx={{mt: 2}}
            value={editedUser?.email || ''}
            onChange={handleChange}
            variant="filled"
          />
          <TextField
            id="filled-multiline-flexible"
            label="Password"
            name="password"
            fullWidth
            sx={{mt: 2}}
            value={editedUser?.password || ''}
            onChange={handleChange}
            variant="filled"
          />
      
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} disabled={isLoading || uLoading}>
            Cancel
          </Button>
          <Button
            onClick={handleEditUser}
            autoFocus
            disabled={isLoading || uLoading}>
            Update
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

