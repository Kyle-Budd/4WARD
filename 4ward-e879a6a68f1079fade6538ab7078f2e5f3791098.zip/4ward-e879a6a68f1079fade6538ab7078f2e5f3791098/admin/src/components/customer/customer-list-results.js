import DeleteIcon from '@mui/icons-material/Delete';
import {
  Avatar,
  Box,
  Button,
  Card,
  Switch,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TextField,
} from '@mui/material';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import ViewIcon from '@mui/icons-material/RemoveRedEyeOutlined';
import LocationIcon from '@mui/icons-material/LocationCity';
import axios from 'axios';
import {useCallback, useState} from 'react';
import PerfectScrollbar from 'react-perfect-scrollbar';
import {useMutation, useQueryClient} from 'react-query';
import {baseUrl} from 'src/constant/baseurl';
import {getInitials} from '../../utils/get-initials';
export const CustomerListResults = ({users, ...rest}) => {
  const queryClient = useQueryClient();

  const [open, setOpen] = useState(false);
  const [editedUser, setEditedUser] = useState(null);
  const handleOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
    setEditedUser(null);
  };

  const {mutate, isLoading} = useMutation(async variables => {
    const {data} = await axios.post(
      `${baseUrl}/banUser`,

      variables,
    );
    return data;
  });
  const {mutate: delMut} = useMutation(async variables => {
    const {data} = await axios.post(
      `${baseUrl}/deleteUser`,

      variables,
    );
    return data;
  });
  const {mutate: updateMut, isLoading: uLoading} = useMutation(
    async variables => {
      const {data} = await axios.post(
        `${baseUrl}/updateUser`,

        variables,
      );
      return data;
    },
  );

  const handelBanStatus = useCallback((userId, status) => {
    mutate(
      {userId, banStatus: status},
      {
        onSuccess: (d, v) => {
          queryClient.setQueryData('allUsers', old => {
            return {
              ...old,
              users: old.users.map(u =>
                u.id === v.userId ? {...u, banStatus: v.banStatus} : u,
              ),
            };
          });
        },
      },
    );
  }, []);

  const handelDeleteUser = useCallback((id, phone) => {
    console.log(id);
    delMut(
      {userId: id, phone},
      {
        onSuccess: (d, v) => {
          queryClient.setQueryData('allUsers', old => {
            return {
              ...old,
              users: old.users.filter(u => u.id !== v.userId),
            };
          });
        },
      },
    );
  }, []);

  const handelSetUser = useCallback(user => {
    setEditedUser(user);
    handleOpen();
  }, []);

  const handleEditUser = useCallback(() => {
    updateMut(
      {userData: editedUser},
      {
        onSuccess: (d, v) => {
          queryClient.setQueryData('allUsers', old => {
            return {
              ...old,
              users: old.users.map(u =>
                u.id === v.userData.id ? editedUser : u,
              ),
            };
          });
          handleClose();
        },
      },
    );
  }, [editedUser]);
  const handleChange = useCallback(event => {
    setEditedUser(p => ({...p, [event.target.name]: event.target.value || ''}));
  }, []);

  return (
    <>
      <Card {...rest}>
        <PerfectScrollbar style={{overflowX: 'auto'}}>
          <Box sx={{minWidth: 1050}}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Profile pic</TableCell>
                  <TableCell>Name</TableCell>
                  <TableCell>Email</TableCell>
                  <TableCell>Phone</TableCell>
                  <TableCell>Ban Status</TableCell>
                  <TableCell>Change Ban status</TableCell>
                  <TableCell>View</TableCell>
                  <TableCell>Delete</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {users?.map((customer, id) => (
                  <TableRow hover key={id}>
                    <TableCell>
                      <Box flex={1}>
                        <img
                          src={
                            customer?.profilePic ||
                            'https://firebasestorage.googleapis.com/v0/b/ward-af760.appspot.com/o/icons%2F4waed_logo.png?alt=media&token=35b261bc-f2e5-4742-8bfd-64a295cc07f9'
                          }
                          width={50}
                          height={50}
                          style={{objectFit: 'contain'}}
                        />
                      </Box>
                    </TableCell>
                    <TableCell>
                      {customer?.userName || `User ${customer?.id.slice(-5)}`}
                    </TableCell>
                    <TableCell>{customer?.email || 'N/A'}</TableCell>
                    <TableCell>{customer?.phone || 'N/A'}</TableCell>

                    <TableCell>
                      {customer?.banStatus ? 'Active' : 'Inactive'}
                    </TableCell>
                    <TableCell>
                      <Switch
                        defaultChecked={customer?.banStatus}
                        value={customer?.banStatus}
                        size="small"
                        onChange={(_, checked) =>
                          handelBanStatus(customer.id, checked)
                        }
                      />
                    </TableCell>
                    <TableCell
                      onClick={() => handelSetUser(customer)}
                      sx={{':hover': {cursor: 'pointer'}}}>
                      <ViewIcon color="error" />
                    </TableCell>
                    <TableCell
                      sx={{':hover': {cursor: 'pointer'}}}
                      onClick={() =>
                        handelDeleteUser(customer?.id, customer?.phone)
                      }>
                      <DeleteIcon color="error" />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Box>
        </PerfectScrollbar>
      </Card>

      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description">
        <DialogTitle id="alert-dialog-title">
          {editedUser?.userName || `User ${editedUser?.id.slice(-5)}`}
        </DialogTitle>
        <DialogContent sx={{maxWidth: 500, width: 500}}>
          <DialogContentText
            id="alert-dialog-description"
            mt={2}
            alignItems="center"
            display={'flex'}
            style={{gridGap: '10px'}}>
            <LocationIcon /> {editedUser?.location?.address}
          </DialogContentText>
          <TextField
            id="filled-multiline-flexible"
            label="Username"
            name="userName"
            fullWidth
            sx={{mt: 2}}
            value={editedUser?.userName || ''}
            onChange={handleChange}
            variant="filled"
          />
          <TextField
            id="filled-multiline-flexible"
            label="Email"
            name="email"
            fullWidth
            sx={{mt: 2}}
            value={editedUser?.email || ''}
            onChange={handleChange}
            variant="filled"
          />
          <TextField
            id="filled-multiline-flexible"
            label="Phone"
            name="phone"
            fullWidth
            disabled
            sx={{mt: 2}}
            value={editedUser?.phone || ''}
            onChange={handleChange}
            variant="filled"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} disabled={isLoading || uLoading}>
            Cancel
          </Button>
          <Button
            onClick={handleEditUser}
            autoFocus
            disabled={isLoading || uLoading}>
            Update
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

{
  /* <TableCell>{format(customer?.createdAt, "dd/MM/yyyy")}</TableCell> */
}

{
  /* <TablePagination
        component="div"
        count={customers.length}
        onPageChange={handlePageChange}
        onRowsPerPageChange={handleLimitChange}
        page={page}
        rowsPerPage={limit}
        rowsPerPageOptions={[5, 10, 25]}
      /> */
}

{
  /* <TableCell padding="checkbox">
                    <Checkbox
                      checked={selectedCustomerIds.indexOf(customer.id) !== -1}
                      onChange={(event) => handleSelectOne(event, customer.id)}
                      value="true"
                    />
                  </TableCell> */
}
// CustomerListResults.propTypes = {
//   customers: PropTypes.array.isRequired,
// };

// const [selectedCustomerIds, setSelectedCustomerIds] = useState([]);
// const [limit, setLimit] = useState(10);
// const [page, setPage] = useState(0);

// const handleSelectAll = (event) => {
//   let newSelectedCustomerIds;

//   if (event.target.checked) {
//     newSelectedCustomerIds = customers.map((customer) => customer.id);
//   } else {
//     newSelectedCustomerIds = [];
//   }

//   setSelectedCustomerIds(newSelectedCustomerIds);
// };

// const handleSelectOne = (event, id) => {
//   const selectedIndex = selectedCustomerIds.indexOf(id);
//   let newSelectedCustomerIds = [];

//   if (selectedIndex === -1) {
//     newSelectedCustomerIds = newSelectedCustomerIds.concat(selectedCustomerIds, id);
//   } else if (selectedIndex === 0) {
//     newSelectedCustomerIds = newSelectedCustomerIds.concat(selectedCustomerIds.slice(1));
//   } else if (selectedIndex === selectedCustomerIds.length - 1) {
//     newSelectedCustomerIds = newSelectedCustomerIds.concat(selectedCustomerIds.slice(0, -1));
//   } else if (selectedIndex > 0) {
//     newSelectedCustomerIds = newSelectedCustomerIds.concat(
//       selectedCustomerIds.slice(0, selectedIndex),
//       selectedCustomerIds.slice(selectedIndex + 1)
//     );
//   }

//   setSelectedCustomerIds(newSelectedCustomerIds);
// };

// const handleLimitChange = (event) => {
//   setLimit(event.target.value);
// };

// const handlePageChange = (event, newPage) => {
//   setPage(newPage);
// };
