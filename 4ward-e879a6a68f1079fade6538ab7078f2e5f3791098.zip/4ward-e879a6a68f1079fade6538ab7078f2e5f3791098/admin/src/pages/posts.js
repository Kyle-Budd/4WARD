import {Box, Container} from '@mui/material';
import axios from 'axios';
import {useQuery} from 'react-query';
import Loader from 'src/components/loader';
import authHoc from 'src/utils/authHoc';
import {CustomerListResults} from '../components/customer/customer-list-results';
import {DashboardLayout} from '../components/dashboard-layout';
import {baseUrl} from '../constant/baseurl';
import React from 'react';
import { PostListResults } from 'src/components/post/postList';

const fetchAllPosts = async () => {
  const {data} = await axios.get(`${baseUrl}/getAllPosts`);
  return data;
};

const Customers = () => {
  const {data, isLoading} = useQuery('allPosts', fetchAllPosts, {
    retry: false,
    refetchOnWindowFocus: false,
  });

  console.log('-----posts----', data);

  if (isLoading) {
    return <Loader />;
  }

  return (
    <DashboardLayout>
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          py: 8,
        }}>
        <Container maxWidth={false}>
          {/* <CustomerListToolbar /> */}
          <Box sx={{mt: 3}}>
            <PostListResults posts={data?.posts} />
          </Box>
        </Container>
      </Box>
    </DashboardLayout>
  );
};

export default authHoc(Customers);