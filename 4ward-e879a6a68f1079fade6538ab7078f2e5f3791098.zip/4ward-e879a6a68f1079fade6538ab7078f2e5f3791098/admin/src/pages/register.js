import {
  Box,
  Button,
  Container,
  Link,
  TextField,
  Typography,
} from '@mui/material';
import axios from 'axios';
import {useFormik} from 'formik';
import NextLink from 'next/link';
import {useRouter} from 'next/router';
import {useEffect} from 'react';
import {useMutation} from 'react-query';
import {baseUrl} from 'src/constant/baseurl';
import * as Yup from 'yup';

const Register = () => {
  const router = useRouter();

  const {mutate, isLoading} = useMutation(async variables => {
    const {data} = await axios.post(
      `${baseUrl}/createAdmin`,

      variables,
    );
    return data;
  });

  const formik = useFormik({
    initialValues: {
      adminEmail: '',
      adminPassword: '',
      email: '',
      password: '',
    },
    validationSchema: Yup.object({
      email: Yup.string()
        .email('Must be a valid email')
        .max(255)
        .required('Email is required'),

      password: Yup.string().max(255).required('Password is required'),
    }),
    onSubmit: values => {
      if (
        values.adminEmail !== 'kyle@mcholmescorp.com' ||
        values.adminPassword !== '4WARD2022!'
      ) {
        alert('Wrong admin credential!');
        return;
      }
      mutate(values, {
        onSuccess: () => {
          localStorage.setItem('admin_token', values.email);
          window.location.assign('/');
        },
        onError: () => alert('Something went wrong'),
      });
    },
  });

  useEffect(() => {
    if (!localStorage.getItem('superAdmin')) {
      window.location.assign('/');
    }
  }, []);

  return (
    <>
      <Box
        component="main"
        sx={{
          alignItems: 'center',
          display: 'flex',
          flexGrow: 1,
          minHeight: '100%',
        }}>
        <Container maxWidth="sm">
          <form onSubmit={formik.handleSubmit}>
            <Box sx={{my: 3}}>
              <Typography color="textPrimary" variant="h4">
                Create a new sub admin account
              </Typography>
              <Typography color="textSecondary" gutterBottom variant="body2">
                Use admin email to create a new sub admin account
              </Typography>
            </Box>

            <TextField
              error={Boolean(
                formik.touched.adminEmail && formik.errors.adminEmail,
              )}
              fullWidth
              helperText={formik.touched.adminEmail && formik.errors.adminEmail}
              label="Admin Email Address"
              margin="normal"
              name="adminEmail"
              onBlur={formik.handleBlur}
              onChange={formik.handleChange}
              type="email"
              value={formik.values.adminEmail}
              variant="outlined"
            />
            <TextField
              error={Boolean(
                formik.touched.adminPassword && formik.errors.adminPassword,
              )}
              fullWidth
              helperText={
                formik.touched.adminPassword && formik.errors.adminPassword
              }
              label="Admin Password"
              margin="normal"
              name="adminPassword"
              onBlur={formik.handleBlur}
              onChange={formik.handleChange}
              type="password"
              value={formik.values.adminPassword}
              variant="outlined"
            />
            <TextField
              error={Boolean(formik.touched.email && formik.errors.email)}
              fullWidth
              helperText={formik.touched.email && formik.errors.email}
              label="Sub Admin Email Address"
              margin="normal"
              name="email"
              onBlur={formik.handleBlur}
              onChange={formik.handleChange}
              type="email"
              value={formik.values.email}
              variant="outlined"
            />
            <TextField
              error={Boolean(formik.touched.password && formik.errors.password)}
              fullWidth
              helperText={formik.touched.password && formik.errors.password}
              label="Sub Admin Password"
              margin="normal"
              name="password"
              onBlur={formik.handleBlur}
              onChange={formik.handleChange}
              type="password"
              value={formik.values.password}
              variant="outlined"
            />

            <Box sx={{py: 2}}>
              <Button
                color="primary"
                disabled={formik.isSubmitting || isLoading}
                fullWidth
                size="large"
                type="submit"
                variant="contained">
                Create Sub Admin
              </Button>
            </Box>
            <Typography color="textSecondary" variant="body2">
              Have an account?{' '}
              <NextLink href="/login" passHref>
                <Link variant="subtitle2" underline="hover">
                  Sign In
                </Link>
              </NextLink>
            </Typography>
          </form>
        </Container>
      </Box>
    </>
  );
};

export default Register;
