/* eslint-disable react/display-name */
import Box from '@mui/material/Box';
import CircularProgress from '@mui/material/CircularProgress';
import axios from 'axios';
import {useState} from 'react';
import {useQuery} from 'react-query';
import React from 'react';

const authHoc = WrappedComponent => {
  return props => {
    const [isAuth, setisAuth] = useState(null);

    useQuery(
      'loadKey',
      () => {
        const token = localStorage.getItem('admin_token');
        return token;
      },
      {
        onSuccess: d => {
          if (d) {
            console.log('data', d);
            setisAuth(d);
            // axios.defaults.headers.common.Authorization = `Bearer ${d}`;
          } else {
            setisAuth(null);
            window.location.assign('/login');
          }
        },
      },
    );

    if (isAuth) {
      return <WrappedComponent {...props} />;
    } else {
      return (
        <Box
          sx={{
            display: 'flex',
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center',
            height: '100vh',
          }}>
          <CircularProgress />
        </Box>
      );
    }
  };
};

export default authHoc;
